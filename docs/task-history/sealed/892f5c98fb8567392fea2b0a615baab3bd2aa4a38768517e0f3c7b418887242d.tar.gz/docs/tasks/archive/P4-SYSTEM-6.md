# P4-SYSTEM — archive part 6

Completed receipts moved byte-verbatim from the active tree, continuing part 5.

`P4-SYSTEM.12` slice (e1c1) — independent selected cache (`2026-10-08`, `SEMULITH-P4-0096`):

- [x] **REPRODUCE / ROOT CAUSE** — `python3 scripts/probe_gc_cache_author.py
  --author-revision ff75610` rc=1: “cache must retain stale mapping until fence”.
  `rg -n 'def walk|sfence.vma' scripts/derive_rv64gc_expectations.py` locates the
  unconditional PTE walk and fence prose without an effect. Prior parcel census
  sv39-tlb-fence disagrees at steps 191/192/195; pinned supervisor four scopes and
  state.sexp:664 select cached translation behavior independently of engine outputs.
- [x] **FIX** — successful translations install four FIFO slots keyed by 4-KiB VPN
  and 16-bit ASID; G propagates through non-leaves. Hits recheck live effective mode,
  SUM/MXR against cached leaf permissions/A/D; faults install nothing. M/Bare bypass,
  root-on-miss and current ASID visibility remain explicit. Legal fences use x0 identity,
  masked ASID and canonical selected page, retaining globals when ASID-scoped and the
  FIFO cursor for every invalidation. Illegal fences leave cache unchanged. Three
  existing direct PTE-edit fixtures execute legal full fences before requiring freshness.
- [x] **ADDRESSED (verified)** — `python3 scripts/probe_gc_cache_author.py` rc=0:
  hand PTE/PA fixtures cover stale mappings, four zero-operand scopes, masked ASIDs,
  invalid VA, illegal U/TVM fences, inherited globals, root/ASID/Bare/MPRV visibility,
  live SUM/MXR/U, cached D=0, no-fault-installation, FIFO and independent superpage
  keys. Cold cache guest request logs repeat exactly. Thirteen mutants each rc=1 with
  named behavioral assertions; the uncached parent is RED. One initially overbroad
  illegal-fence mutant failed a legal scope first; refine it to illegal cases, then
  the gate names the intended no-effect failure. An invalid-VA guard deletion alone
  has no observable effect for canonical cache keys; the control instead injects
  actual invalid-address over-fencing. Final self-test: 103 pass / 0 fail.
- [x] **NO REGRESSION** — full non-writing author census: parcel 139 exact, zero
  disagreements/refusals; historical word route 120 exact / one corrected cache text
  / zero new, with the same 18 bounded refusals. `--check-owned`: 42 guest(s)
  byte-identical; no records written. All 139 expected-record hashes retained. GUEST-GEN
  rc=0: both generated fixtures match and mirror 91 exact / seven declared rederivations.
  DERIVED-COUNTS rc=0 derives 582 arms; make book rc=0 for project/all model books.
  Rust/production profile/guest/count files unchanged; no broad Rust rerun warranted.
- [x] **LOCKSTEP / PRESSURE** — MEMORY/tree/index/live docs/toolbox/doctrine and
  C/Sv39 book updated; LIVE_STATUS remains P4 11/18, CPU-SYSTEM incomplete. DEV_NOTES
  50,021→47,771 B, shard-0209 carries one oldest record; shard tool asserts 32 ==
  31 kept + one moved, order/bytes exact. CHANGELOG new summary 118 B, full detail here.
  Archive 212 files / 784,318 B, only 2,114 B remaining; next CHANGELOG cut needs
  2,377 B before header/manifest and current head has eight bytes left. `.4` owns the
  urgent lifecycle prerequisite, with exact 210-shard / 211-member archive retrieval
  proof and proposed transaction in its tree. No cap or existing frozen bytes changed.
  promotion: declined (hand cache fixtures/thirteen RED controls retain the lesson).

`P4-SYSTEM.12` slice (e1d0) — honest author provenance (`2026-10-09`, `SEMULITH-P4-0097`):

- [x] **REPRODUCE / ROOT CAUSE** — `python3 scripts/probe_gc_provenance.py
  --author-revision 5ac3514` rc=1: generic output inherited FP provenance.
  `rg -n 'floating-point corpus|def emit' scripts/derive_rv64gc_expectations.py`
  pinpoints emit's unconditional FP fallback, inferred from unmatched filenames.
- [x] **FIX / ADDRESSED** — the tracked author names its actual word or explicit-budget
  C-capable parcel route. Historical capture headers apply only to the 42 canonical
  owned word inputs, never copied names or a new parcel derivation. No invented
  pre-engine chronology. `python3 scripts/probe_gc_provenance.py` rc=0: generic,
  nine borrowed names, raw C.ADDI observation/schema, owned parcel route, unknown-route
  refusal and all 42 historical records exact. Four targeted mutations each rc=1
  with the intended provenance/route reason. No production record is written.
- [x] **NO REGRESSION** — `bash scripts/check_guest_gen.sh` rc=0: 109 pass / 0 fail;
  both tracked generated fixtures exact, base mirror 91 exact / seven declared.
  DERIVED-COUNTS --list derives 605 arms. Only new-output comments change; existing
  139 expectation files, production encoding and Rust modules unchanged.
- [x] **LOCKSTEP** — MEMORY/frontier/live status (P4 11/18 unchanged), logs,
  toolbox/doctrine and C book updated. Completed e1c0 receipt moved verbatim to
  archive part 5 (2,979 B); reconstruction asserted, archive 63,976 B. README neutral
  body and claim-verification source body identical to read-only policy sources.
  Containment guide read (SHA-256 8f77fa39c9bcb9cfc43166259a627a6ced64682030088400b727dccc5d674a53);
  full adoption remains LIVE-CONTAINMENT.4. `make book` and commit gate must pass.
  promotion: declined (permanent provenance fixtures and four RED controls retain the rule).

`P4-SYSTEM.12` slice (e1d1) — historical parcel-count staging (`2026-10-09`, `SEMULITH-P4-0098`):

- [x] **REPRODUCE / ROOT CAUSE** — `python3 scripts/derive_gc_parcel_counts.py`
  rc=0: derives 139 exact architectural write traces at their 4,913 declared boundaries:
  4,888 prior word requests -> 9,770 actual parcel requests. Five guests differ
  from blind doubling (runoff/fetch faults). The encoding's C slot remains unbound;
  e1d's declared count-provenance prerequisite precedes adopting any new extent.
- [x] **FIX / ADDRESSED** — tracked census derives each run independently, checks
  all writes against its prior record and the step fetch sum against the actual
  request log. Deterministic staging manifest carries 393 conservative input hashes,
  including instrument code, schemas/definition data, unit metadata and every paired
  source/record. `python3 scripts/derive_gc_parcel_counts.py --check` rc=0; no guest
  record written. Hand word/mixed/runoff counts and repeat pass. Observation/extent
  mutations each rc=1 with the intended boundary/request-log diagnosis; a damaged
  stored count is DRIFT (rc=1), the unchanged manifest is green.
- [x] **NO REGRESSION** — `bash scripts/check_guest_gen.sh` rc=0: 113 pass / 0 fail,
  both generated fixtures and the base mirror exact. Existing 139 expectation records,
  encoding and both generated Rust modules remain byte-exact against eaad766;
  no Rust change, no broad Rust rerun warranted. DERIVED-COUNTS --list derives 609 arms.
- [x] **LOCKSTEP** — MEMORY/frontier/index, live status (P4 11/18 unchanged), logs,
  C book and toolbox/doctrine updated. e1c1 moved byte-verbatim to archive part 6
  (3,392 B; reconstruction asserted). `scripts/shard_history.py` cuts CHANGELOG
  79 == 76 kept + 3 moved (65,383 -> 57,215 B) and DEV_NOTES 41 == 35 + 6
  (48,995 -> 40,281 B), bytes/order exact; shards 0215/0216, fixed bounds unchanged.
  `make book` rc=0; commit gate enforced. Git diff whitespace check reports only
  retained whole-record blank separators at the two sharded heads' EOF; code diff
  is clean. Next e1d2: the independently authored C corpus.
  promotion: declined (permanent hand/RED/drift controls retain the count distinction).

`P4-SYSTEM.12` slice (e1d2) — specification-derived compressed corpus (`2026-10-09`, `SEMULITH-P4-0099`):

- [x] **REPRODUCE / ROOT CAUSE** — e1d requires a new C corpus before binding.
  `python3 scripts/stage_gc_c_corpus.py` rc=0: 28 staged guests, all 37 selected
  forms, 429 predeclared boundaries, 708 actual parcels. The production encoding
  still carries the C slot. Primary chapter digest re-verified and read in full.
- [x] **FIX / ADDRESSED** — tracked producer declares programs/budgets and hand
  final/PC/state checkpoints before any processor-engine run. Independent author
  derives every observation and request. Coverage requires an actual expansion
  derivation, excluding source annotations at interrupt/fetch-fault boundaries.
  `--check` rc=0, schemas 28/28. Observation and extent mutants each rc=1 with
  named semantic reasons; a saved budget changed 15->16 makes --check DRIFT (rc=1),
  then regeneration restores exact output. Initial LR/SC source syntax was refused;
  corrected to the documented parenthesized-address interface, no oracle changed.
- [x] **NO REGRESSION** — `bash scripts/check_guest_gen.sh` rc=0: 117 pass / 0 fail,
  both generated fixtures and base mirror exact. `python3 scripts/derive_gc_parcel_counts.py
  --check` rc=0: all 139 historical traces still exact at 4,913 boundaries / 9,770
  requests; its conservative fingerprints regenerated for the new producer. All
  142 production records/encoding/generated modules byte-exact against 4754419.
  DERIVED-COUNTS --list derives 613 arms. No Rust or production guest/count changes.
- [x] **LOCKSTEP** — MEMORY/frontier/index/live status (P4 remains 11/18), logs,
  toolbox/doctrine and C book updated. Closed e1d0/e1d1 receipts moved byte-verbatim
  to archive part 6, reconstruction asserted; bounds unchanged. `make book` and
  commit gate enforced. Staged sources/records total 204,698 B: projected profile
  family 519 files / 3,091,575 B before bind metadata, inside current 600 / 3,145,728
  ceilings. Next: e2 preflight of count/mirror contracts, atomic C bind, matched Sail.
  promotion: declined (permanent source/hand/mutation/drift controls retain the method).

`P4-SYSTEM.12` slice (e2a) — govern the count-only mirror migration (`2026-10-09`, `SEMULITH-P4-0100`):

- [x] **REPRODUCE / ROOT CAUSE** — target-local copy adopts independently staged
  parcel counts; current shell governor rc=1 at bound-alias, because full-byte
  comparison cannot express the declared extent migration. Log e2a/before.log.
  Production is still unbound and no production file changes in this prerequisite.
- [x] **FIX / ADDRESSED** — `python3 scripts/check_gc_mirror.py --self-test` rc=0:
  hand word/mixed/runoff counts, repeat, composition selection, wrong count,
  comment/CRLF/write/source drift, stale exceptions, duplicate/direct/nested/string
  field controls pass. C mode independently derives every supplied guest's writes
  and actual requests before surgical direct-field transformation; all other bytes
  governed. The seven named re-derivations must still differ after normalization.
  Four weakened-check mutations each rc=1 for the intended accepted-defect reason.
- [x] **NO REGRESSION** — real target-local migrated corpus on temporary full-C
  composition rc=0: 49 exact files + 42 checked count-only records + seven declared
  re-derivations; same copy with unbound composition rc=1. Production governor
  rc=0: 91 exact / zero adjusted / seven declared, unchanged from pre-slice.
  `bash scripts/check_guest_gen.sh` rc=0: 122 pass / 0 fail, both generated fixtures
  exact. All 142 production records/encoding/modules byte-exact against 413c7da.
  DERIVED-COUNTS derives 618 arms. No Rust change.
- [x] **LOCKSTEP** — live docs/frontier/toolbox/doctrine and C book synchronized;
  P4 remains 11/18. e1d2 receipt moved byte-verbatim (2,185 B) to archive part 6,
  reconstruction asserted. Fixed ceilings unchanged. Active brief now names c1's
  parcel-first replacement, removing the superseded coalescing direction.
  `make book` rc=0. First hook refused derived book-index drift; regenerated through
  gen_book_index.py, then rebuilt the book. Next e2b: atomic composition/corpus/
  contract bind, then matched Sail and leaf acceptance. Commit gate enforced.
  promotion: declined (permanent literal/extent/mutation controls retain the distinction).

## Closed design — e1d2 corpus

- `2026-10-09` (e1d2 corpus design, before changes): primary RVI-C chapter read in
  full from the pinned cache, digest 3f7e7d853d6e12e9d44c3d1bb488d1c312179a308d608182fb01db43a49d6aeb.
  Track a staging producer with predeclared budgets for all 37 selected forms:
  signed/scaled limits, word overflow, aliases/x0/HINTs, stack/compact integer and D
  memory, mixed branches and pc+2 links (rd=rs1), LR/SC with valid C arithmetic,
  reserved original-bit diagnostics/EBREAK and four FS=Off memory gates. Derive
  all expected values spec-side before engine runs. Adapt the existing public
  sv39-straddle source into C.NOP at the final halfword versus a required second
  parcel on a non-executable page; budgets 52 and 51, cause 12/tval next page,
  saved start PCs and actual requests hand-checked. Use temporary full-C composition
  with copied profile/state metadata, emit only target-local staged sources/records
  and a fingerprinted manifest, and discriminate changed observations/extent.
  Production sources/counts/composition/modules remain untouched until e2. Archive
  completed e1d0 verbatim to part 6 to preserve the fixed live-tree ceiling.

`P4-SYSTEM.12` slice (e2b) — historical author extent preflight (`2026-10-09`, `SEMULITH-P4-0101`):

- [x] **REPRODUCE / ROOT CAUSE** — full-C target-local snapshot with independently
  migrated counts makes --check-owned rc=1: all 42 records DRIFT (e2b/before.log).
  The historical word route regenerates capture text and word extent together;
  the new boundary needs a separately derived count, not replacement prose.
- [x] **FIX / ADDRESSED** — `python3 scripts/probe_gc_owned_extent.py` rc=0:
  42-record unbound check, full-C unmigrated refusal, migrated/repeat checks,
  count/write/comment/CRLF drift, canonical word-write refusal with byte identity,
  and explicit parcel write/provenance pass. Bound checks compare independently
  derived parcel writes to the historical derivation and reconcile the actual
  request log before the shared direct-field transform. Four author mutants each
  rc=1: old counts, parcel prose, bad request log and permitted word overwrite.
- [x] **NO REGRESSION** — `bash scripts/check_guest_gen.sh` rc=0: 127 pass / 0 fail;
  both generated fixtures and production mirror (91 exact/seven declared) match.
  First unstaged cold check named the new untracked helper as missing; a temporary
  target-local index included the pending Python files for the tracked-input test.
  Actual index SHA-256 unchanged (verified); no gate weakened. All 142 production
  records/encoding/modules byte-exact against ce6a6d8. No Rust change; 623 arms.
- [x] **LOCKSTEP** — live docs/frontier/book/toolbox/doctrine updated, P4 11/18
  unchanged. Closed e2a receipt and e1d2 design moved byte-verbatim to archive part 6;
  reconstruction asserted, fixed caps unchanged. `make book` and commit gate enforced.
  Next e2c binds the production composition, staged corpus/counts, contract and matrix;
  matched Sail and leaf acceptance follow.
  promotion: declined (permanent snapshot/byte/write/mutation controls retain the rule).


## Closed pre-bind design notes (e2b/e2a)

- `2026-10-09` (e2b author preflight, before changes): the bind also changes the
  42 historical author-owned records' extents. Own this prerequisite before e2c's
  atomic bind: reproduce --check-owned on a target-local full-C snapshot with
  independently staged parcel counts. Preserve the original word-derived capture
  text; independently execute each fixed budget, compare every write and actual
  request log, and transform only its direct fetch field. Share the surgical helper
  with the mirror governor through a small text module, avoiding a dependency from
  the author to its governor. Unbound historical checks stay byte-exact. Refuse a
  default word-route CLI write to a canonical C-composed record; an explicit parcel
  route remains available. Retain controls for migrated/unmigrated counts, wrong
  observations/comments, request-log disagreement, write refusal and the original
  42 records. Archive closed e2a verbatim; production remains unchanged here.

- `2026-10-09` (e2a bind preflight, before changes): own the mirror/count governor
  prerequisite here before the atomic bind. Diagnose the current governor against a
  target-local copy with independently staged parcel counts: exact byte comparison
  must refuse. Replace only its fetch-field comparison for a C-composed unit with a
  surgical transformation; compare every other byte and retain the seven declared
  semantic re-derivations, which must still differ after count normalization. Independently
  derive all supplied records' writes and actual request counts before accepting any
  parcel extent. The unbound production route stays byte-exact. Add permanent controls
  for word/mixed/runoff extents, wrong counts, non-count comments/observations/source
  drift, stale re-derivations, duplicate/nested/string field traps and exact repeat.
  No production record/composition/module change in this prerequisite. Correct the
  active brief's superseded coalescing sentence to the c1 parcel-first decision already
  recorded below. Commit e2a, then e2b binds the staged corpus and contract together.


## Closed e1d staging/provenance design notes

- `2026-10-09` (e1d split, before changes): e1d1 first tracks a reproducible,
  non-writing census of all historical guests at their already-declared budgets.
  Compare every independently derived architectural write to the existing records;
  derive parcel counts from actual request logs and check the per-step sum. Emit a
  deterministic fingerprinted staging manifest, with no production count changes.
  Hand word/mixed/runoff counts, wrong-observation and wrong-extent controls must
  discriminate. Then e1d2 authors the C corpus before e2 binds. Archive e1c1 verbatim
  to part 6 at the live-tree ceiling, with exact reconstruction asserted.

- `2026-10-09` (e1d0 provenance prerequisite, before changes): emit currently falls
  through to the FP-corpus header for generic/C/Sv39 source names. Preserve exact
  historical headers only for the 42 canonical owned sources on their word route;
  every new output names the tracked spec-side author and its actual word or
  explicit-budget C-capable parcel route, without inventing original family or
  pre-engine chronology. Guard generic sources, borrowed historical basenames,
  raw C parcels and parcel re-derivation of an owned input, with parent and targeted
  mutations. Check all 42 owned records exact and historical record hashes unchanged.
  Commit this bounded repair before e1d stages any new corpus/count records.


### Owned e1d provenance prerequisite

`rg -n 'floating-point corpus|P4-SYSTEM.7' scripts/derive_rv64gc_expectations.py`
locates emit's fallback: non-family generic/C/Sv39 source names receive an FP-corpus
header. No such new production record is adopted here; prior outputs keep provenance.
Before publishing the staged C corpus/counts, e1d must derive an explicit correct
family/provenance header and guard generic/C text, while preserving the 42 historical
owned records. Schedule as high priority within e1d, before its first authored record.


## Closed e1c1 cache design

- `2026-10-08` (e1c1 execution plan, before changes): derive the declared four-slot,
  fully associative FIFO cache independently from state.sexp's selected policy and
  pinned supervisor 11.1.2.1/11.1.3.2/11.1.4.1. Cache successful 4-KiB translations
  with ASIDLEN=16, inherited G and leaf permissions; recheck live mode/SUM/MXR/MPRV
  before hits, retain cached A/D, and never install a fault. M/Bare bypass and satp
  root/ASID changes do not implicitly flush. Hits do not refresh FIFO; fences retain
  the replacement cursor and select x0 identity, masked ASID and canonical page.
  Hand PTE/physical-address fixtures, all four zero-operand fences, inherited globals,
  FIFO, stale permissions, fault non-installation and cold repeat must discriminate
  targeted mutations and the uncached parent. Repair direct permission fixtures that
  rewrite PTEs to execute a real legal full fence before requiring a fresh view; retain
  their existing negative controls. Census all 139 parcel architectural traces and
  all 121 historical word texts. The known erroneous unadopted sv39-tlb-fence word
  output may change to the pinned policy; investigate every other difference. Keep
  all 42 owned records byte-exact, and write no expected record or profile binding.
  Document the author cache and its provenance without claiming CPU acceptance.
  Archive-family pressure is now a resumption dependency: 211 files / 781,740 B
  leave 4,692 B, while the oldest required head records total 4,628 B before shard
  headers/manifest. Route the measured lifecycle defect to LIVE-CONTAINMENT.4;
  record its retrieval options and exact evidence before any migration. One DEV_NOTES
  shard and a concise changelog summary can finish this slice without a cap increase.


## Closed e2c binding design

- `2026-10-09` (e2c atomic bind, before changes): bind the production C fragment,
  complete status, staged 28 guest source/expectation pairs and run-order entries,
  and the independently staged 139 historical extents together. Use the shared
  direct-field transformer; assert every other historical byte/source unchanged.
  Regenerate the rv64gc definition/guest modules through their owners and derive
  scope/coverage (expected 200 spellings, including three existing pseudo forms).
  Add REQ-GC-C / OB-GC-C and the two-byte environment-fetch assumption to open v2;
  realize every new POS/NEG check, preserve all frozen v0/v1 records and pins, and
  leave v2 open for .13. Map all new guests into the existing seven-axis matrix,
  replacing the boundary/restart degeneracy with compressed trap/resume evidence.
  Run focused corpus/contract checks, make check for generated Rust, doctrine gates
  and books; matched Sail follows as its own slice before closing .12. CPU-SYSTEM
  remains incomplete on its other axes. Retain parent/new engine identity evidence
  for historical writes and fault PCs, counts differing only as derived; new C
  guests must discriminate the unbound parent. Review/update the affected book and
  dossier/current gate records, generator comments and count-cap projection.
  Owned documentation defects found during this interface review: DOSSIER.md claim
  scope and 'not have yet' still describe the unregistered resolution despite the
  tracked implementation; P4 overview likewise says unregistered/no FP/M unbound,
  and its C frontier stops at d3d0. Reproduce by those phrases versus current files
  and registry; impact is the director's inaccurate review surface. Fix those current
  claims in this bind, retain explicitly dated historical selection decisions, and
  link the generated report for the remaining limits. Initial generation refused
  the new c_compressed group because the closed profile grammar/mapping had no C
  scope family; extend both together and verify schema plus lossless round-trip
  before regenerating the fixture. The interim Rust check correctly rejected its
  still-old fixture counts/missing C guests, not a processor observation change.
  Extraction then refuses all 37 C forms: its semantic census visits only sem,
  never expand. Own the integration fix here: count expansion rows only after the
  existing SEM composition validator accepts their base/bindings; retain duplicate
  checks and add valid/missing-base/unbound/unknown-mapping controls. No new checker
  or bypass of the semantic authority. The real mirror stale-control's old setup
  now fails at a copied rv64i observation, not the stale-exception predicate
  (stale-control-before.log). Restore the current count for its clean pair and use
  the comment-only dir-selfmod-fence exception with independently verified extent;
  require the actual stale-normalization reason. Gate manifest's G-SCOPE text
  also says no C fragment exists although definitions/riscv/c.sexp is tracked; remove
  that resolved open item at the complete bind and regenerate reports.
  PROFILE-CONSISTENCY also refuses PARTS DRIFT (52 + 111 != 200): its
  closed extension-family sum omits c_compressed despite the updated loader.
  Own the matching census extension and good-C/wrong-part controls before signoff.
  Wire the Python extraction controls into the registered shell gate; otherwise
  its new expansion refusals would run only by explicit invocation.
  Final registry census (git ls-files materials/units.sexp docs/models) confirms
  RV64GC is still unregistered and has no per-unit book. The draft's contrary
  claim was wrong and is corrected before commit. Own registration/category
  dispositions and its dedicated book at .14, before evidence promotion/signoff;
  the project P4 chapters remain the current review surface.




`P4-SYSTEM.12` slice (e2c) — atomic C binding (`2026-10-09`, `SEMULITH-P4-0102`):

- [x] **ROOT CAUSE** — git show a909ad8:profiles/rv64gc-lab-v0/encoding.sexp
  composes no C; source/scope/contract are not yet
  bound. Stage expectations before running the changed engine. Generator first
  refused the missing c_compressed grammar, extraction omitted expand rows, and
  PROFILE-CONSISTENCY omitted C in its part sum; real mirror stale control failed
  at an unrelated copied observation. Each reproduced and repaired at its owner.
- [x] **ADDRESSED** — compose C complete, 197 instructions/three pseudos; adopt
  all 56 staged source/record files byte-exact, 28 run-order entries, and 139
  independently derived count changes (4,888 words -> 9,770 parcels at 4,913
  boundaries). REQ-GC-C, OB-GC-C and exact parcel supply join open v2; four checks
  realized. Registry 20/106; frozen v0/v1 records/pins unchanged. All C guests
  join the seven-axis matrix, replacing boundary/restart degeneracy (two remain).
  python3 scripts/gen_definition.py / gen_guests.py rc=0; both modules regenerated.
  Extract expansions through existing
  SEM composition validation; four controls discriminate. Good-C/wrong-part
  census controls pass. Stale mirror control requires its intended refusal reason.
- [x] **NO REGRESSION** — make check rc=0 (core 153, verify 193); all 167 directed
  guests and registry entries pass. Parent/current CLI traces for all 139 old
  guests are byte-identical (PC, mode, GPR writes); all source and non-count record
  bytes exact. Five new public-CLI C traces discriminate the unbound parent.
  GUEST-GEN 127/127; coverage/extraction 200/200; CONTRACT-FREEZE and dossier
  consistency pass. Evidence logs: target/p4-system-12/e2c/. Full doctrine hook
  and books enforced at commit. Project arms 626; unrelated scalar/state modules
  unchanged. Attempted full gate with a temporary index was invalid: nested Git
  self-tests replaced that disposable index; real index SHA-256 stayed exact.
  Run the full gate at the normal staged commit boundary instead.
- [x] **LOCKSTEP** — current dossier/environment/P4 overview/C chapter repaired,
  report regenerated: G-SCOPE green, CPU-SYSTEM incomplete on 8/10 axes. Live
  P4 stays 11/18; matched Sail e2d precedes leaf closure. Closed notes/receipts
  moved verbatim to archive part 6, reconstruction asserted, fixed caps retained.
  promotion: declined (schema/semantic/census/byte/control checks retain the rule).


## Closed live-head records at C signoff (2026-10-09)

The following sections retain the original live-head bytes and link coordinates
from `docs/tasks/P4-SYSTEM.md`; historical implementation observations are records,
not authority to depend on submodule internals. Current integration uses public contracts.

## Decisions

- `2026-10-09` (e2e final C signoff, before checks): run the named make ci suite
  over committed 190d16b plus this owned signoff record. Review .12's acceptance
  against pinned expansion declarations, compiled component controls, complete
  composition/scope/corpus, precise second-parcel trap and the public Sail result.
  Retain the timer platform limit; CPU-SYSTEM does not become passed. Close .12
  only after every required CI leg passes. Archive closed C planning/receipts/logs
  verbatim as needed to make .13's active frontier concise and resumable, retaining
  all future owners and fixed bounds. Update P4 to 12/18, book and resume pointer;
  commit this signoff before activating .13. Do not push below authorized cadence.

- `2026-10-09` (e2d matched Sail, before experiments): exercise all 28 committed
  C guests through scripts/run_rv64gc_sail.py and the dossier-digest-verified public
  Sail binary/config. Keep each guest result, two fresh repeat traces, input hashes
  and the complete declared observation budget. Do not change expectations to fit
  a reference. Plant an independently wrong expected register value and require
  DIVERGE. Derive which of the 37 C forms execute in the matched subset. Investigate
  every refusal/disagreement through public inputs/outputs before classifying it;
  the known timer-platform boundary is a hypothesis to measure, not a waiver.
  Own adapter defects here with permanent negative controls before acceptance.
  Preserve the production sources/expectations and engine modules unless a measured
  defect requires a separately owned repair. Update the reference dossier, C book,
  gate digest and live frontier; commit this slice before leaf signoff/full CI.
  Current references.sexp contains implementation-based Sail assertions (timer
  internals, wait-exit placement and source comments), contrary to the director's
  read-only-black-box boundary. Remove those dependency assumptions when recording
  this public-interface experiment; retain measured outputs, configuration limits
  and provenance. Schedule the wider maintained-knowledge/plan assumption sweep
  at .14 before evidence promotion; archived history is not integration authority.
  Initial public runs: 27 AGREE, c-irq DIVERGE at boundary 9. Its parcel
  derivation says 'pending interrupt 5 delivers...', which the adapter's legacy
  label-only regex cannot recognize. Reproduce with that annotation plus a
  witnessed timer event: missing-step refusal. Extend only the two declared
  spellings, preserve cause matching, and add positive/missing/wrong-cause/row
  controls plus a mutation disabling parcel annotation support. Confirm the timer
  platform root with a public stimecmp/mip probe and repeat the unchanged corpus.
  Track that seven-boundary live diagnostic as probe_gc_sail_timer.py so its
  source, independently derived expectations, public validation variants and two
  fresh trace runs can be reproduced after ignored artifacts are lost. Reuse the
  existing pin, path, assembler, author and trace owners; no submodule inspection.
  The new live-probe row pushes docs/toolbox/definition.md to 16,576 B, over
  its fixed 16,384 B part cap. Split guest-author/staging/Sail rows verbatim into
  guest-evidence.md and link it from the bounded TOOLBOX index; assert every row
  retained exactly once, rather than raising the ceiling.


- `2026-10-08` (e1c discovery / ownership, before changes): pinned supervisor.html
  2046–2080 selects SFENCE scope from rs1/rs2 register identities, including nonzero
  registers holding zero and ASIDLEN-masked zero. The production semantic operator
  passes only values; translation::Tlb::invalidate branches on va==0/asid==0. This
  loses identity and may over-fence even though the declared policy rejects that latitude.
  e1c0 first reproduces through the public evaluator with seeded cache entries and
  hand words, then carries explicit all-address/all-ASID selectors in the semantic data
  and typed cache interface, updates all call sites and documents the corrected contract.
  Add permanent parent/mutation controls for zero-valued nonzero operands and invalid VA;
  maintain ordinary x0 fences, legality and existing corpus. Finish/commit this bounded
  repair before e1c1 derives independent FIFO/cache/permission/global/fence behavior.
  `cargo test -p semulith-core translation::tests::fence_nonzero` on c413dd3 + new
  tests fails 0 passed / 3 failed: all entries removed, versus independently specified
  retention vectors. History e839c1b (SEMULITH-P4-0018) introduced the value-only contract;
  frozen .3 evidence is superseded by this receipt. Its end-to-end raw words also encode
  wrong registers, and the second leg translates while still M so installs nothing.
  Repair those fixtures with pinned-assembler-confirmed words and a pre-fence occupancy
  assertion. Carry explicit optional scopes: None is x0, Some(0) is a real zero selection.
  Semantic data supplies four arguments (values plus identity flags), rejecting old arity.
  The new arity made four DEF-GEN literal sed injections no-ops; the gate correctly
  refused (51 pass / four fail). Before commit, replace the disposable AST effect
  structurally with exactly-one-match assertions, retain all four negative arms, and
  add an obsolete two-argument arity refusal arm. This repairs the dependent fixture
  seam rather than weakening discrimination. No engine result becomes an author
  expectation. The new finding was surfaced in chat. Archive the closed .10 design
  verbatim if the live task exceeds its fixed bound; assert reconstruction and retrieval.

- `2026-10-08` (e1b2 execution plan, before changes): register the selected
  mcounteren/scounteren/menvcfg addresses and their declared CY/TM/IR, read-only HPM,
  WPRI and STCE legalization. S stimecmp read/write needs TM and STCE before effects;
  M bypass and U address privilege remain intact. Existing counter gates keep values
  moving while inaccessible; writable counter rebasing remains an explicit vocabulary
  refusal outside these guests, rather than a guessed storage model. Reuse a public
  canonical quoted-string renderer for author emission (all prose/source/program strings),
  removing the parcel directive's quote/backslash refusal. Hand mode/gate/mask/alias and
  escaped-text/schema fixtures, targeted mutations and all 139 runs precede adoption.
  Preserve all 121 prior word outputs/42 owned records; three repaired guests' committed
  architectural writes are regression controls. If live histories cross their fixed caps,
  use shard_history.py with its byte/order proof and freeze manifest, never raise bounds.

- `2026-10-08` (e1b bounded split, before changes): e1b1 fills base integer rules:
  immediate/register comparisons and XOR, XLEN/word shifts, signed/unsigned branches,
  and narrow memory stock derivations. Add an explicit ReservedInstruction subtype for
  independently identified reserved word-shift bits; the parcel route alone converts
  that named result to the declared diagnostic. A generic unknown Refusal must remain
  a refusal. e1b2 handles remaining CSR enables/counter rules and escaped directives.
  Both retain the prior historical outputs and owned records, and audit all 139 parcel
  traces before any count adoption. The unknown-valid control moves from XORI (newly
  supported here) to the still-unmodeled but real mvendorid CSR, rather than dropping
  the discriminator. Hand boundary/alias/shift-width/branch/memory/reserved fixtures and
  targeted mutations must discriminate. Cached-translation disagreement remains e1c.
  If the receipt crosses the fixed live bound, archive completed e1a and closed .11
  design/split verbatim, assert reconstruction, and retain their retrieval pointers.

- `2026-10-08` (e1 census findings / ownership, before repairs): explicit parcel runs
  over all 139 records give 113 exact architectural traces, four numerical disagreements
  and 22 named refusals (target/p4-system-12/e1/parcel-census.json). Root inspection:
  mm-readonly writes misa=1 because the author has neither its fixed reset nor read-only
  fields; mm-sfence lacks S+TVM satp/SFENCE checks and U SFENCE illegality; mm-sret lacks
  U/TSR legality, so it loops through a forbidden return instead of the handler. The
  sv39-tlb-fence guest sees freshly written PTEs because Hart.walk always walks while
  SFENCE only emits prose claiming a cache flush. These are accepted-input author defects,
  not newly demonstrated production CPU defects. Fix immediately before count adoption:
  e1a fixes CSR/privileged legality and fixed misa with permanent direct/corpus mutations;
  e1b fills the bounded base/CSR vocabulary named by 22 refusals (safe string emission
  included); e1c models the declared translation cache/invalidation policy independently.
  Each gets its own verified commit. Then e1d stages the C corpus/counts and e2 binds.
  The four disagreeing guests' committed spec-derived observations are reproducible
  regressions; source-line/guard locations and matched counts belong in each receipt.
  Preserve all 42 owned records and old production fixtures throughout prerequisites.

- `2026-10-08` (e1 staging plan, before experiments): census all 139 historical guests
  on the explicit parcel author using each record's already-declared boundary count.
  Compare every architectural write to its prior specification-derived record and
  enumerate actual requests; do not infer new counts from engine outputs. Unknown
  vocabulary or any numerical disagreement must be investigated and owned before the
  count can be used. Split a bounded author prerequisite into e1a if this census needs it.
  Then generate an independently authored C corpus covering all 37 forms, limits/hints/
  reserved points, mixed lengths/links and translated straddles before any engine run.
  Keep staging regenerable from tracked sources/producers under target/p4-system-12;
  tracked production guests/counts/profile bind together in e2. The old unit and both
  generated modules must stay exact through this staging work. The resulting permanent
  staged-corpus probe must discriminate wrong observations/extent before binding.

- `2026-10-08` (d3d2 execution design, before changes): add an explicit parcel route
  (`--parcels --steps N`) and API whose positive bounded budget controls every boundary,
  including source run-off, delivered faults, pending interrupts and halted ticks. The
  historical word route/42 owned records remain byte-exact; parcel mode cannot select
  that owned corpus until its count provenance changes at C binding. Load exact sized
  units into the declared region, fetch memory afresh every step, key annotations by
  each unit's byte PC, and count actual parcel attempts. Source end markers cannot
  shorten an explicit budget. Unknown valid vocabulary still refuses; only independently
  known reserved C parcels/wider prefixes become the laboratory illegal diagnostic.
  Expose the resulting hart/steps for finite offline probes. Repair/audit the five owned
  legacy fetch/end gaps using caller budgets declared before experiments: dir-runoff 3,
  fault-fetch 3, it-prio-jump 4, sv39-straddle 52 and sv39-perm-rwx 114. Derive writes from
  spec-side state; legacy records supply previously declared scope/count, never engine
  outputs. C changes fetch extent legitimately, so compare architectural observations
  separately from new parcel counts. Do not overwrite historical records in this slice.
  Permanent controls must reject word-stride directives, padded/self-modified images,
  premature source termination, wrong fetch counts, fault retirement, fetch-before-head,
  or swallowing an unknown valid instruction. Correct the assembler book's old upcoming
  C/fetch sentence as part of this integration's lockstep update.

- `2026-10-08` (d3d1 EPC defect, before repair): the new odd-PC fetch fixture
  returns fault (0, 0x80000001), but Hart.deliver stores mepc=0x80000001 rather than
  0x80000000. Pinned machine.html 2951 and supervisor.html 1131 require EPC bit 0 always
  zero; bit 1 stays usable under IALIGN=16. Tool pinpoint: all four exception/interrupt
  EPC assignments store self.pc directly, bypassing the CSR-write mask used elsewhere.
  Own/fix immediately with this fetch slice; permanent M/S/interrupt odd-PC fixtures
  and an unaligned-EPC mutation discriminate. The 42 historical outputs must stay exact.

- `2026-10-08` (d3d0 containment dependency, before repair): sharder output reports
  DEV_NOTES 49127 B cut at --max-bytes 40960, below its 49152 B ceiling, but the new
  header says it crossed the 48-KiB ceiling. The script explicitly permits an earlier
  target; its fixed SHARD_HEADER and two self-test expectations misstate that event.
  Own/fix this small reporting defect with the slice's necessary containment: new headers
  state the governed bound without asserting a crossing; existing self-tests must fail
  on the old producer then pass. Regenerate only this new, uncommitted shard from the
  exactly reconstructed head; frozen prior shards retain their original historical text.
  This record supersedes their blanket crossing wording for preemptive target cuts.

- `2026-10-08` (d3d0 owned ILEN defect, before changes): while specifying the
  independent fetch route, pinned intro.html 1148–1153 and machine.html 3427–3450
  require an all-ones illegal instruction to be ILEN bits long and a nonzero illegal
  tval to carry min(actual length, ILEN, MXLEN) bits. ILEN=32 here. The C evaluator's
  fetch_instruction short-circuits low-five-bits=11111 after only 16 bits, so it returns
  ReservedDecode { word: 0xffff } for a full 0xffffffff and never requests the second
  ILEN parcel. That also suppresses a required upper-parcel access/page fault.
  Priority immediate: d3d0 fixes this before d3d1 adopts independent fetch evidence.
  Extend the permanent C engine probe with unsupported-prefix/all-ones ILEN images
  and an upper-parcel refusal; first demonstrate RED on b48201c. Fetch at most two
  parcels for any wider prefix; illegal diagnostics retain all available ILEN bits.
  A short-ILEN mutation must discriminate. Production C stays unbound; no submodule
  touched and old corpora unchanged. Then resume the already-owned d3d1 walker/fetch.

- `2026-10-08` (d3d split / owned walker defects, before changes): d3d1 adds a
  memory-backed parcel fetch primitive and repairs the reused spec-side Sv39 walk;
  d3d2 then adds explicit run budgets and byte-addressed guest execution/directives.
  Tools reproduce four author defects: Sv39 VA 0x4000000000 (bit 38=1, upper bits 0)
  translates instead of page-faulting; leaf PTE bit 63 translates with Svnapot absent;
  a pointer at level zero raises author Refusal rather than an architectural page fault;
  MPRV+MPP=S leaves an M-mode data load physical. Fetch correctly ignores MPRV.
  Priority: immediate d3d1, before reusing this walk for C fetch evidence. Also test
  all reserved high PTE bits and non-leaf U/A/D bits required by the same pinned rule.
  Reproduction: Hart fixtures call walk with one 1-GiB leaf at ENTRY or a self-pointing
  chain; no CPU engine supplies answers. Pinpoint: walk's sign test checks upper bits
  without bit 38, extracts PPN without reserved-bit guards, always shortcuts M mode,
  and falls through the three-level loop into Refusal. Pinned supervisor.html 2660,
  2695, 2930 and 2986–2996; machine.html MPRV paragraph gives effective data privilege.
  Log permanent reproductions in the new offline fetch probe; audit the 42 owned records
  and all prior emitted texts. Instruction fetch walks each necessary 2-byte parcel,
  logs actual fetch/walk requests, counts refused requests but never a failed translation,
  preserves start EPC and failing-parcel tval, and never probes a compressed neighbor.
  Request/refusal log fixtures and mutations discriminate these properties. Legacy
  word authoring stays unchanged until d3d2 integrates the new path explicitly.

- `2026-10-08` (d3c legacy audit): all 91 previously emitted texts remain exact.
  New base JALR vocabulary emits six older guests; numeric writes agree on every common
  step. dir-chase, guest-control and fault-jalr-mis have exact counts/observations.
  fault-fetch stops at 2 instead of 3 steps, it-prio-jump at 3 instead of 4, and
  sv39-perm-rwx at 108 instead of 114 (fetches 108 instead of 113). These reproduce the
  already-owned source-map/end and untranslated-fetch limitations. Add their names to
  d3d's immediate repair corpus alongside dir-runoff and sv39-straddle; no existing
  expectation is overwritten and they do not join the 42 owned check records yet.
  Details: target/p4-system-12/d3c/new-legacy-observations.log and legacy-census.json.
  Diagrams are linked under https://docs.riscv.org/reference/isa/v20260120/unpriv/_images/:
  quadrant 0 diag-1f91aa9c4226801a769871aec6df542e2f647a16.svg;
  quadrant 1 diag-ac100c399208ef3eb92487b098c395e35d378dbf.svg;
  quadrant 2 diag-8418563ff7fdb02d02c93d904f77a522a33c22e2.svg.

- `2026-10-08` (d3c inputs/baseline): the pinned RVI-C HTML links the public
  v20260120 SVG listings; downloaded only those three into the task's on-volume spec
  directory (the HTML cache deliberately holds chapters, not linked images). SHA256:
  quadrant 0 7401e1c7d12223a1a92ad08b099185ab0c6a70e4e5bc643601eb847d9e3cf069;
  quadrant 1 8e1cf89de48172d3fb024bacd4abd281441f8568bbedd31a62a49d5ba2f5b27b;
  quadrant 2 8ab4b043d63f0c01920c60cdd159ce8d12b37acda68cb3054081f97508761ca4.
  XML text extraction pins scattered fields against the diagram's bit-index row.
  before.log: execute_c absent; C.LI parcel 0x5081 and the five needed base shapes
  refuse. The unused ADDIW stock locator said 3.1.2.2, but its pinned operation sentence
  is in 3.1.2.1 (rv64.html 542–545); repair that locator with the new implementation.

- `2026-10-08` (d3c design, before changes): implement a separate spec-side RV64C
  parcel decoder in scripts/spec_c.py. Its field reconstruction and expansion words are
  hand-authored from the pinned RVI-C 27.1 prose/format diagrams, without importing the
  engine, generated definition, c.sem.sexp or assembler maps. Retrieve the three SVG
  instruction listings linked by the pinned HTML into target/p4-system-12/d3c/spec;
  record their digests as working-input evidence. Add execute_c to the tracked author:
  reserved parcels deliver cause 2 with original 16-bit tval; ordinary expansions reuse
  spec-side base rules with an explicit instruction length. C.JALR reads the old source
  before its pc+2 link write. Complete only the missing base forms required by C:
  SRAI, ADDIW, ADDW/SUBW and JALR, with fixed-bit guards. Keep the existing word author
  route and all 42 owned outputs identical until d3d introduces parcel fetch/budgets.
  A permanent offline probe checks all 37 hand-word expansions, signed/scattered extrema,
  hints/reserved specialization, integer/control/memory/FP effects and original trap bits;
  compact-register, signed-immediate, link-length and reserved-guard mutations must fail.
  This is component evidence; full compressed guest authoring and binding remain d3d/e.

- `2026-10-08` (d3b adapter design, before changes): keep the public Sail 0.14 trace
  protocol and the corpus's change-observation comparison, but require every ordinary
  expected row (including empty-write instructions). A missing row is allowed only for
  a predeclared interrupt-delivery derivation or a <fetch ...> expectation AND a matching
  trace event at that number; event spelling is mapped to architectural cause from the
  pinned exception/interrupt table. Unknown/malformed/duplicate/out-of-order records refuse.
  Failed reference processes and missing/stale output refuse; each run removes only its
  own prior trace path before launching. Build the exact assembler byte image through
  the tracked ELF writer's public API, eliminating the scratch builder's clang/zig path
  assumptions. Verify the binary's dossier digest and materialize the tracked override.
  The runner's verdict is about declared change-observations, not unrecorded state.
  Component controls are offline; live M re-run and trace-reproduction use the acquired
  binary. Its measured instruction-limit completion returns rc=0 (m-div, limit 29).
  Trace audit: 95 cached corpus traces inspected, including the nested Sv39 directory;
  79 are from AGREE-claimed cells after excluding the dossier's named not-matches. None
  misses an ordinary expected row; nine numbered interrupt deliveries and one explicitly
  declared fetch-page-fault step have matching trace events instead. Sixteen cached
  not-matched cells retain their named limitations. This audit addresses absence only;
  old process statuses were not retained, so re-running selected M cells verifies status
  and observations on the new route. Cached audit rows: target/p4-system-12/d3b/.

- `2026-10-08` (author observation audit, before permission repair): 88 of 91 emitted
  legacy derivations agree with committed step/write/fetch observations; 49 text differences
  are mostly original authoring prose/format. Three numerical mismatches were investigated:
  dir-runoff intentionally expects the implicit zero instruction after the payload, while
  the tool stops at source end; sv39-straddle runs translated code outside its source map,
  while this tool has no fetch translation; both are explicitly owned by d3d's fetch/budget
  work before C evidence. sv39-perm-usr differs at step 120: the producer rejects an S load
  from U=1 with SUM=1 and ignores MXR. The pinned supervisor.html lines 650–670 and
  2478–2490 require those permissions, matching the committed guest. Fix these small data
  permission omissions in d3a, including U-mode's U-bit requirement; direct PTE fixtures
  check SUM data/fetch separation, MXR and U-mode. Re-measure the affected legacy output
  against the committed observations; the 42 owned byte-identical records must stay exact.

- `2026-10-08` (author census, d3a): the existing producer regenerates 42 committed
  expectation documents byte-identically; 49 other derivations differ and 48 guests refuse
  (139 inspected). Retain the 42 as the explicit owned check corpus; compare all 91 emitted
  before/after texts during promotion without overwriting a record. Older incompatible
  programs are outside this producer's current vocabulary, not newly authored evidence.
  `execute(Hart(), 0x04000033)`, 0x04001013 and 0x04004033 all accept reserved upper bits
  as sub/slli/xor. Land narrow independent fixed-bit guards now; add misc-mem's reserved
  funct3 guard and turn unsupported stock mnemonics into named Refusal rather than KeyError.
  The C additions follow after this safe promotion. Baseline outputs/census retained under
  target/p4-system-12/d3-author-{before,census}.json. New checker output reports the owned
  corpus and behavioral controls; the malformed-word cases must refuse before effects.

- `2026-10-08` (d3 execution split, before changes): d3a promotes the existing spec-side
  expectation author with repository-derived paths and a non-writing --check mode, and
  measures its exact corpus of byte-identical re-derivations. The small reserved OP/shift
  guards and named unsupported-mnemonic refusals land here before this producer is exposed;
  C and fetch extensions follow in d3c/d3d. Its unsupported older guests
  remain explicit scope, never a claim that it authored every legacy record. The reserved
  OP/shift over-decode repair carries spec-side controls.
  d3b promotes/repairs the Sail adapter. d3c teaches independent C expansions; d3d adds
  parcel-wise fetch and explicit run budgets (split further if needed); the bound C corpus
  then uses tracked tools.
  Completed .12 (a), (a2), (b) checklists move byte-verbatim to archive/P4-SYSTEM-5.md;
  reconstruction proved identical before editing the live tree. No ceiling changes.
  **Owned Sail comparator defect (priority: before the C matched experiment, d3b):**
  `target/p4-system-12/d3-sail-gap.log` reproduces AGREE for a failed reference, empty trace,
  and one expected ordinary no-write step. compare_sail.py skips any missing row when its
  expected writes are empty and ignores process status. That admits absent evidence. The
  tracked adapter must distinguish an explicitly declared delivery gap from a missing
  ordinary instruction and refuse failed/incomplete reference runs. Audit prior selected
  experiment traces for missing ordinary rows before retaining their conclusions.
  **Owned author over-decode (priority: d3a):** execute's OP branch selects sub for any
  nonzero funct7 with funct3=0 and accepts xor/or/and regardless of funct7; the SLLI branch
  ignores reserved upper bits. Reproduce reserved words against the scratch producer,
  require a named refusal or the profile's declared illegal delivery, and regression-check
  every previously authored record. No C evidence may use the producer before this fix.

- `2026-10-08` (d2 scope before changes): retain the rv64i word fixture/API used by
  replay/reduction and emit rv64gc's exact bytes with an explicit `--image-format bytes`
  configuration. The generator assembles sized units; word mode refuses short units.
  The rv64gc runner loads the byte image directly, preserving trailing parcels and
  32-bit instructions at 2-mod-4 addresses. Compare every old image and expectation
  against a before-change digest census; rv64i's payload remains identical (its generator
  fingerprint necessarily changes). A temporary C composition compiles the generated
  fixture with the tracked runner and checks mixed control flow and the loaded raw bytes;
  padding and runner-offset mutations must fail. Re-state the fetch-count docs as actual
  boundary requests, at most two per step. Production C stays unbound until e.

- `2026-10-08` (slice d split, owned before changes): (d1) the assembler: C fields,
  compact/FP register spellings, grouped scattered immediates, `.half`, byte-addressed
  labels and an explicit sized-unit/byte-image API (the legacy word API refuses short
  units instead of silently padding them). Operand order remains the declared field order,
  with one argument for all pieces of an immediate; C.LUI's argument is its unshifted
  signed six-bit value. The engine probe's words are independent assembler controls.
  (d2) the guest generator and runner's parcel image carrier. (d3) the authoring tool
  and Sail adapter, then their regression. Tool census `rg --files -g '*.py' -g
  '!vendor/**'` finds no tracked rv64gc authoring/Sail runner; the current producers
  live under `target/p4-system-11/{tools,sail}`. Their untracked status is explicit in
  their headers, and the Sail runner's tracked landing was already owed by `.14`.
  Own the authoring producer here too: promote it under `scripts/`, re-derive the old
  corpus byte-identically before extending it, and retain its independent spec-side
  rules. A fresh clone must not need these scratch producers to author the C corpus.
  Commit `e1fe379` passed `make ci` (all five legs) and was pushed at the 300-commit
  cadence; `target/push/last-green.txt` is the boundary's generated evidence record.
  README review found a stale implementation disclaimer: `git blame -L 10,15 README.md`
  dates "No CPU implementation" to the planning-package import `724e422`, before the
  interpreter existed. The current core, CLI and experimental scalar release contradict
  that present-tense statement. Own the correction in (d1)'s documentation sync: distinguish
  experimental implementations from unclaimed conformance/acceptance, preserve the planned
  synthetic examples' status, and remove the unsupported blanket reservation statement.
- `2026-10-08` (PNT resumed; slice c split before changes): (c1) add a typed
  `FetchParcel` request/response and teach boundary providers, counters and injection spans
  its exact two-byte extent; (c2) execute expansions and fetch by length. Diagnostic
  `rg -n 'Request::Fetch|fetch16' crates/semulith-core/src/{env,exec_rv64gc}.rs` shows
  that the existing helper named fetch16 actually requests four bytes. Even its
  page-straddle path therefore reads beyond a parcel. A two-byte region cannot supply
  a legal compressed instruction through that interface. This boundary defect is owned
  here and verified independently of the decoder before execution changes.
  Revise the brief's coalescing choice for the C-enabled table: fetch the first parcel
  exactly, then the second only for a 32-bit instruction. A four-byte speculative request
  cannot distinguish a fault on an unnecessary upper half from a fault on the first half.
  Keeping a one-request count would require a new partial-success protocol without a
  demonstrated need. The unbound production table retains its existing word-fetch route
  until the bind; the bound corpus's parcel counts are re-derived in (d)–(e), and contract
  v2 states the new extent. Register/control-flow identity remains the regression claim.
  The roadmap and leaf acceptance are unchanged; no CPU conformance claim is added.
  Slice (c2) emits length/optional expansion metadata for every rv64gc table (length 4,
  expansion absent while C is unbound); rv64i's table remains structurally unchanged.
  A permanent probe builds a temporary composition with C and compiles the tracked engine
  against that generated table. It verifies exact parcel requests, a second-parcel fault,
  mapped immediate widths, reserved/HINT distinctions, links and FP gating. The temporary
  composition is evidence for the engine, never a tracked unowned generated definition.
- `2026-10-07` (crash recovery, director request): recover the interrupted session and stop at
  the next handoff-ready checkpoint. `git status --short` at `f877726` found five surviving
  files owned by `.12` slice (b): `c.sem.sexp`, `m.sem.sexp`, `schema/semantics.sexp`,
  `check_semantics.py`, `gen_definition.py`. The semantics controls already pass 39/39 and
  C's pair checks 37/37; the generator loads expansions but does not yet emit them or decode
  by specificity. Finish and verify (b), commit it, leave (c) as the precise next action,
  and require `scripts/check_no_background_jobs.sh` to print `handoff: OK` before stopping.
- `2026-10-06` (a found defect, owned before slice (b), `SEMULITH-P4-0080`): reading `extract()` for
  C's scattered immediates found JAL's offset sign taken from bit 19 in BOTH engines (a scattered field
  carried its field width, not its immediate's) — reproduced, fixed and pinned as slice (a2) here,
  because C's `c.j` offset (imm[11:1] in an 11-bit field) would have inherited it; the rv64i release
  decision amended (its recorded evidence unaffected by construction — every result a PASS).
- `2026-10-06` (design brief for `.12`, recorded before its execution, `SEMULITH-P4-0078`;
  sources: a read-only census of the C surface — an explore agent's report, conversation-only;
  every load-bearing fact re-measured where it lives; RVI-C §27.1, RVI-ZC §28.1, the unprivileged
  "Base Instruction-Length Encoding", RVP-MACHINE §2.1.1.16; `exec_rv64gc.rs`;
  `scripts/riscv_asm.py`; the pinned `constants.py`):
  **The measured pre-conditions.** (1) **No C table is on disk or pinned**: `ls
  target/refs/riscv-opcodes/ | grep -c _c` → 0; the ledger pins 17 files, none C. The re-pin is
  the first act. (2) **The selection is 37 forms**: Zca at RV64 (33) + Zcd (4: c.fld, c.fsd,
  c.fldsp, c.fsdsp) — RVI-ZC §28.1.4 "Zca, Zcd if D is specified (RV64 only)"; the five RV32-only
  forms (C.JAL, C.FLW[SP], C.FSW[SP]) excluded; the census grows 163 → 200. (3) **ILEN stays 32**
  (`profile.sexp:25` `(ilen 32) (ialign 16)`): what is missing is instruction LENGTH, not width.
  (4) **The fetch translates both parcels before reading either** (`exec_rv64gc.rs:152-167`): a
  16-bit instruction in a page's last halfword, the next page unmapped, would page-fault today;
  the pc advances by a hard-coded 4 (`:255`). (5) **Upstream marks its constraints in field
  NAMES** (`rd_n0`, `c_rs2_n0`, `c_nzimm6` …), and the pinned `constants.py:16-22` lists six
  overlapping pairs (c.addi/c.nop, c.lui/c.addi16sp, c.mv/c.jr, c.jalr/c.ebreak,
  c.add/{c.ebreak, c.jalr}); the decoder takes the first match in NAME order
  (`gen_definition.py:753`), so c.ebreak's and c.jalr's words would decode as c.add, and
  `check_encoding_disjoint.py` refuses any overlap. (6) **The spec's RVC listings are SVG
  figures** (none on disk); the expansions are per-instruction prose — "C.MV expands into add
  rd, x0, rs2" (§27.1.5.3) — and §27.1.1 states the constraint "each RVC instruction expands into
  a single 32-bit instruction"; §27.1.4 states the one exception, "C.JALR does not expand exactly
  … the value added to the PC to form the link address is 2 rather than 4". (7) **The spec states
  every fault rule C needs**: parcels are 16-bit little-endian, lowest bits first, an
  all-zero parcel illegal ("Base Instruction-Length Encoding"); "no instructions can raise
  instruction-address-misaligned exceptions" (§27.1.1); a fault on a variable-length
  instruction reports "the virtual address of the portion of the instruction that caused the
  fault, while mepc will point to the beginning" (RVP-MACHINE §2.1.1.16); an illegal 16-bit
  instruction's mtval is its 16 bits, right-justified. (8) **Every tool assumes 4-byte
  instructions**: the assembler (`pc += 4`, `.word` only, no C operand), `gen_guests.py`
  (`&[u32]` words), the authoring tool (a 4-byte program map, 37 `pc + 4` sites), the Sail
  harness (`.word`). (9) **Sail's matched configuration already selects Zca and Zcd**
  (`(extension (name "Zca") (supported true))`, Zcd true, Zcf false). (10) The interaction
  matrix's boundary×restart cell is DEGENERATE today for want of a 2-mod-4 mepc — C makes it
  derivable.
  **The design, decided:**
  1. **A compressed form is declared by its EXPANSION, as data** — the constraint §27.1.1 states,
     made the representation: each of the 37 rows names the base instruction it expands into and
     maps its operands by expressions over the C fields (`rd'` = 8 + the 3-bit field; the
     scrambled immediates scaled and extended), with the spec's own "expands into" sentence as its
     quoted source (CITATION-QUOTES verifies it in its section). The engine executes the BASE
     rule over the mapped operands. C.JALR alone has its own rule, citing §27.1.4's exception.
     The acceptance's "proven against the source's expansion table" is then mechanical: every
     row names an instruction the composition defines, and its quoted sentence names it.
  2. **Decode by specificity, and reserved code points declared**: among the rows a parcel
     matches, the one with the most fixed bits wins (c.ebreak > c.jalr > c.add; c.nop > c.addi;
     c.addi16sp > c.lui; c.jr > c.mv) — the six upstream overlaps declared as specializations,
     which the disjointness check accepts where the special row's fixed bits strictly contain the
     general row's. The RESERVED code points are declared from the spec's own sentences
     (§27.1.3.1, §27.1.4, §27.1.5.1–§27.1.5.2, the all-zero parcel) — never inferred from
     upstream's `n0`/`nz` names, because most of those name HINTs, which simply execute their
     expansion (an x0 destination writes nothing).
  3. **The fetch reads a parcel, decides the length, and touches the next parcel only for a
     32-bit instruction** (c1 supersedes the original coalescing choice): translate and
     fetch parcel 0 exactly; parcel 1 is translated and fetched only if bits [1:0] are 11.
     Historical observations stay fixed; counts are independently re-derived. A fault reports the
     second parcel's address in xtval and the instruction's start in xepc. The pc advances by
     the instruction's length; `(inst)` is the instruction's own bits (16 for C). The boundary's
     fetch contract is restated in contract v2 (a parcel-granular fetch the environment answers).
  4. **The tools learn parcels**: the assembler (C operand syntax, `x8`–`x15` for the 3-bit
     registers, `.half`, a byte image); `gen_guests.py` (parcels for rv64gc, rv64i's module
     byte-identical); the authoring tool (an image by halfword, a C expander written by hand from
     the spec's sentences — independent of the fragment's expansion data — and the parcel-wise
     fetch walk); the Sail harness (`.half`).
  5. **Evidence**: an EVD-05 corpus exercising all 37 forms (the 3-bit registers, every
     immediate's extremes, HINTs executing, a reserved code point raising illegal-instruction
     with a 16-bit tval, a 2-mod-4 jump target, 16/32-bit instructions intermixed across a page
     boundary, and the second-parcel page fault: cause 12, xtval pc + 2, xepc pc); Sail matched;
     the boundary×restart cell re-answered with a guest.
  6. **Slices**: (a) the re-pin and the fragment (`c.sexp`: 37 forms, the scatter layouts, the
     declared specializations and reserved points; the disjointness rule); (b) the language for C
     (the expansion construct, its checks, `c.sem.sexp`, the generator's specificity decode); (c)
     the engine (parcel-first fetch, length-aware pc, the expansion executor, the 16-bit `inst`);
     (d) the tools (assembler, guest generator, authoring tool, Sail harness); (e) the staged
     corpus and THE BIND (`(status partial)` gone, scope 200, `REQ-GC-C`, `OB-GC-C` and the fetch
     restatement in contract v2, realized; the matrix; `gate.sexp`; identity proof); (f) the
     straddle-fault evidence, the Sail matched experiment, THE LEAF ACCEPTANCE.
- Closed `.11` design and slice split: [`archive/P4-SYSTEM-5.md`](archive/P4-SYSTEM-5.md),
  moved byte-verbatim at the e1b1 containment crossing; use `.12` above for current scope.
- Closed `.10` design: [`archive/P4-SYSTEM-5.md`](archive/P4-SYSTEM-5.md),
  moved byte-verbatim at the e1c0 crossing; the active `.12` plan is above.
- `2026-10-05` (design brief for `.7`, recorded before its execution, `SEMULITH-P4-0038`): archived verbatim to
  [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at the `.8` design
  brief's crossing (`2026-10-06`, `.7` closed; the ceiling was obeyed, not raised).

- `2026-10-05` (design brief for `.6`, recorded before its execution, `SEMULITH-P4-0034`): archived verbatim to
  [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at the `.8` design
  brief's crossing (`2026-10-06`, `.7` closed; the ceiling was obeyed, not raised).

- `2026-10-05` (design brief for `.5`, recorded before its execution, `SEMULITH-P4-0029`): archived verbatim to
  [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at the `.8` design
  brief's crossing (`2026-10-06`, `.7` closed; the ceiling was obeyed, not raised).

- `2026-10-04` (design brief for `.4`, recorded before its execution, `SEMULITH-P4-0022`):
  archived verbatim to [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at
  this file's thirteenth per-part ceiling crossing (`2026-10-05`, the leaf closing; the
  ceiling was obeyed, not raised — the `.2`/`.3` briefs' pattern).

- `2026-10-03` (design brief for `.3`, recorded before its execution, `SEMULITH-P4-0014`):
  archived verbatim to [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at
  this file's seventh per-part ceiling crossing (`2026-10-04`, `.4` slice (a) landing; the
  ceiling was obeyed, not raised — the `P2-SCALAR-designs` precedent).

- `2026-10-03` (design brief for `.2`, recorded before its execution, `SEMULITH-P4-0003`):
  archived verbatim to [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at
  this file's sixth per-part ceiling crossing (`2026-10-04`; the ceiling was obeyed, not
  raised — the `P2-SCALAR-designs` precedent).

- `2026-10-02` (design brief for `.1`, recorded before its execution, `SEMULITH-P4-0001`):
  archived verbatim to [`archive/P4-SYSTEM-designs.md`](archive/P4-SYSTEM-designs.md) at
  this file's sixth per-part ceiling crossing (`2026-10-04`; the ceiling was obeyed, not
  raised — the `P2-SCALAR-designs` precedent).

- `2026-09-13`: the default RISC-V Linux route runs compatible **M-mode firmware providing
  selected SBI services** before an S-mode kernel. A host-modelled SBI is a different contract
  and is never silently substituted (`ROADMAP.md` §P6) — which constrains what this profile
  must implement.

## Acceptance Checklist (filled per leaf at execution time)

Completed checklists live verbatim in the archive — the per-part ceiling was obeyed,
never raised, at every crossing. The index:

- leaf `.1`, `.2` (all slices + LEAF ACCEPTANCE), `.3` (all slices), `.4` slice (a) →
  [`archive/P4-SYSTEM.md`](archive/P4-SYSTEM.md) (crossings 1–7).
- `.4` slices (b)–(f), `.5` slices (a)–(d), `.6` slices (a)–(c), `.7` slice (a) →
  [`archive/P4-SYSTEM-2.md`](archive/P4-SYSTEM-2.md)
  (8th — the archive split — 9th–13th, 15th–23rd).
- part 3 opened at the `2026-10-06` `.7` slice-(c1) crossing (part 2 at its own
  ceiling): [`archive/P4-SYSTEM-3.md`](archive/P4-SYSTEM-3.md) — the closed leaves'
  changelog entries and Commit Log rows (the (c5) crossing), and `.7` slices (b)–(c3)
  part 2 (the (d2) crossing), (c4)–(c6) (the (d5) crossing), and (d1)–(e3) — `.7`
  complete — (the `.9` slice-(d) crossing).
- part 4 opened at the `2026-10-06` `.11` design crossing (part 3 near its ceiling):
  [`archive/P4-SYSTEM-4.md`](archive/P4-SYSTEM-4.md) — `.8` slices (a)–(e); `.9` (a)–(d) and `.10`
  (a)–(c) at the `.11` slice-(d) crossing; `.11` (a)–(d) at the `.12` slice-(c1) crossing.
- part 5: [`archive/P4-SYSTEM-5.md`](archive/P4-SYSTEM-5.md) — `.12` (a), (a2),
  (b), (d1)–(e1c0), plus closed `.10` design and `.11` design/split, moved byte-verbatim
  as completed records leave the live head.

### ROUTING EVIDENCE — archive pressure to `LIVE-CONTAINMENT.4`

`python3` census: docs/changelog 784,318 / 786,432 B, CHANGELOG 65,528 / 65,536 B,
oldest changelog record 2,377 B. A next normal cut cannot fit, independently of guest
vocabulary/cache semantics. Earlier e1c0 failed at 787,026 B and reconstructed only
uncommitted shards; repeating summary trimming would retain the scaling term. The
receiving `.4` goal already owns the guide's complete route/lifecycle inventory; its
old append-history non-goal incorrectly assumed sharding solved aggregate growth.
Corrected that scope and scheduled a finite lossless archive transition before e1d.
The read-only-source prototype authenticates every member; live removal/checker edits
await direction because the guide's lifecycle stop condition changes direct browsing.

`P4-SYSTEM.12` slice (e2d) — public-interface Sail evidence (`2026-10-09`, `SEMULITH-P4-0103`):

- [x] **ROOT CAUSE** — the committed 28-guest corpus runs through the pinned
  public reference. Initial results 27 AGREE, one c-irq DIVERGE rc=1 at boundary 9.
  A parcel interrupt annotation with a witnessed STI event raises missing-step
  refusal in the parent adapter (legacy label spelling only). This is an adapter
  defect, separately from the measured timer supply. No expectation is fitted.
- [x] **ADDRESSED** — scripts/run_rv64gc_sail.py now recognizes both exact
  author spellings with the same required cause/event. scripts/probe_gc_sail.py
  rc=0: matching parcel event, absent/wrong event and an instruction row discriminate;
  disabling parcel support rc=1, named missing step. Existing four mutants retain
  their refusals. New live probe_gc_sail_timer.py derives seven boundaries before
  Sail: stimecmp reads 0, mip reads 0 twice versus laboratory 32; two fresh traces
  exact. Public validator: baseline valid; Zicntr alone has no time source, CLINT
  toggles have no mapped CLINT region. This proves the declared platform difference
  without submodule implementation access or adding a device to force a match.
- [x] **NO REGRESSION** — all 28 rerun: 27 AGREE / 412 boundaries, two traces
  byte-identical each; all 37 selected spellings present in actual Sail rows.
  c-irq remains named platform difference at 9 (a row instead of STI delivery).
  Fresh public run with wrong C.LI expected value DIVERGE, rc=1, first boundary.
  GUEST-GEN 128 pass / 0 fail; 627 registered arms. Corpus, expected values,
  generated Rust and frozen contracts unchanged from 2611340. Live diagnostic
  rc=0; artifacts target/p4-system-12/e2d/. No new Rust; full CI at e2e signoff.
- [x] **LOCKSTEP** — ninth experiment recorded in matched_scope; structured
  evidence remains .14's. Removed implementation-derived reference assumptions,
  retained public observations/configuration limits and explicit GPR-only scope.
  Book/dossier/toolbox/doctrine/gate/live frontier updated; CPU-SYSTEM incomplete,
  P4 11/18. Closed e2c plan/receipt archived verbatim, reconstruction asserted;
  fixed caps retained. Toolbox: 21 rows moved verbatim into guest-evidence.md,
  bounded index updated, every row retained once. .14 owns registry/book and the
  wider black-box assumption sweep.
  promotion: declined (tracked public diagnostic and negative controls retain it).

Completed e1c1/e1d0/e1d1/e1d2/e2a/e2b/e2c receipts and pre-bind designs: [`archive/P4-SYSTEM-6.md`](archive/P4-SYSTEM-6.md).

## Verification Log

Every closed leaf's rows live verbatim in [`archive/P4-SYSTEM-2.md`](archive/P4-SYSTEM-2.md):
`.1` and `.2` (14th crossing), `.4` and `.3` (16th/17th), `.5` (18th), `.6` (19th —
`2026-10-05`, the `.7` design brief landing). The ceiling was obeyed, never raised;
only the ACTIVE leaf's rows stay inline below.

| Date | Leaf | Checks | Result |
| --- | --- | --- | --- |
| `2026-10-09` | `.12` slice (e2d) | Sail 27/28, 412 boundaries, 37 forms; timer public probe; wrong value/annotation RED; GUEST-GEN 128 | measured matched subset; full CI/signoff next |
| `2026-10-09` | `.12` slice (e2c) | make check; 139 exact parent traces; five C parent controls; GUEST-GEN 127; extraction/coverage 200; frozen contract | C bound; Sail next |
| `2026-10-08` | `.12` slice (e1c1) | parent RED; 13 RED; GUEST-GEN 103/103; parcel 139 exact; 42 owned exact; books | cache repaired; archive lifecycle prerequisite before staging |
| `2026-10-08` | `.12` slice (e1c0) | parent 0/3 then three green; two selector RED; translation 29/29; make check; DEF-GEN 56/56 | production scopes repaired; independent cache author next |
| `2026-10-08` | `.12` slice (e1b2) | masks/30 mode gates/literal text/schema; 8 RED; 117 corpus steps; GUEST-GEN 89/89 | 138 exact, zero refusals; owned cache repair next |
| `2026-10-08` | `.12` slice (e1b1) | 22 hand arithmetic, ten branches, memory/reserved; 8 RED; 471 corpus steps; GUEST-GEN 80/80 | 135 exact; three refusals/cache owned next |
| `2026-10-08` | `.12` slice (e1a) | fixed misa/mode/TVM/TSR fixtures; 9 RED; 140 mode-matrix steps; GUEST-GEN 71/71 | privilege repaired; vocabulary/cache prerequisites next |
| `2026-10-08` | `.12` slice (d3d2) | byte/budget/head/code-visibility fixtures; 8 RED; 176 legacy steps; GUEST-GEN 61/61 | tools ready; staged C corpus/counts next |
| `2026-10-08` | `.12` slice (d3d1) | exact parcel/PTE/MPRV/EPC fixtures; 9 RED; GUEST-GEN 52/52; 97 prior texts exact | independent fetch/walk repaired; byte guests/budgets next |
| `2026-10-08` | `.12` slice (d3d0) | C engine 18/18; parent/mutation 3 RED; DEF-GEN 55/55; make check | every wider prefix retains ILEN bits; independent fetch/walk next |
| `2026-10-08` | `.12` slice (d3c) | 37 forms/effects, 79 scatter bits, 6 RED controls; GUEST-GEN 42/42; 42 owned + 91 legacy exact | independent C component ready; fetch/budgets next |
| `2026-10-08` | `.12` slice (d3b) | 79/79 cached strict checks; live M 4/4 + C image; 4 RED controls; GUEST-GEN 35/35 | strict tracked Sail adapter; absence defect closed; C author next |
| `2026-10-08` | `.12` slice (d3a) | 42 exact owned records; 7 reserved + permission probes; 6 RED controls; GUEST-GEN 30/30 | author tracked and repaired; 169 permission observations agree; Sail repair next |
| `2026-10-08` | `.12` slice (d2) | 2 compiled image/runner probes, 2 RED controls; GUEST-GEN 23/23; make check | exact bytes ready; 188 old images/expectations unchanged; (d3) producers next |
| `2026-10-08` | `.12` slice (d1) | 37 forms, 21 refusals, exact bytes; 3 RED controls; GUEST-GEN 20/20; corpus 77/77 | assembler ready; old guests unchanged; (d2) image generator/runner next |
| `2026-10-08` | `.12` slice (c2) | 15 engine probes (baseline 0/15); DEF-GEN 54/54; make check | C evaluator ready; exact fetch and expansion execution proven on temporary composition; (d) tools next |
| `2026-10-08` | `.12` slice (c1) | make check; parcel extent, alignment, visibility, refusal spans | typed two-byte boundary ready; existing corpus unchanged; (c2) next |
| `2026-10-07` | `.12` slice (b) | 37/37 declarations; SEMANTICS 46/46 controls; DEF-GEN 51/51 (104 spec-side checks, compiled decoder 8/8); citations 0 findings; make check + make gate + all books green; handoff OK | the language and generator ready; crash recovered; handoff before (c) |
| `2026-10-06` | `.12` slice (a2) | the boundary tests RED on both engines, then GREEN; both corpora unchanged (76/76) | JAL's offset sign fixed |
| `2026-10-06` | `.12` slice (a) | C composes (37; 192 with the extensions); the disjointness self-test 17/17; the census 163 == 163 | the C fragment |
| `2026-10-06` | `.11` slice (d) + LEAF | 13/13 forms; lab 139/139 + Sail 4/4; EVD-05 pin OK; 4,485 vectors | **met** — the leaf closes |
| `2026-10-06` | `.11` slice (c2) | Sail over the M corpus: 4 AGREE of 4 (99 steps); a planted wrong quotient DIVERGES | the reference route |
| `2026-10-06` | `.11` slice (c1) | 4,485 vectors through the engine; M-VECTORS ok, 6/6 controls; a hand-edited vector RED twice | the generated evidence route |
| `2026-10-06` | `.11` slice (b) | corpus 139/139; identity 135/0 + 4 RED; census 163 == 163; CONTRACT-FREEZE 3 versions; the generator's controls 17/17 (re-written relative) | M bound |
| `2026-10-06` | `.11` slice (a) | SEMANTICS 32/32; DEF-GEN 45/45; muldiv 6/6 + two mutations RED | the language carries M |
| `2026-10-06` | `.10` slice (c) + LEAF | the four reports regenerated in a fresh worktree (no `target/`), byte-identical | **met** — the leaf closes |
| `2026-10-06` | `.10` slice (b) | the generator's controls 17/17; GATE-REPORT 16/16, 5 reports in sync; the literal census | `GS-REPORT.md`: incomplete, 9 of 10 open, every one owned |
| `2026-10-06` | `.10` slice (a) | the measure's controls 7/7; GATE-REPORT 13/13; the cross-credit RED (old 1 of 72, new 0); the pairing RED | rv64gc 14 of 100, rv64i 0 of 72 |
| `2026-10-06` | `.9` slice (d) + LEAF | v1 frozen; an edited v1 record named and refused (rc=1); the controls 7/7; the registry 14/14 | **met** — the leaf closes |
| `2026-10-06` | `.9` slice (c) | CONTRACT-FREEZE ok with two supersessions; the registry 14/14; RECORD-SCHEMA ok | **met** — the wrong v0 statements corrected by v1, never rewritten |
| `2026-10-06` | `.9` slice (b) | the registry's two tests (10 checks realized, every guest holding); RED with one entry dropped; CONTRACT-FREEZE (2 versions) and RECORD-SCHEMA ok; 135/135 | **met** — every new assumption has a positive and a negative fixture that exist and run |
| `2026-10-06` | `.9` slice (a) | CONTRACT-FREEZE 7/7 controls; the real contract clean (1 unit, 1 version); the schema ok; no record changed | **met** — a contract version is a checked document, v0 frozen |
| `2026-10-06` | `.8` slice (e) + LEAF | sail over the ten `.8` guests (3 AGREE; the counters cell and the six injected guests named — each injected one diverging at its first refused access); 134/134 | **met** — the leaf closes |
| `2026-10-06` | `.8` slice (d) | five injected guests derived (every cell as designed) and green (134 guests); RED — a refused walk read as a page fault is caught first by inj-walk-l2 (the 129 earlier guests blind); RECORD-SCHEMA ok; STATE-GEN re-derived | **met** — a fault injected at a chosen suboperation leaves the architecturally required state, on every multi-suboperation instruction the profile has |
| `2026-10-06` | `.8` slice (c) | inj-carrier derived and green (129 guests); RED with the runner's refusals emptied (step 12); the predicate's boundary test; the schema refuses an unknown kind; the tool regression 80/80 | **met** — injection is typed, declared and honoured on both the engine's and the model's side |
| `2026-10-06` | `.8` slice (b) | the pins census; prio-sv39 derived (causes 4 6 13 4 5 7 2 2) and green on the engine (128 guests); sail AGREE 128 steps; RECORD-SCHEMA ok; the matrix 28 cells | **met** — the table declared, every realizable adjacent pair pinned on both engines |
| `2026-10-06` | `.8` slice (a) | the probe on the HEAD engine (x5 written, then cause 2); the RED guest on the old engine (step 9); 127/127 after the fix; identity 125/0 + 2 RED; sail AGREE mm-csr-ro-write (51) and a-lrsc-fault (41), the counters guest the named Zicntr-absent cell; the tool before/after 76/76 + F/D 22/22 | **met** — a refused CSR write leaves rd untouched on both engines |
| `2026-10-06` | `.7` slice (e3) + LEAF | the acceptance evidence re-run at HEAD: fp:: 8 passed (230 + 3,168), run_rv64gc 4/4 (125), FP-VECTORS ok (agree 2131), Sail 24 AGREE rc=0, fpcheck 0 of 63,752 vs the reference | **met** — the leaf closes |
| `2026-10-06` | `.7` slice (e2) | 3,168 fixtures (162 combinations, 21 operations, every flag raised) pass on the first run; RED with UF removed; FP-VECTORS 7/7 (fixture DRIFT arm); the per-op cost on the final model layer and on the raw backend in one run | **met** — breadth tracked and gated; performance measured (2.8–6.9× the backend on the arithmetic core, the exact OF/UF's cost) |
| `2026-10-06` | `.7` slice (e1) | the override re-materialized (unmoved) and validated; sail's F/D config read (Precise dirtiness, FourState FS); 24 FP guests on sail 0.14 — 24 AGREE, 927 steps exact; the comparator's RED (one corrupted expectation → DIVERGE at that step) | **met** — the encoding/state surface agrees with the second engine on every cell |
| `2026-10-06` | `.7` slice (d5) — THE BIND | the pre-bind census (the slot at encoding.sexp:17, 0 D rows, count_total 118, no FToF); the payload landed 34/34 byte-identical; run_rv64gc 4/4 over 125; 32/32 D forms generated; 150 == 150 (the exclusion flipped itself); coverage 150/150; the matrix 28 cells; DOSSIER-SCHEMA 224 judged | **met** — D executes in the tracked engine; the 114 older guests byte-identical |
| `2026-10-06` | `.7` slice (d4) | the tool's D refusal measured; F re-derived 11/11 identical through the D-taught tool; D derived 11/11 schema-valid, re-derived 22/22 identical; three authoring defects re-derived (alignment, andi, a false comment); the scratch engine 125 guests 4/4 (RED: FToF's mode ignored → d-f2f step 13); identity 114/0 + 11 RED | **met** — every D guest spec-derived and satisfied on the scratch engine; the bind lands it |
| `2026-10-06` | `.7` slice (d3) | the planned sNaN patch bypassed (vectors still green — dead); the backend probed (INVALID_OP both ways); slice (a)'s 24 conversion FLAGS rows read (all backend NV, MPFR none); 230/230 vectors; FP-VECTORS hardware agree 2131 with the tie mutation caught on the conversion leg; fp.rs over the 63,752-case corpus 0 vs the reference, 24 vs MPFR (the oracle's) | **met** — the conversions modeled; the record corrected at its source |
| `2026-10-06` | `.7` slice (d2) | the operator census (only f2f new; 62 → 63); d.sem.sexp 32/32 + 19 quotes judged (0 findings); check_semantics 26/26; DEF-GEN 37/37 with the D-gate RED by mutation; the F + D staged module emits FToF; the assembler's D spelling 32/32 vs spike-dasm + 4 refusals; the tracked modules fingerprint-only | **met** — the language states D; nothing tracked executes it until the bind |
| `2026-10-06` | `.7` slice (d1) | the pre-slice census (D pinned nowhere); the fetch through the tracked route (MATCH both pins, 118 == 118) and byte-identical to the census fetch; the exclusion RED (exactly the 32 D names); 9 fragments regenerated, 8 byte-identical; d.sexp schema ok; trial units — D without F refused by name, F + D composes 147 + 3; rv64i 52 == 52 | **met** — D pinned and fragmented, the slot unmoved |
| `2026-10-06` | `.7` slice (c6) — THE BIND | the pre-bind census (the slot at encoding.sexp:16, 0 F rows, count_total 88, no fp:: in the evaluator); the payload landed 38/38 byte-identical from the worktree; run_rv64gc 4/4 over 114; 30/30 F forms generated; 118 == 118 vs the pinned tables; EXERCISE-COVERAGE 118/118; the matrix 28 cells; RECORD-SCHEMA, PROFILE-CONSISTENCY, EXTRACTION, DEF-GEN, GUEST-GEN, CITATION-QUOTES ok; two stale facts swept (fp.rs 362 → 290; the schema's deviation count) | **met** — F executes in the tracked engine; the 103 older guests byte-identical |
| `2026-10-06` | `.7` slice (c5) | specfp's signed fused forms vs the sign-flip construction (464,000 cases, 0 disagreements; RED 490 / 153,438 under two mutations); the corpus re-authored + re-derived from scratch (22/22 byte-identical; f-fused moves 9 lines under the mutated reference); the scratch engine 114 guests 4/4 (RED: accrual dropped → f-arith step 9); identity 103/0 + 11 RED on the parent; FP-VECTORS unchanged | **met** — every F guest's expectation is spec-derived and the arms satisfy them on the scratch engine; the bind (c6) lands the payload |
| `2026-10-06` | `.7` slice (c4) part 2 | 176 spec-side vectors (3 RED first — the UF boundary); the oracle's OF/UF rules read in source and corrected (72 false OFs; UF delivered-result) with SoftFloat's RISC-V roundPack read as the cross-reference; fp.rs over the corpus — 0/51,840 vs corrected MPFR, 0/63,480 vs the exact-rational reference, RED on one corruption; FP-VECTORS 6/6 with the reference-mutation arm | **met** — the model layer is the RISC-V policy over the backend, OF/UF exact; the qualification record amended |
| `2026-10-06` | `.7` slice (c4) part 1 | the shared cache census (rustc_apfloat at slice (a)'s landing time); cargo metadata's resolution path before (~/.cargo) and after (.app-data/vendor); the shared cache's stat snapshot unchanged by a full + wasm build; the missing-store RED (loud); make vendor idempotent and reproducible | **met** — every cargo run in the repository resolves on-volume; CI and bootstrap populate the store |
| `2026-10-06` | `.7` slice (c3) part 2 | the language census (44 operators; the typed 43); the FP block (18 operators, the contract once); f.sem.sexp 30/30 + 26 quotes judged; check_fp + 6 arms (23/23); the F lowering on a staged composition + 8 DEF-GEN arms (31/31); the assembler's derived register files — 30/30 spike-dasm round trip, 6/6 refusals; both modules and both fixtures emission-neutral | **met** — the F vocabulary exists, checked and lowered; the tracked module unmoved until the bind |
| `2026-10-06` | `.7` slice (c3) part 1 | the pinned F/D chapters' heading census against every `RVI-F §20.1.1` / `RVI-D §21.1.2` locator; the fcsr content re-cited §20.1.2, FLEN=64 §21.1.1; both FP guests re-derived (sources only, values byte-identical); 103/103; check_citations 52/52 (its scope measured: sem files only, existence only) | **met** — the locators name the sections that hold their content; the tool gap owned by `CITATION-ACCURACY` |
| `2026-10-06` | `.7` slice (c2) | the pre-slice census (F pinned nowhere; 7 FRAGMENTS entries; the fetched tables 26 + 4 rows, 13 pseudo rows; rs3/rm already in arg_lut.csv); the tracked-route fetch byte-identical to the census fetch; the named exclusion RED without it (118 vs 88, exactly the 30 F names); f.sexp generated (30 forms, owns rs3/rm, no pseudos), the seven others byte-identical; schema + disjointness (115-form trial union collision-free) | **met** — the F tables pinned and owned as a fragment; the scope and the slot unmoved until the bind; both profiles verify; `make gate` green |
| `2026-10-06` | `.7` slice (c1) | the FSRM sentence + the rm table re-read against slice (b)'s frm WARL; the engine traced on fp-fcsr-view (x12 `0x45`, x14 `0x2` — retention); the fix at the declaration + both generators; the unit tests and the authoring tool corrected; the guest re-derived spec-side and RED against the unfixed legalization (step 15), green after (103/103); the tool's quote refusal fired; three ceiling crossings resolved by their own procedures (DEV_NOTES shard, archive part 3, the book partition) | **met** — frm holds any 3-bit value; the reserved-rm policy recorded (illegal-instruction, still valid per the pinned revision; Sail's `Fcsr_RM_Illegal`); `make check` rc=0, `make gate` green |
| `2026-10-06` | `.7` slice (b) | the two latent defects re-measured live (the fsprobe: the gate absent — Ok ×6 at FS=Off; fcsr reads 0x0, writes refused); the Sail placement measurement (the FS gate rides decode-time legality — fdext_control.sail:19, fext_insts.sail:888 — dynamic state, not the encoding; the FS=Off instruction cells are the bind's, recorded); the `fp_registers` descriptor element (schema + dossier mapping + gen_state + the 4th census candidate, RED-armed); the census re-answer + the three FP-CSR statements refined; privilege.rs (the FS section; the permitted() arm; compose_view/write_legalized; FP-CSR writes mark FS=Dirty — fdext_regs.sail:455); 134/134 lib tests (6 new); the corpus 103/103 (fp-fs-off 40 steps, fp-fcsr-view 20 — EVD-05 spec-side); the matrix cells; the identity proof (101 pre-slice guests byte-identical, 5,491 trace lines, both CLIs vs the parent worktree; the RED control — both new guests diverge on the parent — caught the harness's own `--profile=` bug first); STATE-GEN 29/29 + both pairs byte-exact, DEF-GEN re-derived, DERIVED-COUNTS 430→431; `make check` rc=0, `make gate` all green, bench wasm + smoke-bench + both books | slice (b) landed: the FP state modelled and gated; next slice (c) — THE F BIND |
| `2026-10-06` | `.7` slice (a) | the candidate re-measurement (LICENSE texts from the fetched artifacts; the negatives re-confirmed; the TestFloat claim unverifiable, not counted); the capability census (softfloat's five §6 gaps; apfloat's sqrt absence); the MPFR path (the system libmpfr 4.2.2 via vec_gen.c, four measured corrections); the probe (63,752 cases: ZERO arithmetic-core disagreements; 612 value + 386 flag disagreements, all named — policy surfaces or the two LLVM-vs-IEEE deviations; softfloat's 4,416 shared cases with 68, all NaN-sign, its sqrt MPFR-exact); the timing table (apfloat f64 add/mul/div 10.1/10.5/40.7 ns/op, fma 15.7; softfloat 3.2/2.3/5.1, sqrt 44.1); the wasm proof (both candidates); the decision record + INDEX + the PROMOTED knowledge card; the dependency landing (pinned =0.2.3+llvm-462a31f5a5ab; Cargo.lock 4→7; on-volume cargo home); `make check` rc=0, `make gate` all green (DERIVED-COUNTS 430; the knowledge map regenerated), bench wasm + smoke-bench + both books | slice (a) landed: rustc_apfloat QUALIFIED by measurement; softfloat disqualified on capability; the fallback stays named |
## Commit Log

Every closed leaf's rows (`.1`–`.6` and the tree's own `SEMULITH-P4-0001`) live verbatim
in [`archive/P4-SYSTEM-3.md`](archive/P4-SYSTEM-3.md) — moved at the `2026-10-06` `.7`
slice-(c5) crossing; only the ACTIVE leaf's rows stay inline below.

| Leaf | Commit subject or reference | Notes |
| --- | --- | --- |
| `.12` (slice e2d) | `SEMULITH-P4-0103 (leaf P4-SYSTEM.12): verify compressed execution against Sail and reproduce its timer-platform limit` | e2e full CI/signoff |
| `.12` (slice e2c) | `SEMULITH-P4-0102 (leaf P4-SYSTEM.12): bind compressed execution and its independently derived parcel corpus` | e2d matched Sail |
| `.12` (slice e2b) | `SEMULITH-P4-0101 (leaf P4-SYSTEM.12): retain historical capture text while independently checking parcel extents` | e2c atomic bind, then matched Sail |
| `.12` (slice e2a) | `SEMULITH-P4-0100 (leaf P4-SYSTEM.12): govern independently checked parcel counts without exempting mirror content` | e2b atomic bind, then matched Sail |
| `.12` (slice e1d2) | `SEMULITH-P4-0099 (leaf P4-SYSTEM.12): stage the specification-derived compressed corpus before binding C` | e2 bind contracts, then matched Sail |
| `.12` (slice e1d1) | `SEMULITH-P4-0098 (leaf P4-SYSTEM.12): stage independently derived parcel counts for the historical corpus` | e1d2 C corpus, then e2 bind |
| `.12` (slice e1d0) | `SEMULITH-P4-0097 (leaf P4-SYSTEM.12): preserve historical provenance and label new author routes honestly` | e1d staged C corpus/counts, then e2 bind |
| `.12` (slice e1c1) | `SEMULITH-P4-0096 (leaf P4-SYSTEM.12): derive the selected translation cache independently` | containment lifecycle, then e1d / e2 |
| `.12` (slice e1c0) | `SEMULITH-P4-0095 (leaf P4-SYSTEM.12): preserve SFENCE operand identity through the semantic cache interface` | e1c1 independent cache, then corpus/counts/bind |
| `.12` (slice e1b2) | `SEMULITH-P4-0094 (leaf P4-SYSTEM.12): derive counter permissions and preserve literal expectation text` | e1c cache, then corpus/counts/bind |
| `.12` (slice e1b1) | `SEMULITH-P4-0093 (leaf P4-SYSTEM.12): derive the base integer vocabulary and reserved word-shift diagnostics` | e1b2 CSR/directives, then cache/corpus/counts |
| `.12` (slice e1a) | `SEMULITH-P4-0092 (leaf P4-SYSTEM.12): repair fixed misa fields and privileged legality in the independent author` | (e1b) vocabulary, then cache/corpus/counts |
| `.12` (slice d3d2) | `SEMULITH-P4-0091 (leaf P4-SYSTEM.12): derive byte-addressed guests with explicit boundary budgets` | (e1) staged corpus/counts next |
| `.12` (slice d3d1) | `SEMULITH-P4-0090 (leaf P4-SYSTEM.12): derive exact parcel fetches and repair the spec-side Sv39 walk` | (d3d2) explicit byte guest budgets next |
| `.12` (slice d3d0) | `SEMULITH-P4-0089 (leaf P4-SYSTEM.12): fetch every ILEN parcel before reporting an unsupported instruction` | (d3d1) independent walker/fetch repair next |
| `.12` (slice d3c) | `SEMULITH-P4-0088 (leaf P4-SYSTEM.12): derive compressed component expectations from independent spec-side rules` | (d3d) parcel fetch/budgets next |
| `.12` (slice d3b) | `SEMULITH-P4-0087 (leaf P4-SYSTEM.12): track the parcel-capable Sail runner and refuse absent reference evidence` | (d3c) C author expansion next |
| `.12` (slice d3a) | `SEMULITH-P4-0086 (leaf P4-SYSTEM.12): track the spec-side expectation author and repair its encoding and permission checks` | (d3b) Sail repair/audit next |
| `.12` (slice d2) | `SEMULITH-P4-0085 (leaf P4-SYSTEM.12): carry exact guest byte images through generation and the rv64gc runner` | (d3) author/Sail tools next |
| `.12` (slice d1) | `SEMULITH-P4-0084 (leaf P4-SYSTEM.12): assemble compressed instructions and preserve exact byte images` | (d2) generator/runner next |
| `.12` (slice c2) | `SEMULITH-P4-0083 (leaf P4-SYSTEM.12): execute compressed expansions and fetch only the required parcels` | (d) tools next; production C bind remains (e) |
| `.12` (slice c1) | `SEMULITH-P4-0082 (leaf P4-SYSTEM.12): add exact two-byte instruction fetches to the environment boundary` | (c2) engine next |
| `.12` (slice b) | `SEMULITH-P4-0081 (leaf P4-SYSTEM.12): recover the interrupted C language slice; declare expansions and decode by specificity` | handoff; (c) next |
| `.12` (slice a2) | `SEMULITH-P4-0080 (leaf P4-SYSTEM.12): slice a2 — a found defect owned: JAL's offset sign was taken from bit 19 in both engines; pinned at the boundary and the extremes` | (b) next |
| `.12` (slice a) | `SEMULITH-P4-0079 (leaf P4-SYSTEM.12): slice a — the C re-pin and the fragment: 37 forms, their scatter layouts, the six declared specializations` | (b) next |
| `.12` brief | `SEMULITH-P4-0078 (tree P4-SYSTEM): the .12 design brief — bind C: each compressed form declared by its expansion, decoded by specificity, fetched parcel-first` | (a) next |
| `.11` (slice d) + LEAF | `SEMULITH-P4-0077 (leaf P4-SYSTEM.11): slice d — THE LEAF ACCEPTANCE: M bound, every form on both engines from expectations derived first; the leaf CLOSES` | frontier → `.12` |
| `.11` (slice c2) | `SEMULITH-P4-0076 (leaf P4-SYSTEM.11): slice c2 — the Sail matched experiment over the M corpus: 4 AGREE of 4` | (d) next |
| `.11` (slice c1) | `SEMULITH-P4-0075 (leaf P4-SYSTEM.11): slice c1 — 4,485 generated M vectors through the engine; M-VECTORS, the 38th doctrine, gates the table and judges its reference` | (c2) next |
| `.11` (slice b) | `SEMULITH-P4-0074 (leaf P4-SYSTEM.11): slice b — THE BIND: the unit composes riscv/m; the M corpus (139/139, 135 byte-identical + 4 RED on the parent); OB-GC-M opens contract v2` | (c) next |
| `.11` (slice a) | `SEMULITH-P4-0073 (leaf P4-SYSTEM.11): slice a — the language for M: eight arithmetic operators, the division-domain rule, m.sem.sexp, the generator, the model layer` | (b) next |
| `.11` brief | `SEMULITH-P4-0072 (tree P4-SYSTEM): the .11 design brief — bind M: eight arithmetic operators, the division-by-zero results stated in the definition, contract v2 opened` | (a) next |
| `.10` (slice c) + LEAF | `SEMULITH-P4-0071 (leaf P4-SYSTEM.10): slice c — THE LEAF ACCEPTANCE: every report regenerates byte-identically in a checkout with no target/; the leaf CLOSES` | frontier → `.11` |
| `.10` (slice b) | `SEMULITH-P4-0070 (leaf P4-SYSTEM.10): slice b — the GS builder over all ten axes, the unit's verified evidence manifest, the first CPU-SYSTEM report (incomplete, 9 of 10 open, every one owned)` | (c) next |
| `.10` (slice a) | `SEMULITH-P4-0069 (leaf P4-SYSTEM.10): slice a — the contract measure becomes the unit's own: its registry, under the declaring obligation, over the effective contract` | (b) next |
| `.10` brief | `SEMULITH-P4-0068 (tree P4-SYSTEM): the .10 design brief — the CPU-SYSTEM report is an instrument over all ten axes; the census's open axes owned by eight new leaves (.11–.18)` | the tree grows to 18 |
| `.9` (slice d) + LEAF | `SEMULITH-P4-0067 (leaf P4-SYSTEM.9): slice d — rv64gc's ENVIRONMENT document, v1 frozen, CONTRACT-FREEZE judges before certifying; THE LEAF ACCEPTANCE — the leaf CLOSES` | frontier → `.10` |
| `.9` (slice c) | `SEMULITH-P4-0066 (leaf P4-SYSTEM.9): slice c — v0's stale statements superseded in v1 (OB-GC-PRIV-INSNS-V1, OB-GC-ECALL-EBREAK-V1, their checks realized); the code's forward references to .9 resolved` | the two requirement mirrors named |
| `.9` (slice b) | `SEMULITH-P4-0065 (leaf P4-SYSTEM.9): slice b — contract v1: four environment assumptions (translation inputs, interrupt sources, virtual time, reservation events), each with realized POS/NEG fixtures; the check registry` | env-irq-sources the one new fixture |
| `.9` (slice a) | `SEMULITH-P4-0064 (leaf P4-SYSTEM.9): slice a — the contract becomes a versioned document (schema/contract.sexp), rv64gc's v0 recorded and frozen (46 members pinned), CONTRACT-FREEZE registered (the 37th doctrine)` | the doctrine on its five surfaces |
| `.8` (slice e) + LEAF | `SEMULITH-P4-0062 (leaf P4-SYSTEM.8): slice e — the sail attempt over the faults corpus (3 AGREE + 7 NAMED of 10), THE LEAF ACCEPTANCE; the leaf CLOSES` | frontier → `.9` |
| `.8` (slice d) | `SEMULITH-P4-0061 (leaf P4-SYSTEM.8): slice d — the injected-fault corpus (LR/SC/AMO halves, FP transfers, a walk refused at each Sv39 level); OB-GC-PARTIAL-PROGRESS declared; the state candidate re-answered` | fetch refusals named out (no fetch model in the authoring tool) |
| `.8` (slice c) | `SEMULITH-P4-0060 (leaf P4-SYSTEM.8): slice c — the typed fault-injection carrier: declared refusal regions honoured by the runner and the spec-side model alike; inj-carrier proves it end to end (an AMO's store refused after its load)` | both guest modules regenerated |
| `.8` (slice b) | `SEMULITH-P4-0059 (leaf P4-SYSTEM.8): slice b — the fault-priority table declared (D-FAULT-PRIORITY + its mirrors); prio-sv39 pins the missing adjacent pairs, sail AGREE` | a characterization guest, no engine change |
| `.8` (slice a) | `SEMULITH-P4-0058 (leaf P4-SYSTEM.8): slice a — the CSR rd-before-trap defect fixed at root (csr-rw, the atomic read-write; RED-first, sail AGREE on mhartid); LR's wrong unreachable cause and a-lrsc-fault's stale prose` | the brief's sail evidence corrected |
| `.7` (slice e3) + LEAF | `SEMULITH-P4-0056 (leaf P4-SYSTEM.7): slice e3 — the decision record's closing measurement + THE LEAF ACCEPTANCE; the leaf CLOSES (F and D bound and validated)` | frontier → `.8` |
| `.7` (slice e2) | `SEMULITH-P4-0055 (leaf P4-SYSTEM.7): slice e2 — the numeric fixtures at scale (3,168 seeded spec-side cases, every operation × format × mode, gated by FP-VECTORS) + the model layer's per-op cost measured` | the doctrine row's stale count corrected |
| `.7` (slice e1) | `SEMULITH-P4-0054 (leaf P4-SYSTEM.7): slice e1 — the Sail matched experiment over the FP corpus: 24 AGREE of 24 (927 steps), an encoding/state match; the slice (e) split recorded` | the ledger's sixth experiment |
| `.7` (slice d5) — THE BIND | `SEMULITH-P4-0053 (leaf P4-SYSTEM.7): slice d5 — THE BIND: the unit composes riscv/d (150 forms, 125 guests, the FToF arm tracked)` | the staged payload landed; the worktree removed |
| `.7` (slice d4) | `SEMULITH-P4-0052 (leaf P4-SYSTEM.7): slice d4 — the staged D corpus (11 guests, 125/125 on the scratch engine, identity 114/0 + 11 RED)` | records only; the payload stays staged for (d5) |
| `.7` (slice d3) | `SEMULITH-P4-0051 (leaf P4-SYSTEM.7): slice d3 — fp.rs's format conversions (54 spec-side vectors, the hardware arm extended); the record's deviation (ii) withdrawn — the 24 cases were the MPFR oracle's missing signaling NaN` | the decision record's second amendment |
| `.7` (slice d2) | `SEMULITH-P4-0050 (leaf P4-SYSTEM.7): slice d2 — the language for D: f2f (the one new operator, gated on riscv/d), d.sem.sexp (32 rules at format 64), the assembler's D spelling derived (32/32 round trip)` | the closed (b)–(c3) part 2 checklists archived |
| `.7` (slice d1) | `SEMULITH-P4-0049 (leaf P4-SYSTEM.7): slice d1 — the rv_d/rv64_d re-pin (32 forms) + the d.sexp fragment (requires riscv/f, owns no field; the 3 pseudo rows written out); the slice (d) split recorded` | no Rust touched; the slot unmoved |
| `.7` (slice c6) — THE BIND | `SEMULITH-P4-0048 (leaf P4-SYSTEM.7): slice c6 — THE BIND: the unit composes riscv/f (118 forms, 114 guests, the F arms tracked)` | the staged payload landed; the worktree removed |
| `.7` (slice c5) | `SEMULITH-P4-0047 (leaf P4-SYSTEM.7): slice c5 — the staged F corpus (11 guests, 114/114 on the scratch engine, identity 103/0 + 11 RED); specfp learns the signed fused forms` | records + the tracked reference; the payload stays staged for (c6) |
| `.7` (slice c4 part 2) | `SEMULITH-P4-0046 (leaf P4-SYSTEM.7): slice c4 part 2 — fp.rs, the model layer over rustc_apfloat (OF/UF exact on the unbounded value, sqrt computed); the qualification oracle's two rule defects found and the record amended; FP-VECTORS registered` | 176 vectors; 0/51,840 + 0/63,480; the third deviation; the pin expressed =0.2.3 |
| `.7` (slice c4 part 1) | `SEMULITH-P4-0045 (leaf P4-SYSTEM.7): slice c4 part 1 — the dependency store on-volume: .cargo/config.toml routes every cargo run to .app-data/vendor (slice a's first registry dependency resolved through ~/.cargo)` | source replacement; make vendor; CI + bootstrap populate; RED-proven |
| `.7` (slice c3 part 2) | `SEMULITH-P4-0044 (leaf P4-SYSTEM.7): slice c3 part 2 — the semantics language learns FP (18 operators, the FP-state contract once), f.sem.sexp (30 rules), the gated lowering, the assembler's derived register files` | check_fp; the Surface bundle; the derived form count (the typed 43 was 44); 30/30 round trip |
| `.7` (slice c3 part 1) | `SEMULITH-P4-0043 (leaf P4-SYSTEM.7): slice c3 part 1 — the FP-CSR locators corrected (fcsr is RVI-F §20.1.2, FLEN=64 is RVI-D §21.1.1)` | the heading census; 24+ locators re-cited; both guests re-derived sources-only; the citation tool's blind spot measured and routed to CITATION-ACCURACY |
| `.7` (slice c2) | `SEMULITH-P4-0042 (leaf P4-SYSTEM.7): slice c2 — the rv_f/rv64_f re-pin (30 forms) + the f.sexp fragment (owns rs3/rm; the 13 pseudo rows written out, not carried)` | the tracked-route fetch byte-identical; the bind-gated exclusion RED-proven; the fragment generated, the others byte-identical; trial union 115 collision-free; both profiles verify |
| `.7` (slice c1) | `SEMULITH-P4-0041 (leaf P4-SYSTEM.7): slice c1 — frm holds any 3-bit value (slice b's WARL retention fixed at root); the slice (c) split recorded; the P4 book chapter partitioned per leaf` | the defect measured (spec text + engine trace); the declaration fixed, both generators re-run; tests + authoring tool corrected; fp-fcsr-view RED→green; the slice (c) split (c1–c6) and the FS-gate placement decided; DEV_NOTES shard, archive part 3, the book partition (33 → 39 chapters); knowledge card promoted |
| `.7` (slice b) | `SEMULITH-P4-0040 (leaf P4-SYSTEM.7): slice b — the FP state: the f-file census-gated, the FS gate live on the FP CSRs, the fcsr two-owner view fixed at root, the FS=Off corpus` | the defects re-measured live (the fsprobe); the Sail placement measured (decode-time legality — the instruction cells are the bind's); the fp_registers element through schema/dossier/generator + the 4th census gate (RED-armed);the census re-answer + the FP-CSR statements; privilege.rs (the FS section, the permitted() arm, compose_view/write_legalized, dirty-on-FP-CSR-write); 134/134 lib tests; 103/103 corpus (fp-fs-off + fp-fcsr-view, EVD-05); the matrix cells; the identity proof (101 byte-identical, 5,491 lines, both CLIs; the RED control diverges on the parent — and caught the harness's `--profile=` bug); STATE-GEN 29, DEF-GEN, DERIVED-COUNTS 430→431; make check + make gate green, bench wasm + smoke-bench + both books |
| `.7` (slice a) | `SEMULITH-P4-0039 (leaf P4-SYSTEM.7): slice a — the backend qualification: rustc_apfloat QUALIFIED (the arithmetic core MPFR-exact; softfloat fails §6 on capability)` | the re-measurement (licenses, provenance, the TestFloat claim unverifiable); the capability census (softfloat's five §6 gaps; apfloat's sqrt absence); the MPFR path (system libmpfr, four measured corrections); 63,752 probe cases — zero arithmetic-core disagreements, 612/386 all named; softfloat's 68 all NaN-sign; the timing table; the wasm proof; the decision record + INDEX + the PROMOTED knowledge card; the pinned dependency (Cargo.lock 4→7, the re-export compile-use); make check + make gate green (DERIVED-COUNTS 430), bench wasm + smoke-bench + both books |

## Changelog

- `2026-10-08`: `.12` (e1c1) done: independent cache, all 139 parcel traces exact;
  archive pressure owned by LIVE-CONTAINMENT.4 before staging C/counts.
- `2026-10-08`: `.12` (e1c0) done: fence scopes preserve x0 identity, including
  real page/ASID zero; three parent RED regressions green; two old fixture legs repaired.

- `2026-10-08`: `.12` (e1b2) done: independent CSR enables and literal prose;
  eight RED, three formerly refused guests/117 steps exact; census 138/139, no refusals.

- `2026-10-08`: `.12` (e1b1) done: base integer author rules and reserved W shifts;
  eight RED, 17 formerly refused guests/471 steps exact; census 135/139 exact.

- `2026-10-08`: `.12` (e1a) done: fixed misa and privileged legality; nine RED
  controls, five mode-matrix guests/140 steps exact; all census gaps owned before staging.

- `2026-10-08`: `.12` (d3d2) done: exact byte guest budgets, annotations, current code
  and head boundaries; eight RED controls; five gaps reproduce 176 architectural steps.

- `2026-10-08`: `.12` (d3d1) done: independent translated parcel fetch, four walk
  defects plus EPC masking repaired; nine RED controls, all 97 prior outputs exact.

- `2026-10-08`: `.12` (d3d0) done: wider prefixes fetch all ILEN=32 bits; three new
  probes RED before repair, then C engine 18/18. Resume independent walker/fetch d3d1.

- `2026-10-08`: `.12` (d3c) done: independent 37-form C component author; six RED
  controls, 42 owned and 91 prior texts exact; parcel fetch and budgets next.

- `2026-10-08`: `.12` (d3b) done: tracked strict Sail runner, 79/79 cached checks,
  live M 4/4 and mixed C image, repeat traces exact; four absence mutations discriminate.

- `2026-10-08`: `.12` (d3a) done: spec-side author tracked with non-writing checks,
  42-record owned corpus, reserved guards and SUM/MXR/U repair; six mutation controls.

- `2026-10-08`: `.12` (d2) done: rv64gc byte fixtures reach the tracked runner exactly;
  scalar payload and all old images/expectations unchanged; permanent mixed-image controls.

- `2026-10-08`: `.12` (d1) done: all 37 C forms assemble; exact sized units/images and
  byte labels, reserved/specialization refusals, three mutation controls. d2 next.

- `2026-10-08`: `.12` (c2) done: parcel-first fetch and length-aware expansion execution;
  permanent 15-case probe, baseline RED, two mutation controls; DEF-GEN 54/54. (d) next.
- `2026-10-08`: `.12` (c1) done: typed parcel boundary and extent tests; PNT resumed.
  The closed `.11` checklists archived verbatim to part 4.
- `2026-10-07`: `.12` slice (b) done (`SEMULITH-P4-0081`) — the interrupted session recovered:
  C's 37 expansions, exact bindings, reserved predicates, specificity decode and a compiled
  declaration probe. Stop at the director's requested checkpoint; the engine is slice (c).

- `2026-10-06`: `.12` slice (a2) done (`SEMULITH-P4-0080`) — a found defect owned: JAL offsets beyond ±512 KiB had the wrong sign in both engines.

- `2026-10-06`: `.12` slice (a) done (`SEMULITH-P4-0079`) — the C tables pinned, `c.sexp` generated (37 forms, 6 declared specializations).

- `2026-10-06`: `.12` design brief recorded (`SEMULITH-P4-0078`) — C binds as declared expansions (the spec's own constraint, made the representation), decoded by specificity with reserved code points from the spec, fetched parcel-first. Slices (a)–(f).

- `2026-10-06`: `.11` slice (d) done and the LEAF CLOSES (`SEMULITH-P4-0077`) — M bound and evidenced three ways. Frontier → `.12` (bind C).

- `2026-10-06`: `.11` slice (c2) done (`SEMULITH-P4-0076`) — Sail agrees with the M corpus, 4 of 4.

- `2026-10-06`: `.11` slice (c1) done (`SEMULITH-P4-0075`) — 4,485 generated M vectors run through the engine; M-VECTORS registered (38 doctrines).

- `2026-10-06`: `.11` slice (b) done (`SEMULITH-P4-0074`) — M bound (163 forms, 139 guests); contract v2 opened; the profiles/ byte ceiling re-derived.

- `2026-10-06`: `.11` slice (a) done (`SEMULITH-P4-0073`) — the language carries M (eight operators, the division-domain rule), `m.sem.sexp` written.

- `2026-10-06`: `.11` design brief recorded (`SEMULITH-P4-0072`) — M binds through eight arithmetic operators, the division-by-zero results stated by guards in the definition; contract v2 opened for `OB-GC-M`. `.8`'s checklists archived (part 4).

- `2026-10-06`: `.10` slice (c) done and the LEAF CLOSES (`SEMULITH-P4-0071`) — the CPU-SYSTEM
  report is reproducible, per axis, and reads `incomplete` (9 of 10 open, each owned).
  Frontier → `.11`.

- `2026-10-06`: `.10` slice (b) done (`SEMULITH-P4-0070`) — the first CPU-SYSTEM report:
  `incomplete`, 9 of 10 axes open, each open item owned by `.11`–`.18`.

- `2026-10-06`: `.10` slice (a) done (`SEMULITH-P4-0069`) — the contract measure is the unit's
  own registry over the effective contract; rv64gc reads 14 of 100, rv64i 0 of 72.

- `2026-10-06`: `.10` design brief recorded (`SEMULITH-P4-0068`) — the gate report is the
  instrument; its census found M and C unbound (an ownership gap), the contract measure not
  unit-scoped, and six axes with no rv64gc evidence path. The tree grows by `.11`–`.18`.

- `2026-10-06`: `.9` slice (d) done and the LEAF CLOSES (`SEMULITH-P4-0067`) — the environment
  contract is versioned and frozen (v0, v1), v1 states the four environment assumptions with
  realized fixtures, and rv64gc has its ENVIRONMENT document. Frontier → `.10`.

- `2026-10-06`: `.9` slice (c) done (`SEMULITH-P4-0066`) — **the supersessions**: v1 replaces
  v0's wrong wfi/sfence.vma and ecall/ebreak statements by new records, the old ones frozen
  in place; their checks realized. Next: slice (d) — the reports and the leaf acceptance.

- `2026-10-06`: `.9` slice (b) done (`SEMULITH-P4-0065`) — **contract v1's assumptions**: the
  unit's first environment assumptions — translation inputs, interrupt sources (none), the
  virtual-time supply, reservation events (none) — each with a positive and a negative fixture
  a tracked registry runs. Next: slice (c) — the stale v0 statements superseded.

- `2026-10-06`: `.9` slice (a) done (`SEMULITH-P4-0064`) — **the contract is versioned**: a
  contract document lists each version's records; rv64gc's v0 is recorded as it stands and
  frozen, every record pinned; CONTRACT-FREEZE refuses an edited frozen record. Next: slice
  (b) — v1's four environment assumptions with their fixtures.

- `2026-10-06`: `.8` slice (e) done and the LEAF CLOSES (`SEMULITH-P4-0062`) — faults, restart
  and partial progress validated: a fault injected at any suboperation leaves the required
  state; fault priority declared and pinned on both engines; the one place that broke the
  unit discipline fixed at root. Sail: 3 AGREE + 7 NAMED of 10. Frontier → `.9`.

- `2026-10-06`: `.8` slice (d) done (`SEMULITH-P4-0061`) — **the injected-fault corpus**: five
  guests refuse one suboperation's access each (LR/SC/AMO halves, FP transfers, a walk at every
  Sv39 level) and pin the architecturally required state; rv64gc declares its partial-progress
  obligation; the state candidate is answered. Next: slice (e) — Sail, the reports, the leaf
  acceptance.

- `2026-10-06`: `.8` slice (c) done (`SEMULITH-P4-0060`) — **the injection carrier**: a guest
  declares refusal regions (fetch/load/store/walk); the runner answers matching requests
  with an access fault and the authoring model predicts the same. `inj-carrier` proves it,
  including an AMO whose store is refused after its load completed. Next: slice (d) — the
  injected-fault corpus and the obligation.

- `2026-10-06`: `.8` slice (b) done (`SEMULITH-P4-0059`) — **the fault-priority table**:
  declared as `D-FAULT-PRIORITY` (the pinned table, the laboratory's misaligned-high choice,
  the unreachable rows named); `prio-sv39` pins the four missing adjacent pairs, Sail AGREE.
  Next: slice (c) — the typed fault-injection carrier.

- `2026-10-06`: `.8` slice (a) done (`SEMULITH-P4-0058`) — **the CSR defect at root**: a CSR
  instruction whose write is refused no longer commits rd — one atomic read-write judges both
  halves first. RED-first guest, 127/127, identity 125/0, sail AGREE on `mhartid` (the counter
  cases a named not-matchable cell: the matched config has no Zicntr). Next: slice (b) — the
  priority table.

- `2026-10-06`: `.7` slice (e3) done and the LEAF CLOSES (`SEMULITH-P4-0056`) — the
  floating-point backend is qualified and F and D are bound and validated: the decision
  record closes with its measured correctness (230 directed + 3,168 seeded spec-side cases
  tracked and gated; 0 of 63,752 corpus disagreements; Sail 24 AGREE of 24) and
  performance (the model layer 2.8–6.9× the raw backend). Frontier → `.8`.

- `2026-10-06`: `.7` slice (e2) done (`SEMULITH-P4-0055`) — **the fixtures at scale**: 3,168
  seeded cases from the exact-rational reference over every model-layer operation, format
  and rounding mode, tracked and gated; all pass. The model layer's per-op cost measured:
  2.8–6.9× the raw backend on the arithmetic core — the price of exact overflow/underflow.
  Next: slice (e3) — the reports, the book, the leaf acceptance.

- `2026-10-06`: `.7` slice (e1) done (`SEMULITH-P4-0054`) — **the Sail matched experiment**:
  all 24 floating-point guests agree with Sail 0.14 step for step (927 steps). Sail's FP is
  SoftFloat, so this is the encoding/state match the brief designed — decode, the FS gate,
  NaN-boxing, flag accrual, reserved rounding modes — plus one more numeric opinion. The
  slice (e) split is recorded. Next: slice (e2) — the numeric fixtures at scale.

- `2026-10-06`: `.7` slice (d5) done (`SEMULITH-P4-0053`) — **THE BIND**: the unit composes
  `riscv/d`; the 32 double-precision forms execute in the tracked engine (the census 150 in
  all four places; REQ-GC-D + OB-GC-D; the 11 guests on the seven existing axes). The
  corpus reads 125/125, the 114 older guests byte-identical. F and D are bound: G is
  complete but for M (its own leaf) — C rides its leaf. Next: slice (e) — the fixtures at
  scale, the Sail encoding/state match, the leaf acceptance.

- `2026-10-06`: `.7` slice (d4) done (`SEMULITH-P4-0052`) — **the staged D corpus**: 11
  guests (the Off gate, the 64-bit transfers and a boxed single seen as a double, the
  arithmetic and its flags, the fused forms, sign injection, min/max, compares, classes,
  the integer and format conversions, reserved rounding modes on exact operations),
  every expectation spec-derived. The scratch engine passes 125/125; the 114 older guests
  are byte-identical and every D guest fails on the parent. Next: slice (d5) — THE BIND.

- `2026-10-06`: `.7` slice (d3) done (`SEMULITH-P4-0051`) — **the format conversions**:
  `fp.rs::convert` and its exact reference, 54 vectors, the hardware cross-check extended.
  Measuring the backend before patching it overturned the qualification record's deviation
  (ii): the backend does raise NV for a signaling NaN through a conversion — the 24 cases
  were the MPFR oracle's, which has no signaling NaN. Two genuine deviations remain. Next:
  slice (d4) — the staged D corpus.

- `2026-10-06`: `.7` slice (d2) done (`SEMULITH-P4-0050`) — **the language for D**: one new
  operator, `f2f` (the format conversion), lowered only where `riscv/d` is composed;
  `d.sem.sexp` states the 32 D rules as F's at format 64; the assembler spells D operands
  from the rules (32/32 against spike-dasm). Next: slice (d3) — `fp.rs`'s conversions.

- `2026-10-06`: `.7` slice (d1) done (`SEMULITH-P4-0049`) — **the D tables pinned**: `rv_d`/`rv64_d`
  (32 forms) in the ledger under the bind-gated exclusion, and `definitions/riscv/d.sexp`,
  which requires F by name and owns no field. The slice (d) split is recorded: the FP
  vocabulary is already width-generic, so D adds one operator (the format conversion) and
  `fp.rs` patches the backend's last flag deviation there. Next: slice (d2) — the language.

- `2026-10-06`: `.7` slice (c6) done (`SEMULITH-P4-0048`) — **THE BIND**: the unit composes
  `riscv/f` and the 30 single-precision forms execute in the tracked engine — the Off gate
  at the instruction head, every rounded arm through `fp.rs` with sticky flag accrual and
  the Precise Dirty rule, NaN-boxing on every single read and write. The census is 118 in
  all four places; REQ-GC-F + OB-GC-F; the 11 guests ride the seven existing axes. The
  corpus reads 114/114, the 103 older guests byte-identical. Two stale facts from earlier
  slices corrected on the way. Next: slice (d) — the D bind.

- `2026-10-06`: `.7` slice (c5) done (`SEMULITH-P4-0047`) — **the staged F corpus**: 11
  guests covering the FS=Off gate, NaN-boxing and the transfers, the five rounding modes
  and the reserved ones, the five flags, the fused forms, sign injection, min/max with
  ±0/NaN, the compares' signaling rule, the ten classes, the saturating conversions and
  the Precise Dirty rule — every expectation derived spec-side. The reference learned the
  signed fused forms (it computed only FMADD), cross-checked against the sign-flip
  construction on 464,000 cases. On the scratch engine: 114/114, identity 103/0 with all
  11 F guests RED on the parent. Next: slice (c6) — THE BIND.

- `2026-10-06`: `.7` slice (c4) part 2 done (`SEMULITH-P4-0046`) — **the model layer**:
  `fp.rs` owns the RISC-V policy over rustc_apfloat (canonical NaN, boxing, rounding-mode
  resolution, sqrt computed exactly, min/max/compares/class in bits, Table 5's NaN→int, the
  FMA ∞×0 rule), with OF and UF judged on the exactly-unbounded result. Its spec-side vectors
  exposed that slice (a)'s MPFR oracle shared two of the backend's conventions (OF on the
  exact magnitude: 72 false overflows; UF on the delivered result: a third deviation hidden);
  corrected, fp.rs disagrees with neither oracle on the 63,752-case corpus. FP-VECTORS
  registered; the decision record amended. Next: slice (c5) — the staged F corpus.

- `2026-10-06`: `.7` slice (c4) part 1 done (`SEMULITH-P4-0045`) — **the dependency store
  on-volume**: slice (a)'s first registry dependency had been resolved by every routine
  build through the shared `~/.cargo` (cargo metadata named the path); `.cargo/config.toml`
  now replaces crates.io with the untracked on-volume `.app-data/vendor` (`make vendor`, in
  CI and bootstrap too), and a missing store fails loudly. Part 2 (`fp.rs`) continues.

- `2026-10-06`: `.7` slice (c3) part 2 done (`SEMULITH-P4-0044`) — **the semantics language
  learns FP**: the floating-point block states the FP-state contract once (the f-file read
  pre-instruction, writes marking Dirty, the Off gate judged at the head of any rule that
  touches FP state, sticky accrual with Sail's Precise dirtiness, NaN-boxing in the tree, the
  reserved-rm policy) and 18 operators; `f.sem.sexp` writes the 30 rules (26 quotes, all in
  their cited sections); `check_fp` refuses an unresolved rm, a computed rounding argument,
  a non-literal format and one operand in two register files; the generator lowers the F
  surface exactly when `riscv/f` is composed (the tracked module unmoved); the assembler
  spells f-registers by the semantics' own `(freg …)` (30/30 through spike-dasm). The typed
  "43 forms" was 44 since `.4` — now derived (62). Next: slice (c4) — `fp.rs`.

- `2026-10-06`: `.7` slice (c3) part 1 done (`SEMULITH-P4-0043`) — **the FP-CSR
  locators corrected**: the pinned chapter numbers fcsr §20.1.2 (§20.1.1 is the
  register file) and FLEN=64 §21.1.1 (§21.1.2 is NaN boxing); slice (b)'s locators,
  carried into c1, named the wrong sections in state.sexp, both FP guests, a doc
  comment and a test. No gate could see it — `check_citations.py` resolves sem-file
  locators by existence only — so the gap is owned by the new `CITATION-ACCURACY`
  tree, executed before part 2 writes thirty new FP citations.

- `2026-10-06`: `.7` slice (c2) done (`SEMULITH-P4-0042`) — **the F tables pinned and
  owned**: `rv_f`/`rv64_f` re-pinned through the tracked `extensions/` route (3,050/320
  B, a fresh re-fetch byte-identical), the census leg's named exclusion extended to
  them until the bind (RED-proven: 118 vs 88 without it), and `definitions/riscv/f.sexp`
  generated — 30 forms, owning `rs3` and `rm`, the register-file class left to the
  semantics. The 13 pseudo rows are written out, not carried (they spell real forms;
  the CSR aliases would have made F require Zicsr for spellings). Trial composition
  115 forms collision-free. Next: slice (c3) — the semantics language learns FP.

- `2026-10-06`: `.7` slice (c1) done (`SEMULITH-P4-0041`) — **frm holds any 3-bit
  value**: slice (b)'s WARL one-of 0..4 (retain on an illegal write) contradicted the
  FSRM sentence and the rm table's dynamic reserved modes; fixed at the declaration,
  the generated mirror and manifest regenerated, the unit tests and the spec-side
  authoring tool corrected, `fp-fcsr-view` re-derived and RED against the unfixed
  engine (fcsr `0x45` vs `0xE5`) before green. The reserved-rm policy recorded
  (illegal-instruction for static 101/110 and dynamic 101–111). The slice (c) split
  (c1–c6) and the FS-gate placement (judged at the head of any FP-state-touching
  instruction) decided before execution. Three ceiling crossings resolved by their
  own procedures: DEV_NOTES sharded, this file's closed-leaf changelog entries moved
  to the new archive part 3, the book's P4 chapter partitioned per leaf (33 → 39
  chapters; the duplicated heading and the stale `.3`/`.4` headings fixed). Next:
  slice (c2) — the `rv_f`/`rv64_f` re-pin and the `f.sexp` fragment.

- `2026-10-06`: `.7` slice (b) done (`SEMULITH-P4-0040`) — **the FP state lands**:
  the f0-f31 file at FLEN=64 is declared in the state document (the new
  `fp_registers` construct, schema + mapping + generator) and emitted as hart
  state under the census discipline (the 4th REQUIRED_CENSUS_CANDIDATES gate,
  RED-armed — STATE-GEN 29/29); the two latent defects are fixed at root, both
  re-measured live first: mstatus.FS now gates the fflags/frm/fcsr CSRs in every
  mode (six Ok's at FS=Off before, six refusals now; Sail's decode-time
  placement measured — the instruction side is the binds' `fp_enabled()` hook), and fcsr's two-owner view composes (read:
  fflags[4:0] with frm[2:0] above; write: split back under each owner's own
  table, frm's one-of 0..4 judging its slice) — the pre-slice engine read 0 and
  refused writes. FP-CSR writes mark FS=Dirty (Sail's write_fcsr precedent); SD
  follows, being computed. The corpus gains fp-fs-off (the gate cells, the
  transitions, SD observed) and fp-fcsr-view (compose/split/retention), 103/103,
  EVD-05 spec-side; the FS=Off INSTRUCTION cells are the bind's — no FP
  instruction decodes yet, measured. The 101 pre-slice guests run byte-identical
  against the parent engine (both CLIs, 5,491 trace lines; the RED control —
  the new guests MUST diverge there — caught the identity harness's own
  option-syntax bug first). DERIVED-COUNTS 430→431; `make check` rc=0, `make
  gate` green, bench wasm + smoke-bench + both books. Next: slice (c) — THE F
  BIND (30 forms + pseudos — the `.4`/`.6` bind shape).

- `2026-10-06`: `.7` slice (a) done (`SEMULITH-P4-0039`) — **rustc_apfloat QUALIFIED**
  by measurement: the arithmetic core (add/sub/mul/div/fma values, all 5 modes,
  both widths) is MPFR-exact over 63,752 probe cases; the 612 value + 386 flag
  disagreements are all named — the model-layer policy surfaces (NaN→int 340,
  fmin/fmax 240, NaN payloads 32) and the two LLVM-vs-IEEE deviations (opOverflow
  only for ±inf results; no NV on sNaN conversions) — all fp.rs's by name.
  softfloat fails ARCH §6 on capability (no rounding modes, no flags, no FMA, no
  64-bit conversions, no min/max) while measuring MPFR-exact where it exists
  (the 68 disagreements are all its NaN-sign convention). The MPFR path: the
  system libmpfr 4.2.2 via a scratch C generator, its semantics corrected
  spec-side (RNDNA, exponent-range OF/UF, NaN canonicalization, NAN ≠ NV).
  Licenses/provenance measured from the extracted crates (Apache-2.0 WITH
  LLVM-exception, LLVM APFloat f3598e8f / MIT OR Apache-2.0, musl-libc lineage);
  three lineages, none Berkeley. The decision record lands
  (decision_fp-backend-qualification.md + INDEX + the PROMOTED knowledge card);
  the dependency pinned (`=0.2.3+llvm-462a31f5a5ab`, Cargo.lock 4→7, on-volume
  cargo home, the re-export compile-use). `make check` rc=0, `make gate` green
  (DERIVED-COUNTS 430), bench wasm + smoke-bench 53 arms + both books. Next:
  slice (b) — the FP state with the FS=Off corpus.

The entries for the closed leaves live verbatim in the archive: `.1` and `.2`'s
slices (a)–(f) in [`archive/P4-SYSTEM-2.md`](archive/P4-SYSTEM-2.md) (the twentieth
crossing), `.6` there too; `.2`'s slices (g)–(h), `.3`, `.4` and `.5` in
[`archive/P4-SYSTEM-3.md`](archive/P4-SYSTEM-3.md) (moved `2026-10-06` at the `.7`
slice-(c1) crossing — the ceiling obeyed, not raised). Only the ACTIVE leaf's entries
stay inline above.
