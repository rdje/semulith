# P4-SYSTEM — evidence archive 12

Captured from 2c3ef6b3cecb9d691102f0d13926210061d10893 (P4-SYSTEM.14 a3).
Source docs/tasks/P4-SYSTEM.md: 117546 bytes, 1468 lines,
SHA256 b3a1e477c3e36b45c35ac17888b6ab93f82d9424c205642c3049598fe0d51c15.

Five complete closed-.13 spans preserve 76064 bytes in
original order: execution designs/census, acceptance, verification, commits and
changelog, including their older history routes. The complete task graph, .14
prerequisites/receipts and live frontier remain in docs/tasks/P4-SYSTEM.md.
Historical next/current/status wording here never overrides current canonical
records. .13 closed at SEMULITH-P4-0191:114/114 checks and frozen v2.

Extract each payload after its BEGIN marker newline and before the extra newline
preceding END. Authenticate its stated bytes and SHA256. Replace only the five
new live history routes with those payloads, then remove only a3 ownership and
new receipts to reconstruct the named committed source byte-for-byte/in order.
The owning leaf records the complete inverse and damaged-byte/marker/payload/
route controls. Prior archives/history remain immutable; all local caps stay fixed.

## designs

<!-- BEGIN designs bytes=59895 sha256=2ab200399f3d39de9db978c3d1cc0a46722f0fd8d60d87e2769d8850fa66f88c -->
### `.13` execution plan (`2026-10-09`, `SEMULITH-P4-0105`)

Ownership precedes changes. Read ROADMAP P4, CPU_ENVIRONMENT, the v1 book chapter,
ENVIRONMENT, all 55 obligation records, version membership, registry/tests, typed
boundary, FlatMemory and the GC runner before implementation. The shared
gate_report.contract_measure reports 53 effective obligations / 106 checks,
20 realized. Frozen v0/v1 records and pins must remain byte-identical.

Bounded units, each verified and committed before the next:

1. **Census/design**: enumerate effective records with their actual realization
   method, remaining boundary assumptions and stale statements. Resolve questionable
   wording with a diagnostic before classifying it. Produce the user-readable v2
   plan and a reproducible inventory; no premature G-CONTRACT credit.
2. **Versioned declarations**: add unit-specific boundary assumptions and replace
   stale inherited records in open v2, preserving every frozen line. Re-answer the
   hidden-state consequence against the actual state inventory. Each declared
   contract violation must remain distinct from a target exception.
3. **Scope checks**: realize dossier/configuration obligations with explicit static
   predicates and independent negative controls; extend the registry to name what
   actually runs. A passing unrelated guest cannot realize a scope declaration.
4. **Execution/boundary checks**: bind remaining guarantees to discriminating corpus
   or direct typed-boundary fixtures; add missing fixtures where the census finds
   no adequate evidence. Run every registry entry and refuse missing/misbound ids.
5. **Signoff/freeze**: only after all effective checks run, freeze v2 with exact
   member pins, regenerate GS, verify the gate's verdict and full local CI, then
   close .13. .14 retains requirement-status/experiment-record/registration work.

Completed b1 through c7 design/ownership receipts are preserved verbatim in
[`archive/P4-SYSTEM-7.md`](archive/P4-SYSTEM-7.md#completed-designs).

Completed c8–c16 designs are preserved byte-verbatim in
[`archive/P4-SYSTEM-7.md`](archive/P4-SYSTEM-7.md#runtime-designs).

Completed c22b–c25 designs: [archive/P4-SYSTEM-9.md](archive/P4-SYSTEM-9.md#design-a).

Completed c26a–c29e0 designs: [archive/P4-SYSTEM-10.md](archive/P4-SYSTEM-10.md#designs).

Completed c29e1–c33b designs: [archive/P4-SYSTEM-11.md](archive/P4-SYSTEM-11.md#designs).



### `.13` c33c — contain completed task receipts (completed, SEMULITH-P4-0183)

Owned on clean92c5855/brief0/actual census rc=0 after complete D. Full tracked
family census: tasks82/2914171B, live127192/131072B; book51/523390B leaves898B.
Before new reservation/SC code, transfer five whole completed c29e1–c33b
spans (designs, acceptance, verification, commits, changelog) to finite new
archive/P4-SYSTEM-11.md with exact lengths/SHA/source order. Preserve every
retained live byte and active .13/.14 ownership/frontier/census; dated active/
next wording in source is historical, D parent now complete. Authenticate full
committed127192B inverse; corrupt/absent-marker/omitted payload controls must
refuse. Prior archives/sealed history and core/data/canonical/frozen/registry112/
effective110/114/LIVE remain exact. No cap increase. Small worked book route,
live receipts/pointers/index, focused gates/six books and clean workflow.
Next own atomics-book introduction containment before reservation/SC examples;
retain current feature explanations/commands/tables and all public evidence.

Result:

Full tracked-family census on clean92c5855: tasks82/2914171B, live127192B;
book51/523390B. Five whole completed c29e1–c33b spans82856B move verbatim
in order to archive11/84762B SHAee6d39437ea5a5ee5d3ea981665b486e3db29f68987f00faea04da9296ad8302.
Live partition46007B before receipt. Full committed127192B source inverse
SHA6e0c4fe3b78d09da814fbc3937b935b441111c34a0c004ece5e99a8ab71119e9 exact;
corrupt byte/absent marker/omitted payload controls refuse. Retained live
segments/.13/.14/frontier/census and prior archives/history exact. Source's D
parent active wording is historical; c33b completed it. No cap increases.
Initial scratch ownership delimiter omitted surrounding inserted newlines;
exact common prefix/suffix diagnostic identifies the whole1093B insertion,
then source authentication passes before archive credit. No project data lost.
Verifier/focused/six books rc=0; core/data/canonical/frozen/registry112/effective
110/114/LIVE exact. Prior Rust173/17/242 applies: no runtime change. Book worked
route/index/live pointers sync. Evidence target/p4-system-13/c33c. Next own
c33d atomics-book timeline containment before reservation/SC examples, then
reservation/SC/full CI/freeze; .14 priority provenance/note sweep still owned.
promotion: declined (finite source-specific inverse and worked archive example retain this existing containment method).


### `.13` c33d — contain atomics timeline before final pairs (completed, SEMULITH-P4-0184)

Owned on clean2c5a9fd/brief0/actual census rc=0. Governed book51/523938B
leaves350B; live task49054B/131072. Read full atomics chapter, current A
semantics/selected reservation policy, public guest syntax and v2 counts.
Preserve whole original introduction before Direct contract observations in
new finite archive/P4-SYSTEM-book-c33d.md with source/payload length/SHA and
complete chapter inverse. Replace timeline by current22form/ordering/width/
LR-SC/AMO/fault-policy explanation, worked syntax and public evidence limits.
Qualify last c29a checkpoint102/114 as historical with current contract route;
preserve that whole original paragraph too. Retain all other original headings,
tables/fences/feature examples/public observations byte-exact, prior archives/
history/core/data/canonical/frozen/registry112/effective110/114/LIVE exact.
Corrupt/absent-marker/omitted controls refuse. No bound grows. Full tracked
family/part census, worked inverse route/index/live receipts, focused/six books,
clean commit before reservation/SC/full CI/freeze; .14 sweep stays owned.

Result:

Governed book51/523938B leaves350B on clean2c5a9fd. Preserve whole original
7179B atomics introduction plus440B c29a checkpoint paragraph in finite
8886B archive SHA80c1896a54884aa9cd955eddd3ee372b2937ee7239de02bd61fbc88365d854a3.
Full14853B committed-source inverse/order SHA2da8559ebe63d0b838ee8e16e5f62da0908a716142278c2c9ee1a4e662c22461
exact; corrupt/absent-marker/omitted-payload controls refuse. Chapter14853→
10769B saves4084B. All original headings/tables/translation fence/direct and
public evidence body byte-exact. Current22forms/nineAMOs/W-D/aq-rl/physical
width-valid reservation/selected LR-SC/fault rules and public evidence limits
remain explained; new three-step syntax yields oldwordSExt/SC0/readback42.
Canonical assembler22forms/88ordering words and independent-author worked
sequence exact. Initial scratch unpack assumed a pair; published assemble API
returns a list of(word,text), corrected before any syntax credit. No model fault.
Scoped own-script review finds assembler module docstring's ancestry/semantic-
independence assertions, rootb8d09f53; .14 priority repair owned before evidence
signoff. Canonical encoding route returns before upstream-table fallback.
Verify/focused/six books rc=0. Prior archives/history/core/data/canonical/frozen/
registry112/effective110/114/LIVE exact; prior Rust173/17/242 applies. Current
c29a count explicitly historical, live v2 route; book worked inverse/index/
pointers sync, fixed caps. Evidence target/p4-system-13/c33d. Next own c34
reservation witnesses, then SC/full CI/freeze; .14 sweep remains scheduled.
promotion: declined (finite source inverse, permanent public examples and named .14 repair preserve this existing containment/evidence discipline).


### `.13` c34a — witness reservation histories before binding (completed, SEMULITH-P4-0185)

Owned on cleane8163fe/brief0/actual census rc=0. Review frozen OB-RESERVATION/
REQ-D-RESERVATION, current state/semantics/public reservation/step interfaces,
existing A full-state fixture and companions, atomics/v2/ENV books. Governed
book520166B leaves4122B; DEV30682B below36864health, fixed caps.

Source/consumer prerequisite: root495b4b8 copied the "exactly the specification's
one-hart set" invalidation phrase into decision D-RESERVATION, requirement
REQ-D-RESERVATION and frozen OB-RESERVATION (460e4d8 only partitions it).
Authenticated A12.1.2/12.1.3 SHAafbd8def7bdf64287ef51a9cb14dd654fba0f0cfeef63bccdfd47408f5b0dff2
states reservation-set/aliasing latitude and occasional SC failure; trap
retention is this laboratory's selected policy, not a universal ISA command.
Current core/book already distinguish the selection. Own correcting all live
mirrors via a frozen-safe open-v2 supersession at c34b, before binding credit.
Consumer tests automatically require every v2 member realized; do not weaken
that selector for a declaration-only intermediate commit. Safe subdivision:
c34a witnesses/diagnostic only, unbound; c34b adds the qualified decision/
requirement/v2 record and its2Execution bindings together. Reuse pending
CHK-RESERVATION-POS/NEG under new OB-GC-RESERVATION-V2; preserve frozen v0/v1
bytes, prior112registry and effective110/114 until c34b completes.

Refine finite matrices before code. Reuse parent atomics private observer/
auditor and literal initial state in child module, expectations built before
execution, including complete GPR/FPR/26CSR owners/PC/mode/reservation retained
fields/TLBcursor/wait/full memory/exact cumulative requests/retirement/extent.
Ordinary histories cross W/D,4aq-rl,M/S/U,rd0/6/7/9 and selected literal data;
LR replacement, matching/wrong-address/width/no-LR/intervening-SC behavior,
success AND failure clearing seen by a following SC, selected ordinary overlap
preservation. Public companion trapped-SC/recovery remains; direct misaligned,
unmapped/refused and translated LR/SC faults preserve prior reservation with
precise kind/cause/VA/request termination. Physical alias fixtures use distinct
VAs mapped to same/different PA, repeated SC translation-cache hits, literal
PTE/TLB outcomes. Choose exact bounded counts in refinement before implementation.
Well-formed wrong instruction effects and bad capture components must fail;
actual disabled reservation establish/clear/match/trap preservation/request/
auditor paths must fail then byte-restore. Pair histories must discriminate
mutator defects even if the literal expected reservation uses public state
construction helpers. No production matches result constructs expectations.
Independent author/assembler/new matrices and all167/5365/10524 prior corpus
exact; public evidence scope explicit. Rust/focused/six books and current
examples/live docs, clean commit before c34b record/bindings; .14 sweep owned.


C34a source review reproduces a physical-permission defect before binding:
cold SC.W to unmapped0 retires with rd1 in the public core step (only2fetch
parcels), while the independent author traps cause7. Two fresh Sail calls
produce4byte-identical cause7 traces; two public Spike runs rc=0 produce
identical raw trap_store_access_fault/tval0 logs. Authenticated A12.1.2
norm:sc_retire_permission requires memory permission before SC retirement;
RVWMO's absence of failed-SC memory operations does not remove that check.
Root495b4b86 returns1 after translation and before any Store; own Environment
trait has only request, with no physical permission-only operation. Author
root022f5575 checks the laboratory region before reservation match. This is a
core/boundary gap, not evidence of an author fault or a reference-lineage claim.
Reproduce target/p4-system-13/c34a/sc-diagnostic.py, sc-public.py, sc-spike.py;
all temporary Rust diagnostic bytes restored, fresh binary identity recorded.
Priority next c34b0/SEMULITH-P4-0186, before any reservation/SC binding:
provide a side-effect-free physical store-permission boundary operation,
version its open-v2 contract without editing frozen v0/v1, and discriminate
unmapped/refused nonmatching SC without issuing a data Load/Store. Audit all
public adapters, snapshots/request consumers, existing contract witnesses and
independent author refusal semantics. Retain target exceptions versus provider
violations, VA trap payload, reservation trap-retention and precise request
termination; require defect RED then repair GREEN, actual disabled guard RED,
focused/full Rust/book gates. Scope refinement after clean c34a commit; do not
dirty-pivot or leave a merely reported defect. C34a's finite selected cells do
not cover this unresolved no-match physical-permission cell and add no binding
credit. C34b record/binding work follows the repair, with IDs renumbered as needed.

C34a finite refinement before code (counts independently recomputable):
- Bare multiplicity1152 =2widths×4ordering×M/S/U×4destination layouts×
 4literal parent vectors0/1/2/7×3SC sources(x9/address/x0). LR destinations
 0/6/7/9 include rs1/source aliases; first SC destinations0/10/9/7 include
 its rs1=x10/source=x9. Independent later address registers retain addresses.
 Seven histories with lengths4/4/3/3/3/2/4: two LRs at distinct addresses then
 old-address SC failure; two LRs then new-address success; wrong-address SC;
 matching SC; mismatched-width SC; invalid retained/no LR; same-address LR
 width replacement. Every completed SC is followed by a must-fail SC, proving
 success/failure clear. Each expected SC outcome is scenario-literal, never
 Reservation.matches. Totals8064histories/26496boundaries/13824data requests.
- Six preservation histories LR→overlap SW/SD/FSD/AMOADD or ALU/FENCE→matching
 SC→must-fail SC, same1152multiplicity:6912histories/27648boundaries/19584data
 requests. Full surrounding bytes and all other state prove selected ordinary
 overlap retention; both narrow/full writes and non-data operations covered.
- Physical aliases: same/different PA×2width×4ordering×4dest×4vectors×3sources
 =768MPRV-S sequences LR→SC→repeated SC,2304boundaries/1152data/4608walks.
 Two distinct VAs map to PA5000 or separate3000; repeated SC must use cached
 translation, with literal permission/TLB/FIFO state and no repeated walk.
 Positive total15744sequences/56448boundaries/34560data/4608walks.
- Bare faults: LR3faulttypes×4prior reservation states×2width×4ordering×
 3modes×4dest=1152; SCmisalignment×4states=384; SCunmapped/refused with
 matching reservation=192. Total1728boundaries/960data requests. A nonmatching
 Bare SC need not issue a Store; do not invent a provider fault without one.
- MPRV-S translated faults: LR5bad leaf states (V0,W-only,X-only,A0,U/SUM0),
 SC7 (same plus R-only/D0), each×2width×4ordering×4priorstates×4dest=1536.
 Walk refusals at each of3levels×LR/SC×samewidth/order/priorstates/dest=768.
 Data refusal: LR4priorstates/SC1matchingstate×2width×4order×4dest=160.
 Total2464translated boundaries/160data/6624walks, precise LR5/13 versus
 SC7/15 causes, full VA and trap stack. Prior valid/invalid-retained/cold/
 different-width reservations are compared exactly; no external event added.
 Negative total4192boundaries/1120data/6624walks. Combined60640boundaries,
 121280parcels/35680data/11232walks=168192requests, all expected before stepping.
Actual-control refinement before mutation: ten common full-state judge predicates
(requests/memory/x/f/CSR/reservation/TLB/wait/PC-mode/extent), six reservation
helper mutations (establish/clear/valid/address/width/always-fail), trap clear,
pre-translation nonmatch bypass, LR cause, SC alignment, request logging, global
TLB install and ordinary-store clearing:23 actual disabled controls, each must
fail a named new test rc=101 for an observed assertion, then restore every byte.
Export all prebuilt plans before stepping in temporary diagnostic code, restore,
and cross-derive each architectural boundary with the independent author plus
canonical assembler words. That author does not observe explicit data requests
or invalid retained reservation fields; direct full-state/request witnesses do.
Keep this as a safe unbound prerequisite; c34b's frozen-safe declaration mirrors
and2bindings must land together because the completed selector admits all v2.

Result:

Unbound reservation-history prerequisite:15744positive sequences/56448boundaries
and4192fault boundaries, total60640/121280parcels/35680data/11232walks/168192
requests. All expectations precede execution. Seven replacement/clear/width/
no-LR histories, six ordinary-overlap/ALU/FENCE preservation histories and
same/different-PA aliases cross widths/orderings/destination/source aliases and
literal values; faults compare prior valid/invalid-retained/cold states. Complete
GPR/FPR/26CSR owners/PC/mode/memory/reservation retained fields/TLBcursor/wait/
requests/outcome audited.16well-formed wrong effects,16bad captures and23actual
disabled guards fail; finally byte-restored, paired SC literals discriminate
global establish/clear/TLB helpers despite their expected-state use.
Independent author cross-derives all60640prebuilt boundaries and canonical205
words;167/5365/10524 prior corpus exact. Author omits explicit data requests and
invalid retained reservation fields; direct observer owns those. Temporary
export code restored. Initial scratch assembler check passed raw field counts
where public LR/SC syntax needs ordering suffixes/parenthesized address; fixed
before syntax credit, no model defect inferred. Rust173/17/246, focused13and
six books rc=0. Core/data/canonical/frozen/archives/history/LIVE and prior112
registry/effective110/114 exact. No new binding or conformance/lineage credit.
Source prerequisite roots495b4b8/460e4d8:3mirrors incorrectly universalize
selected invalidation/trap policy. Consumer admits every non-v0 obligation;
c34b must qualify live mirrors and add a frozen-safe v2 replacement with its
2bindings together, never weaken that selector.
New owned defect: cold Bare SC.W to unmapped0 retires rd1 in core; independent
author and4fresh public Sail traces/two public Spike raw logs trap cause7/tval0.
Pinned A12.1.2 requires memory permission before SC retirement. Root495b4b86
returns1 before any physical boundary request; Environment offers no permission-
only operation. Root022f5575 author checks region before match. Public binary
identities/fresh successful runs/repeats recorded; no dependency internals read.
Next priority c34b0/0186 repairs this side-effect-free physical permission seam
before binding; refine scope on clean commit. Existing finite witness cells
exclude this unresolved no-match cell. Named .14 provenance sweep remains owned.
Evidence target/p4-system-13/c34a; fixed caps, no push below cadence.
promotion: declined (finite full-state witnesses reuse the existing contract method; newly measured permission defect has immediate owned repair before binding).



Completed c18–c22a designs: [archive/P4-SYSTEM-9.md](archive/P4-SYSTEM-9.md#design-b).

### `.13` c34b0 — check physical permission on failed SC (completed, SEMULITH-P4-0186)

Owned on clean691c608/brief0/actual census rc=0 after c34a. Re-read pinned
A12.1.2 norm:sc_retire_permission, the own Environment/SC/FlatMemory boundary,
all Request consumers (rg -l Request:: crates), generated refusal interface,
request shape/address/data/event/order fixtures, reservation/atomic witnesses
and current atomics/v2/environment books. Roadmap .13 closes no guarantee
without actual executable checks; newly measured unmapped-SC defect is priority
before reservation/SC binding. Do not inspect dependency implementations.

Smallest seam: add Request::StorePermission{width,addr} and corresponding void
Response::StorePermitted. It validates physical write permission with no byte
read/write, counter fetch or target event. Only a nonmatching SC issues it,
after alignment/Store translation and before clear/rd1/retirement. Matching SC
keeps its Store, which already validates permission. Permission failure takes
cause7 with original VA and preserves reservation/rd; wrong response/typed
provider violation remains ModelError, never target trap. No Store/Load is
invented for failed SC. FlatMemory checks full aligned region and returns void;
all forwarding/scripted providers preserve observable request/answer kinds.

Extend already-open v2 address/data/event statements and their bound executable
pairs, keeping12members/prior112registry/effective110/114 and frozen v0/v1 exact.
No extra unbound record or selector exemption. GC experiment refusal category
Store includes explicit writes and permission checks at the same physical byte
span; update the generator-owned public comment and regenerate exactly that
comment, retaining every guest image/value/fetch/refusal datum. This matches the
independent author's existing pre-match region/store-refusal permission check;
direct providers can still distinguish actual Store from StorePermission.
Census records permission checks separately from explicit data stores; GC
snapshot/replay remains explicitly unsupported, no serialization scope added.

Before repair add permanent unmapped cold-SC witness and require RED101 at the
trap/full-state assertion, then fix. Expand finite W/D×4ordering×M/S/U×
4destinations×4nonmatching prior states at aligned mapped/unmapped and refused
permission boundaries; translated success/failure uses PA in request and VA
in trap, repeated cached SC has no walk. Matching success/refused Store,
misalignment/translation faults before permission, and malformed permission
answers distinguish the branches. Extend bound boundary width/edge/no-effect,
address high-bit and every-kind event fixtures. Actual skip-permission,
permission-as-Store, fault-as-failure and malformed-as-target mutations must
fail named tests, then restore. New API is side-effect-free by provider bytes/
full-state/request audits, not a name-based claim.

C34a's unchanged architectural cells gain20736permission-only requests
(19584Bare+1152aliases), so60640boundaries/121280parcels/35680data/11232walks/
20736permissions=188928requests. Parent A adds960permission checks, direct
12168boundaries/24336parcels/46800requests. Re-derive exact counts, retain all
numeric/architectural outcomes, prebuilt independent author/canonical words/
full prior corpus, core response matching and refusal adapter controls.
Rust/focused checks/full local CI for this boundary milestone; synchronize
current book examples/limits and live docs, with fixed caps. Then clean commit
before qualified reservation supersession/binding, SC/full CI/freeze and .14.

C34b0 full-CI diagnostic (owned before provider repair): the first full CI
and focused run stop at DEF-GEN. Running check_definition_gen.sh --self-test
rc=1 reveals52pass/4fail: the standalone C-only probe's exhaustive Memory
provider does not handle the new StorePermission enum variant (E0004), so its
GREEN and3behavioral RED controls never compile. This is integration scope,
not evidence that the generator lost discrimination. Extend that C-only provider
with an explicit unexpected-SC permission panic, retaining all18C checks and
three compiled behavioral mutations. Preserve failed logs, rerun sequentially;
credit full CI only after all five legs actually complete. No wildcard escape.
Repair validated: full make ci rc=0, including the18C-only probes and all
3compiled behavioral mutations through DEF-GEN. Failed logs retained as
ci-integration-red.log/focused-integration-red.log; no generator/input change.

C34b0 refinement: permanent defect witness first RED101 (rd changed instead
of trap). A temporary raw-CSR diagnostic then found the reused parent trap
expectation retaining MPRV in a Bare case (difference0x20000); that helper is
for translated AMOs. Build mode/status-specific literal expectations, not from
actual output. All12atomic tests now pass, including1152Bare+384translated
permission cells,80malformed answers,8provider-misalignment answers and1
refused-data-Store no-issue cell:1625newboundaries/3250parcels/1152walks/
1625permissions,6027requests. No data access in these cells.
Strict compile identifies two exhaustive test providers; extend the GC walk
provider and explicitly refuse the GC-only kind in the RV64I-only fixture.
Three pre-existing wrong-SC table controls now fail first on the added request
rather than the later reservation difference. Update those expected reasons;
keep independent corrupt-reservation captures/actual disabled auditor controls.
Actual-control refinement: skip permission, permission-as-Store, target-fault-
as-failure, malformed-as-target, permission-region bypass and provider byte
write behind StorePermitted:6new RED101 controls then exact restoration, plus
all23prior actual guards under the new request shape. All structural/numeric
outcomes remain checked before source or registry credit.

Result:

Repair root495b4b86's failed-SC physical-permission gap. Before code repair,
permanent cold unmapped-SC test RED101: rd changed instead of trap. Core now
requests side-effect-free StorePermission after Store translation on nonmatch;
only StorePermitted permits clear/rd1/retirement. Target refusal traps7 with
original VA and preserves prior state; malformed replies remain ModelError.
Matching SC retains Store's permission check. FlatMemory checks full aligned
span without byte access/fetch increment; forwarding, scripted, refusal and
census adapters cover the new kind separately from explicit data stores.
Open-v2 address/data/event statements and bound fixtures extend together;
12members/prior112registry/effective110/114 and frozen v0/v1 exact. Published
Store refusal category includes permission checks; generator-owned comments
and fingerprints regenerated, all guest arrays/data/canonical expectations exact.
Independent author already checks region/store-category refusal before match;
its explanatory comment now states the category, not an invented data write.
New1625full-state boundaries/3250parcels/1152walks/1625permissions=6027requests:
1152Bare+384translated permission cells,80malformed replies,8provider-misalignment
answers and1unissued-Store control. Independent author1536architectural cells/
32canonical words and prior167/5365/10524 exact; provider-contract answers and
invalid retained reservation fields remain direct evidence. Prior60640boundary
architectural expectations unchanged, now20736permissions/188928requests;
parent A gains960permissions/46800direct requests, no data/value change.
Six actual permission controls plus all23prior guards RED101 then restored;
valid StorePermitted with a hidden byte write fails memory audit. Initial
fault-control needle expected GPR change, but first rd0 case reports CSR owners;
corrected before credit, no lost control. Temporary export code restored.
Raw-CSR diagnostic identifies new Bare expectation's reused translated-AMO
MPRV0x20000; replace by independent mode/status literals. Three old wrong-SC
table controls now name the first extra permission request; independent corrupt-
reservation captures/disabled auditors still discriminate. Two exhaustive test
providers and the standalone C-only provider extended explicitly; no wildcard.
Rust173/17/253, focused14,
full make ci all five legs and six books rc=0. All other core/definition/data/
canonical/frozen/archives/history/LIVE and prior registry exact. Current book/
ENV/report/pointers sync, fixed caps. Evidence target/p4-system-13/c34b0.
Owned c34b1 documentation defect discovered while preparing containment:
rg current C chapter finds present-tense "Contract realization stays98/114"
(spaced source text), rootd8925716 at c.md:433, although gate_report measures
110/114. Impact: book review misstates current realization. C34b1 will replace
that historical tail with an explicit current-report route, preserving the exact
old receipt in its source inverse. No runtime or reference agreement change.
Next own c34b1/0187 book/development containment before qualified reservation
supersession+binding, SC/full CI/freeze and priority .14 sweep; book has569B
room before final receipts. No new G-CONTRACT or reference-lineage credit.
promotion: declined (the existing boundary/full-state method owns this defect, repair and discriminating controls; no new knowledge card needed).

### `.13` c34b1 — contain C chronology and append-history heads (completed, SEMULITH-P4-0187)

Owned on clean c538c6e, brief0, actual handoff census rc=0. Read roadmap P4
acceptance dependency, current C chapter in full, assembler byte-image/budget
interfaces, own C definition and .13/full-state/request book context, bounded
archive and append-history policies. Scope is review documentation; current
Rust173/17/253 and full CI green at c538c6e apply. No implementation change.
Book51/523719B has569B remaining; DEV35639B approaches36864B health and
CHANGELOG54373B exceeds49152B health. Fixed caps must remain unchanged.

Replace the completed C implementation chronology with a stable, thorough
current feature guide:37selected forms, operand expansion/specificity, exact
parcels/ILEN/fault precedence, hints/reserved/FS rules, sized assembler and
worked mixed-length values, independent author/finite controls and current
167guest/200spelling scope. Preserve the complete original chapter byte-verbatim
in a finite tracked task archive with source SHA/length and exact inverse.
Keep public reference commands, results and limits live. Rootd8925716's old
present-tense98/114 tail becomes an explicit current-report route; archive it
as historical evidence, never silently substitute a new reference result.

Use the public sharder to move only oldest whole DEV/CHANGELOG entries to
new0232/0233 shards, below health with working room. Prove old head = new
head+payload, entry/order equality and unchanged predecessor manifest/history;
corrupt/missing capture and lost payload controls must refuse. Do not alter
sealed archives, registry caps, frozen contracts, canonical code/data or LIVE.
Verify all37canonical C spellings and independently author the worked mixed
program before documentation credit; full prior corpus must remain exact.
Run focused docs gates and six books, update live pointers/receipts, clean
commit before qualified reservation supersession+binding, SC/full CI/freeze.
Evidence target/p4-system-13/c34b1. No new contract or reference-lineage credit.

Result:

C chapter29216→12173B, saves17043B. Preserve full29216B source
SHA9b5a2b0e9de88eebc917e745d5d0ac755fd0edf737cd058d83100ea1c9254fcc in finite
30513B archive SHA18718b7a601326fefeba105c5e0ba70f0bebba7b721dee2abba6caf9147b21a2.
Original25253B chronology prefix becomes8133B stable current guide, retaining
all37selected forms, mappings, decoder specificity, hints/reserved/FS rules,
parcel/ILEN/fault behavior, sized APIs, independent author/controls and current
scope. Receipt helper first stopped before writes on an absent heading guard,
then on a row prefix shared by verification/commit tables. Remove the unused
heading and anchor the actual commit row at line start; rerun with set-e.
Public reference section remains exact except rootd8925716's old98/114
present-tense sentence now routes to the current contract summary. No changed
reference result or lineage claim. Complete inverse reconstructs the committed
source; corrupt capture, absent marker and omitted payload refuse.
Worked c.li/c.addi/ADDI/c.mv image0d447d14930444002685:10bytes,
4boundaries/5parcels at offsets0/2/4/6/8, final x8/x9/x10=2/6/6 and PCentry+10.
Literal encodings, all37hand words/21operand refusals and independent author
verify the example; full167/5365/10524 prior corpus remains exact.
DEV6whole entries→0232, 35639→23836B before this receipt;
shard12036B SHA976cb0212d13a554200163da6100e4892e5a6552891a6f3b0a320a5203eed6f7; original head
SHAaf5074ac049dcac141d37d4a31aed563547e5861e2aa7a6acb69becee90f1c1a. CHANGELOG23whole entries→0233,
54373→40882B; shard13728B
SHA546cfd2f71aff48f99a83d09d65dbc73f2d343a3917178c41a99cca830c82d86; original head
SHAbd280482e0080eb57f26a710efb148d5838ff13d165ac7a0081f690345f49534. Both exact byte/order inverses; two lost-payload
controls refuse. Prior23manifest rows exact, now25live+210sealed=235logical.
All prior code/data/canonical/frozen/contracts/registry112/effective110/114/
archives/sealed history/LIVE/caps exact. Derived book index follows current
headings/terms. Focused8docs gates and six books rc=0. Governed book51/
506676B leaves17612B room; tasks85/2995432B before final receipts, max130981B.
DEV25532B and CHANGELOG41562B stay below health; fixed caps unchanged.
Optional git diff --check rc=2 names only retained DEV/CHANGELOG entry
separators newly at EOF. Direct source comparison confirms those exact newline
bytes predate this slice; retain them to preserve the whole-entry inverse.
All other changed files pass whitespace checking. No whitespace/source repair
is inferred from moving the unchanged boundary of a historical entry.
Then qualified reservation supersession+binding c34b/0188, SC/full CI/freeze
and owned priority .14 sweep. Evidence target/p4-system-13/c34b1.
promotion: declined (existing finite inverse, current-book and append-history controls own this containment and count correction; no new knowledge card).

### `.13` c34b — qualify and bind the reservation guarantee (completed, SEMULITH-P4-0188)

Owned on clean5c7080b/brief0/actual handoff census rc=0 after c34b1. Read
roadmap P4/.13, authenticated pinned A12.1.2 (56889B/SHAafbd8def), current
D-RESERVATION/REQ-D-RESERVATION/frozen OB-RESERVATION, reservation/SC core,
full-state reservation+permission fixtures, ExecutionCheck/registry/selector,
version membership and atomics/v2/environment books. Current registry112,
effective110/114; open v2 has12members, frozen v0/v1 unchanged. No dependency
implementation or pin inspection. Old3copies include the frozen record: qualify
only the2live mirrors and a new v2 replacement, never edit the frozen copy.

Root495b4b86's wording presents the selected invalidation/trap/width/alias
policy as exactly the specification's set. Keep the actual selected behavior,
qualify architecture versus laboratory authority, completed LR/SC versus traps,
physical exact-width matching and ordinary-instruction preservation. Physical
permission must precede completion/clearing. Source review also finds public
Reservation::matches comments calling its predicate the whole success rule/
architecture license; qualify that existing comment under this same owner:
public-comment blame root1c554fcf (76–80); live mirror roots495b4b86, frozen
partition460e4d8. Matching is the selected reservation condition, never a replacement for
alignment, translation and physical permission. No runtime semantic change.

Add OB-GC-RESERVATION-V2, superseding frozen OB-RESERVATION, reusing its
CHK-RESERVATION-POS/NEG ids. Membership13 and those2executable bindings land
together: the non-v0 completeness selector remains unchanged. Change only its
measured completed-check census112→114, then require an actual missing-binding
RED naming CHK-RESERVATION before adding the registry rows. Expected final
registry114/effective112/114; re-derive before credit. New metadata is laboratory
policy, not an independent/conformance result; keep every frozen record/pin.

Promote the60640full-state reservation boundaries to ordinary compiled
fixtures. Also promote the1536architectural physical-permission cases from
c34b0 into Result-returning fixture helpers, retaining the same5test entry
points and literals; malformed-provider80/misalignment8/unissued-Store1
remain direct tests plus existing bound environment checks. Positive execution
runs56448normal/alias boundaries; negative runs4192faults plus1536permission
cells (including their successful controls). Direct total62176boundaries/
124352parcels/35680data/12384walks/22272permissions=194688requests. Re-derive
counts and preserve expectations/205+32canonical words/prior corpus. Companion
pair/mustfail/fault guests use existing comparison, with no guest data change.

Existing16wrong effects/16corrupt captures and29actual guards must still
fail after promotion/refactor and restore exactly; production registry fixtures
must execute and propagate failures. Run strict Rust, focused profile/generator/
contract/doc gates and six books. Update current policy/examples/limits and
realization summaries, ENV/derived GS/current docs; protect all other canonical
code/data, historical archives/history/LIVE/caps. Clean commit before separately
qualifying/binding deterministic SC, full CI/freeze and owned priority .14 sweep.
Evidence target/p4-system-13/c34b. Any failed integration belongs to this slice.
Missing-binding control: cargo test exact completeness rc=101, one test:
OB-GC-RESERVATION-V2 declares CHK-RESERVATION-POS, no registry entry realizes it.
The census was deliberately114 before this run; selector unchanged. Now bind
both rows and promote the same prebuilt direct expectations, then require GREEN.

Result:

Qualified D-RESERVATION/REQ-D-RESERVATION and added matching laboratory
OB-GC-RESERVATION-V2. Frozen OB-RESERVATION remains byte-exact; explicit member/
supersession in open v2 gives13members, still57effective obligations/114checks.
Core public comments root1c554fcf no longer call matches the whole success rule
or architecture license; alignment/translation/physical permission are separate
preconditions. Actual CPU statements/data/semantics remain byte-exact after
comment removal. Live mirror roots495b4b86 and frozen partition460e4d8 recorded.
Completeness selector unchanged; census deliberately114 before missing-binding
RED101 naming CHK-RESERVATION-POS. Add2Execution rows under the new record:
registry112→114/effective110→112of114. All prior112rows remain exact.
Promote the same60640history/fault expectations and1536architectural permission
cells. Result-returning helpers propagate failures; five permission test names,
setup/values/trap formulas and89other direct cases retained. Sixteen wrong
effects/16corrupt captures remain discriminating. All29prior actual guards
RED101/restored, plus2new registered-route error controls RED101/restored;
normal full registry evidence GREEN0. No compile failure counted as a control.
Temporary census prints the4audited reservation families and1152Bare/384translated
permission counts through actual registered execution, then restores both sources
byte-for-byte. Full-state/request judges already compare actual to each prebuilt
witness:56448positive +4192fault +1536permission =62176direct boundaries,
124352parcels/35680data/12384walks/22272permissions=194688requests. Three unchanged
companions add85boundaries/170parcels. Old60640/205word and1536/32word independent
architectural derivations apply to unchanged expectation inputs; fresh full prior
167/5365/10524 corpus agrees. This does not reclassify numeric/reference lineage
or extend the author's explicit-data/invalid-retained-field observation boundary.
Strict Rust173/17/253 rc=0. Current atomics/v2/ENV/derived GS/index synchronized;
GS112/114, still incomplete/open and8of10CPU axes open. Boundaries and public
finite limits remain explicit. Frozen versions/pins, old registry/selector,
canonical data/guest arrays, archives/history/LIVE/caps unchanged. Profiles raw
member census delegates the two-tier per-part exemption to README-ROUTES;
fixed aggregate/file limits are also measured. Focused14/six books rc=0.
Book51/510708B leaves13580B; tasks85 stay within the fixed3MiB bound.
Then qualify/bind deterministic SC separately, full CI/freeze and priority .14
source/note sweep. Evidence target/p4-system-13/c34b. No push below cadence.
promotion: declined (existing full-state/boundary method, frozen-safe supersession and registered propagation controls preserve this qualification without a new knowledge card).


Commit integration defect (owned here before repair): pre-commit rc=1 rejects
RECORD-SCHEMA rule9: frozen OB-RESERVATION still mirrors the old requirement.
The focused14 set did not include RECORD-SCHEMA; DOSSIER-SCHEMA validates
shape, not the mirror relationship. Root3ceebc55 rule9 predates versioning and
checks every historical record against the current requirement. CONTRACT-FREEZE
requires old bytes retained; skipping all superseded ids would weaken the guard.
Repair only the authenticated frozen historical-mirror case: require an exact
pinned member and a valid inheritance/supersession route to a current replacement
which explicitly mirrors the same requirement. Live and unversioned mirrors,
malformed routes, altered pins and drifting/missing replacements must still fail.
Add durable RED/GREEN controls, include RECORD-SCHEMA in focused checks, update
its mdBook explanation and derived arm count; preserve frozen bytes and runtime
inputs. Verification and acceptance stay pending until the repaired gate passes.
Evidence target/p4-system-13/c34b/schema. No change of task-tree or scope credit.
Resolution: real-record defect RED1→GREEN0; new self-test61pass/0fail,
13new durable controls. The old guard, disabled pin predicate and disabled
current-replacement equality each make the self-test RED1 with its named MISS.
No tracked source is changed by these copied-script controls. Replacement now
explicitly names requirement_id; every frozen record/pin remains byte-exact.
Focused15 (now including RECORD-SCHEMA)/six books/final verifier rc=0.
Book51/511918B leaves12370B; largest part32768B. Prior Rust173/17/253 applies.
LIVE milestone rows unchanged; derived arm census only655→668. Commit complete
only after hooks pass, brief0, clean tree and actual job census rc=0.


### `.13` c34c — preserve authority in versioned requirement mirrors (completed, SEMULITH-P4-0189)

Owned on cleanb61ad39/brief0/actual handoff census rc=0. Before deterministic
SC, probe one suspected gate edge: rule7 follows requirement.obligation_ids,
while a superseding replacement names the requirement through requirement_id.
A replacement could mirror the exact architectural statement but downgrade its
authority to laboratory. Use a synthetic versioned catalogue through the real
RECORD-SCHEMA function; diagnose before classifying. If reproduced, extend the
authority check to explicit requirement mirrors without relaxing statement,
pin, inheritance or ordinary checks. Add one permanent rejecting control and
actual disabled-guard control; keep all current profiles/records/Rust/data/
frozen/history/milestones exact. Only the derived arm count may change.
Update the current doctrine explanation within its existing32768B cap, task/
live receipts and memory; focused record/doc gates and six books, clean commit.
Then deterministic SC c35/0190, full CI/freeze and owned priority .14 sweep.
Evidence target/p4-system-13/c34c; this is gate authority, not a CPU finding.

Diagnosis: defect-red.log self-test RED1 expected record rc=1 but actual0 on
OB-A-V2 with exact statement S/requirement category defined/authority laboratory.
Rootd3fecbf3 rule7 follows only requirement.obligation_ids; root3ceebc55 mirror
parameter and b61ad39 supersession route admit a replacement outside that list.
Resolved by checking architectural authority on explicit mirrors not already
checked by the historical obligation list. Equality/version/pin guards retained.
Self-test62/0; copied disabled actual authority predicate produces named RED1,
normal real catalogue GREEN0. No current CPU/profile record failure observed.
Fourteen version/authority controls now coexist with all earlier verdicts;
measured doctrine arms669. Only that LIVE count changes, every milestone exact.
Focused9docs/records, six books and final invariant verifier rc=0. Book51/511940B leaves12348B, largest32746B; fixed caps. Prior journal payload/order exact; no Rust change, prior173/17/253 applies.


### `.13` c36 — freeze the complete contract (completed, SEMULITH-P4-0191)

Ownership before changes: all57effective obligations/114checks ran green in c35;
registry116, v2 has14members. Read roadmap P4, .13 acceptance/design, contract
manifest/catalog, freeze judge, GS/report and current v2/atomics/ENV chapters.
Freeze only v2 with SHA-256 of each exact canonical record line (no newline),
preserving all v0/v1 bytes, obligations, registry/fixtures and CPU sources.
Judge the final frozen candidate with full `make ci` (five named legs/six books),
plus intact/edited-record/missing-pin/dropped-member scratch controls over v2.
Re-derive GS; require G-CONTRACT green while CPU-SYSTEM remains incomplete on
its other7axes. Close .13 only after signoff; activate .14 and synchronize all
frontiers/live/book records. No new independence or conformance claim; no push.
Verify prior frozen blocks, catalog/CPU/fixtures/history and fixed caps exact.
Evidence target/p4-system-13/c36, same-volume TMPDIR. Root/repair/regression
receipts must name actual tools and outcomes; promotion decided at signoff.

Result: freeze.py rc=0 derives14pins over exact expanded record lines (no newline),
intact scratch GREEN0; edited SC record/missing SC pin/dropped SC member RED1
with named causes. Real CONTRACT-FREEZE rc=0, v0/v1 manifest prefix exact.
Full `make ci` rc=0: Rust173/17/253; every doctrine/self-test, wasm bench,
headless smoke and all6books green. No runtime/canonical/fixture/catalog change.
GS derives114/114 effective checks and latest v2 frozen; G-CONTRACT green,
CPU-SYSTEM incomplete7/10axes. .13 acceptance met; .14 now owns the frontier.
Final docs gates/books/invariant verifier confirm closure and fixed caps.
Promotion: declined — canonical frozen pins, existing versioning judge and
current book/report retain the result; no new method or independence claim.

### `.13` c35 — qualify and bind deterministic SC (completed, SEMULITH-P4-0190)

Owned on clean64461b9/brief0/actual handoff census rc=0. Read roadmap P4/.13,
D-SC-DETERMINISTIC/REQ-D-SC-DETERMINISTIC/frozen OB-SC-DETERMINISTIC, pinned
A12.1.2/12.1.3, public reservation and SC execution, complete history/permission
fixtures, registry/completeness selector and atomics/v2/environment book sections.
The live SC wording and hidden-state reservation explanation omit alignment,
Store translation and physical permission as prerequisites to completed outcomes.
Qualify the selected no-spurious, exact-physical/exact-width success policy and
0/1 results versus traps; retain laboratory authority and architecture latitude.
The most recent completed LR and no intervening completed SC are represented by
the reservation's history, not an independent success license. No runtime semantic
change: update two live mirrors and reservation census explanation only, regenerate
inspection text/input fingerprints through public generators, preserve storage,
reset/legalization/definitions/guest data and all frozen bytes/pins.

Add OB-GC-SC-DETERMINISTIC-V2 with explicit requirement_id, superseding frozen
OB-SC-DETERMINISTIC and reusing CHK-SC-DETERMINISTIC-POS/NEG. V2 member14 and
both Execution bindings land together. Selector unchanged; measured selected
census114→116 must first fail specifically for missing binding. Expected registry
116/effective114/114; derive before credit. Both new Execution variants call the
existing full-state reservation/permission fixtures:62176direct boundaries and
194688requests are shared coverage, not additional unique cells or independence.
Positive companions pair+loop add25boundaries/50parcels; negative mustfail+fault
add71/142. Existing wrong effects/captures and31actual Rust guards must discriminate;
add2new SC registered-route propagation controls, restore exact source bytes.
Fresh registered SC census and independent prior167guest corpus, strict Rust,
focused15including RECORD-SCHEMA, six books, current policy/worked SC examples/
limits and ENV/derived GS/live docs. Protect every prior114registry row, all current
fixture inputs, canonical semantics, frozen/history/milestones and fixed caps.
Current book511940B leaves12348B, contract-v2 part31264B; put detail in atomics,
keep the main current count owner bounded. Any failed integration is owned here.
Then full CI and freeze in a separate signed unit; priority .14 sweep remains owned.
Evidence target/p4-system-13/c35; no new conformance/reference-lineage claim.

Result:
Root495b4b86 SC policy mirrors and reservation inspection explanation (current
source root6addc986) omit completed-outcome prerequisites. Authenticated pinned
A56889B/SHAafbd8def requires SC permission before retirement and permits wider
reservation sets/physical alias latitude/spurious outcomes. Qualify both live
statements; explicit requirement mirror OB-GC-SC-DETERMINISTIC-V2 supersedes
frozen OB-SC-DETERMINISTIC. V2 has14members. State explanation and exactly3input
SHA occurrences regenerate through gen_state/gen_definition; only one inspection
string changes, all storage/reset/legalization and instruction semantics exact.
Completeness census116 with identical selector first fails RED101 naming missing
CHK-SC-DETERMINISTIC-POS. Two new Execution routes then bind shared immutable
reservation/permission inputs and unchanged companions; prior114registry rows
exact. Registry116/effective114/114,57obligations; latest v2 still open.
Strict Rust173/17/253 rc=0. Existing16wrong effects/16bad captures remain passing
rejection tests.29underlying guards+2shared witness errors+2reservation routes+
2new SC routes each
RED101 and byte-restored; normal full registry GREEN0. Fresh isolated SC census
prints4audited families and1152/384permission cases through new Execution arms,
then restores3persisted source backups byte-exact:62176boundaries/124352parcels/
35680data/12384walks/22272permissionchecks=194688requests. Those overlap the
reservation pair fully; no new unique direct case or independence claimed.
Positive pair+loop25/50 and negative mustfail+fault71/142 companions unchanged.
Fresh independent167/5365/10524 corpus exact; earlier60640/205word and1536/32word
architectural derivations apply to identical expected inputs, not freshly
re-derived all62176cases. The author still omits explicit data requests and
invalid retained fields; direct observer owns them. Public mixed-width divergence
and reference lineage untouched. Independently hand-coded/canonical/author
worked alias history words1003332f/18a5352f/18a5b2af exact: LR replacesx6 with
old data; SC uses originalx10 as both address/source then setsx10=0; repeat
returnsx5=1, memory1080 and PC100c. Registered history3/width8/order0/(6,10)/
vector7/source10 exercises these fields/values. Atomics/v2/ENV/derived GS/index
sync; current policy distinguishes success/failure from traps. Focused15/six books/final verifier rc=0. Book51/516123B leaves8165B;
profiles521/3129663B and tasks85 stay within fixed caps. Prior CPU semantic expressions/canonical data/
frozen/history/LIVE/caps exact; inspection text/fingerprints only in core.
Next c36/0191 full CI and v2 freeze, then priority .14 provenance/note sweep.
promotion: declined (the current policy example, shared full-state witnesses, exact regeneration inverse and discriminating registered routes retain this finite binding without a new lineage claim).


### `.13` census and dispositions (slice a)

Reproduction uses the existing single owner, not another effective-contract parser:
`gate_report.contract_measure(Path("profiles/rv64gc-lab-v0"),
records_sexp.load(Path("profiles/rv64gc-lab-v0/contract-obligations.sexp")))`.
Group its declared `(obligation, check)` pairs by obligation; join records by id.
Measured 55 total records, 53 effective, 106 checks, 20 realized. The two excluded
records are the v1 supersessions OB-GC-PRIV-INSNS and OB-ECALL-EBREAK. JSON receipt:
`target/p4-system-13/a/inventory.json` (regenerable, not required by builds).

This table is the **planned realization**, not credit for checks not yet registered.
POS/NEG details must be reviewed against each guest's actual instructions and
expectations during slice d; a fixture name alone is insufficient evidence.

| Effective obligation | Registered checks | Planned realization / disposition |
| --- | --- | --- |
| `OB-GC-COMPOSITION` | 0/2 | Static: exact profile/encoding extension set |
| `OB-EXT-CLOSURE` | 0/2 | Static: dependency closure including D/F/Zicsr and Zca/Zcd |
| `OB-PRIV-REVISION` | 0/2 | Static: source ids, versions and digest pins |
| `OB-PRIV-MODES` | 0/2 | Runtime: mm-ecall-modes / mm-csr-legality-u; static mode set |
| `OB-SV39` | 0/2 | Runtime: sv39-translate-4k/2m/1g / sv39-fault-canonical |
| `OB-SVADE` | 0/2 | Runtime: sv39-translate-4k / sv39-svade; assert PTE unchanged |
| `OB-FAULT-PRIORITY` | 0/2 | Replace in v2: distinguish triggers from environment break |
| `OB-GC-PARTIAL-PROGRESS` | 2/2 | Registered: injected carrier/atomic/FP faults and CSR refusal |
| `OB-IALIGN-16` | 0/2 | Runtime: c-links / c-page-straddle; static ILEN/IALIGN |
| `OB-ZICNTR` | 0/2 | Runtime: mm-counters / mm-csr-ro-counters; static scope |
| `OB-SSTC` | 0/2 | Runtime: i-timer / mm-stimecmp |
| `OB-FP-DEFER` | 0/2 | Replace in v2: qualified backend identity and evidence limits |
| `OB-ABI` | 0/2 | Static: LP64D choice, pinned toolchain contract; no ABI-run claim |
| `OB-SBI` | 0/2 | Static: future firmware requirement; no implemented SBI claim |
| `OB-CSR-SET` | 0/2 | Static: all 33 CSR identities/storage/views; runtime permission fixtures |
| `OB-NO-PMP` | 0/2 | Static: explicit exclusion and absence from CSR/definition selection |
| `OB-NO-H` | 0/2 | Static: explicit exclusion, mode set and extension selection |
| `OB-RVWMO` | 0/2 | Static: one-hart selected legal sequential subset; runtime aq/rl fixture |
| `OB-PRIV-INSNS` | 0/2 | Static four-form scope plus runtime mm-mret/mm-sret/mm-wfi/mm-sfence |
| `OB-RESOLUTION-ROUTE` | 0/2 | Replace together with OB-ROUTE-FLIP by current definition record |
| `OB-ROUTE-FLIP` | 0/2 | Replace together with OB-RESOLUTION-ROUTE; no historical slot counts |
| `OB-SCOPE-CENSUS` | 0/2 | Static: scope enumeration equals complete composed definitions/pseudos |
| `OB-ALU-IMM` | 0/2 | Runtime: scope-alu / bound-arith,bound-ext |
| `OB-ALU-REG` | 0/2 | Runtime: scope-alu / bound-arith,bound-alias |
| `OB-ENDIAN` | 0/2 | Direct boundary: byte-order fixture / reversed-byte control |
| `OB-FENCE` | 0/2 | Runtime: fault-fence,scope-mem / reserved fm/pred/succ fixture |
| `OB-JALR-LSB` | 0/2 | Runtime: dir-chain / fault-jalr-mis (now legal halfword target) |
| `OB-LOAD-EXT` | 0/2 | Runtime: dir-ext-matrix / bound-ext; boundary low-bit stores |
| `OB-LOAD-X0` | 0/2 | Runtime: dir-x0-writes / fault-ld-x0-fault,fault-ld-x0-mis |
| `OB-LUI-AUIPC` | 0/2 | Runtime: smoke-arith / bound-arith |
| `OB-NO-DELAY-SLOTS` | 0/2 | Runtime: scope-branch / dir-cmp-branch,dir-chain |
| `OB-SHAMT` | 0/2 | Runtime: bound-shift / bound-shiftw,fault-shiftw-res |
| `OB-WSUFFIX` | 0/2 | Runtime: bound-arith / bound-shiftw,bound-ext |
| `OB-XLEN` | 0/2 | Static width plus runtime bound-arith / it-fault-wrap-ld |
| `OB-GC-CSR-ACCESS` | 0/2 | Runtime: mm-csr-rw / mm-csr-ro-write,mm-csr-legality-s/u |
| `OB-GC-COUNTERS` | 0/2 | Runtime: mm-counters / mm-csr-ro-counters |
| `OB-WALK-IMPLICIT` | 0/2 | Direct boundary request-kind witness; runtime inj-walk-l2/l1/l0 |
| `OB-GC-ATOMICS` | 0/2 | Runtime: a-amo-arith/minmax-w/d / a-lrsc-mustfail,a-amo-sv39 |
| `OB-GC-FENCEI` | 0/2 | Runtime: fencei-selfmod / fencei-reserved |
| `OB-GC-F` | 2/2 | Execution: all30forms, numeric/transfer/boxing/directed/refusal witnesses + companions |
| `OB-GC-D` | 2/2 | Execution: all32forms, numeric/raw64/format/directed/refusal witnesses + companions |
| `OB-RESERVATION` | 0/2 | Runtime: a-lrsc-pair / a-lrsc-fault,a-lrsc-mustfail |
| `OB-SC-DETERMINISTIC` | 0/2 | Runtime: a-lrsc-loop / a-lrsc-mustfail |
| `OB-ATOMIC-MISALIGN` | 0/2 | Runtime: aligned a-lrsc-pair / a-lrsc-illegal,a-amo-overlap |
| `OB-GC-ENV-TRANSLATION-INPUTS` | 2/2 | Registered: translation/Svade vs refused walk reads |
| `OB-GC-ENV-INTERRUPT-SOURCES` | 2/2 | Registered: timer/software pending vs nonexistent sources |
| `OB-GC-ENV-VIRTUAL-TIME` | 2/2 | Registered: counters/timer vs halted retirement |
| `OB-GC-ENV-RESERVATION-EVENTS` | 2/2 | Registered: constrained loop/pair vs hart-caused failure |
| `OB-GC-PRIV-INSNS-V1` | 2/2 | Registered: wait/fence and permissions/wake without delivery |
| `OB-GC-ECALL-EBREAK-V1` | 2/2 | Registered: modes/breakpoint and delegated delivery |
| `OB-GC-M` | 2/2 | Registered: multiply/word and divide/alias edge cases |
| `OB-GC-C` | 2/2 | Registered: all 28 C guests |
| `OB-GC-ENV-FETCH-SUPPLY` | 2/2 | Registered: page-end/link vs straddle/fetch fault |

#### Boundary closure

Five new assumptions are needed: address units, access widths/physical memory
attributes, event-delivery point, ordering, and cold reset. The scalar contract's
eight assumptions minus fetch leave seven, but virtual time already has a v1
replacement and partial progress is covered by the GC guarantee plus atomic
responses. Code visibility is OB-GC-FENCEI and the typed memory provider. Do not
copy scalar rules saying no asynchronous interrupt, 32-bit fetch, no memory-model
claim or integer-only reset into this composition.

The five new records must state physical requests versus translated guest VAs,
8-bit byte addresses, B/H/W/D data widths, exact full responses or failures,
alignment before translation, executable main memory without MMIO, little-endian
storage, instruction-boundary interrupt evaluation, one-hart sequential ordering
as a legal RVWMO subset, and the full declared cold state. Negative response-shape
or schedule fixtures are **contract violations**, not architectural trap causes.
Warm reset, external IRQ sources and multi-agent reservations remain out of scope.

#### Stale wording owned and scheduled for slice b

- OB-FP-DEFER: replace the qualification-stage wording by the qualified backend and
  finite numeric-evidence limits; preserve shared-ancestry constraints.
- OB-RESOLUTION-ROUTE and OB-ROUTE-FLIP: one current generated-definition record
  replaces both historical stage statements. Validate current scope, not stale
  62-guest/six-slot counts. Original records stay frozen; requirement-status work
  remains .14's.
- **Additional defect, reproduced**: OB-FAULT-PRIORITY says "no breakpoint exists
  (no Sdtrig)" although EBREAK and C.EBREAK deliver cause 3. RVP-MACHINE Table 7
  distinguishes instruction/data address triggers from environment break.
  Rehashed the pinned public machine.html: SHA-256
  b63fe33517fef2dabe53cdbc45b05d656bf808eebf83f0af5a4ab74549617fea.
  c-breakpoint.expected.sexp step 4 reads mcause=3. Root cause: a blanket absence
  phrase used for the absent address-trigger rows. Impact: contradictory effective
  contract prose, not an observed engine fault. Supersede the frozen record in v2
  with precise wording; annotate the old decision without rewriting its mirrored
  statement. No absence-of-Sdtrig claim will suppress EBREAK coverage.

The state consequence must include the FP file, 26 CSR storage owners (33 CSR
names including views), TLB, reservation and wait state as well as x/pc/mode and
memory. CSR views introduce no independent state; virtual time resides in mcycle.
The generated state's actual fields were read to establish this census. No replay
support is implied; implementing it remains .16.

Static realization will use explicit predicates over canonical parsed documents,
with a genuine violating copy for each negative check. Registry entries will name
static or typed-boundary checks as explicitly as guest checks, and all entries will
run in the normal suite. G-CONTRACT must keep counting only the effective unit's
exact declared pairs. Freeze only after all checks pass.

Promotion: declined — the canonical versioned records and the v2 book chapter
retain the scope decisions; this census remains the detailed execution receipt.


<!-- END designs -->

## acceptance

<!-- BEGIN acceptance bytes=9195 sha256=64bf353da7ccb0c49266fff5da55177a6f291a7bece8c063f9a38e9f833d8c8e -->
- [x] `.13` c36 — **ROOT CAUSE**: freeze.py/contract_measure rc=0:
  all114effective checks already exercised, v2 still open with14unpinned members;
  derive exact no-newline SHA256 pins from expanded canonical records.
- [x] `.13` c36 — **ADDRESSED**: freeze.py/CONTRACT-FREEZE/GS rc=0:
  intact GREEN0, edited record/missing pin/dropped member RED1; v2 frozen,
  G-CONTRACT green, CPU-SYSTEM incomplete7/10; .13 closed and .14 active.
- [x] `.13` c36 — **NO REGRESSION**: make ci/focused9/make book/verify.py rc=0:
  Rust173/17/253, all doctrines, wasm/bench/smoke, six books; v0/v1 prefix,
  obligations/CPU/registry/fixtures/prior journals/history exact, fixed caps.


- [x] `.13` c35 — **ROOT CAUSE**: source-auth/metadata/blame rc=0:
  root495b4b86 SC statements/current6addc986 inspection omit completed-path
  prerequisites; pinned A requires permission before retirement. Missing-binding
  cargo test RED101 names CHK-SC-DETERMINISTIC-POS before registration.
- [x] `.13` c35 — **ADDRESSED**: make check/census/example/verify.py rc=0:
  qualified live mirrors/new14thv2 member+2Execution rows, registry116/effective
  114/114; shared62176boundaries/194688requests;35actual controls RED101/restored,
  new SC route errors propagate, exact hand/canonical/author alias-history example.
- [x] `.13` c35 — **NO REGRESSION**: focused15/make book/verify.py rc=0:
  Rust173/17/253, six books and fresh167/5365/10524 corpus; all earlier fixture
  inputs/registry/frozen/history/LIVE/caps exact. Core inverse permits only one
  inspection string/3input hashes; storage/reset/legalization/semantics exact.
  Earlier205/32word derivations still apply; no unique-case/lineage credit.

- [x] `.13` c34c — **ROOT CAUSE**: defect-red.log self-test rc=1:
  architectural replacement's false acceptance actual0 instead of expected1;
  blame rootd3fecbf3's obligation_ids route misses explicit replacement mirrors.
- [x] `.13` c34c — **ADDRESSED**: self-test/real record gate rc=0:
  62pass/0fail with new authority refusal; copied actual disabled predicate
  rc=1 produces named MISS. Previous mirror/version/pin controls retain verdicts.
- [x] `.13` c34c — **NO REGRESSION**: verify.py/focused9/make book rc=0:
  prior guard inverse and CPU/profiles/contracts/frozen/history/milestone bytes
  exact; six books, fixed caps, prior Rust173/17/253 applies. LIVE count only
 668→669; registry114/effective112/114 unchanged.

- [x] `.13` c34b — **ROOT CAUSE**: source-auth/blame/verify.py rc=0:
  root495b4b86 policy overstatement, root1c554fcf public prerequisite omission;
  missing-binding RED101. Record-gate defect RED1 identifies root3ceebc55's
  version-unaware comparison; frozen460e4d8 partition must remain exact.
- [x] `.13` c34b — **ADDRESSED**: make check/census.py/route-controls.py
  rc=0: qualified3live statements/new13thv2 member +2Execution bindings,
  registry114/effective112/114;62176boundaries/194688requests;31Rust controls
  RED101/restored. Record-gate GREEN0/self-test61/0;13new version controls and
  3copied actual guards RED1 discriminate; authenticated current mirror route.
- [x] `.13` c34b — **NO REGRESSION**: verify.py/focused15/make book
  rc=0: Rust173/17/253, six books, fresh167/5365/10524 corpus; unchanged
  expectation inputs retain prior205/32word derivations. Frozen/selector/old
  registry/CPU semantics/data/canonical/archives/history/milestone rows/caps
  exact; only LIVE's derived arm count655→668. No cap increased.
- [x] `.13` c34b1 — **ROOT CAUSE**: verify.py rc=0: committed book
  523719B leaves569B; full C chapter29216B authenticates source9b5a2b0e;
  current tail's98/114 rootd8925716 conflicts with measured effective110/114.
- [x] `.13` c34b1 — **ADDRESSED**: verify.py/derive.py rc=0: full source
  inverse exact, five damaged controls refuse; chapter saves17043B, all37forms,
  worked4boundaries/5parcels and current report route; DEV6+CHANGELOG23 whole
  entries byte/order exact, prior manifest prefix retained, heads below health.
- [x] `.13` c34b1 — **NO REGRESSION**: focused8docs/make book rc=0:
  six books; prior167/5365/10524 exact; code/data/canonical/frozen/archives/
  history/LIVE/registry112/effective110/114/caps exact; Rust173/17/253 and
  full CI green from unchanged c538c6e apply, no additional Rust check needed.
- [x] `.13` c34b0 — **ROOT CAUSE**: defect-red.log cargo test rc=101:
 cold unmapped SC changes rd rather than traps; prior public core/author/Sail/
 Spike diagnosis pins root495b4b86. expectation-diagnostic rc=0 identifies
 parent translated-AMO expectation's MPRV bit, independently corrected for Bare.
- [x] `.13` c34b0 — **ADDRESSED**: cargo test/derive-plans.py rc=0:
 1625new full-state boundaries,1536independent architectural cells/32words,
 exact20736new permission checks in prior60640cells, parent A+960. mutations.py
 rc=0:6new/23prior actual controls RED101, byte-restored; no matching-SC Store
 replaced, no explicit data operation for nonmatch. Bound v2 pairs/adapters sync.
- [x] `.13` c34b0 — **NO REGRESSION**: make check/verify/focused/full
 make ci/six books rc=0: Rust173/17/253; guest arrays/canonical data/frozen v0/v1/
 archives/history/LIVE/prior112registry/effective110/114 exact. Open-v2 remains
 12members; no premature reservation/SC binding. Book/ENV/report/pointers sync,
 next bounded containment owned before binding; every cap fixed.
 promotion: declined (existing boundary and full-state evidence preserves the repair and controls with a precise next action).

- [x] `.13` c34a — **ROOT CAUSE**: diagnose.py rc=0: authenticated A/
 privileged sources, root495b4b8 three policy mirrors and non-v0 realization
 selector verified. sc-diagnostic/public/spike.py rc=0: unmapped cold SC
 discrepancy reproduced/root495b4b86 permission seam, immediate c34b0 owned.
- [x] `.13` c34a — **ADDRESSED**: derive-plans.py rc=0: all60640prebuilt
 boundaries/205canonical words/prior167/5365/10524 exact;4newtests GREEN,
 16wrong effects/16bad captures rejected. mutations.py rc=0:23actual guards
 RED rc=101 then restored, including shared-helper paired-history controls.
 Source/consumer qualification diagnosed; unbound witness subset excludes the
 newly discovered permission cell until immediate c34b0 repair before binding.
- [x] `.13` c34a — **NO REGRESSION**: make check/verify/focused/six books
 rc=0: Rust173/17/246; core/data/canonical/frozen/archives/history/LIVE/prior112
 registry/effective110/114 exact. Book/index/environment/report/resume/receipts
 sync. No new realized check, reference lineage or conformance claim.
 promotion: declined (existing full-state method plus immediate owned permission repair preserve the findings without a new knowledge card).

- [x] `.13` c33d — **ROOT CAUSE**: census/partition.py rc=0: full51-member
 book523938B/350room, original7179B introduction/440B checkpoint selected
 before change. Own-script blame pins ancestry wording rootb8d09f53, .14 owned.
- [x] `.13` c33d — **ADDRESSED**: verify.py rc=0: archive8886B/full14853B
 inverse/order/SHA exact; damaged byte/absent-marker/omission refuse; save4084B.
 All original headings/tables/fence/direct/public evidence body byte-exact;
 current policies and canonical88word/independent worked example verified.
- [x] `.13` c33d — **NO REGRESSION**: verify/focused/six books rc=0:
 prior archives/history/core/data/canonical/frozen/registry112/effective110/114/
 LIVE exact; prior Rust173/17/242 applies. Book/index/pointers/receipts sync,
 historical checkpoint qualified, named .14 repair scheduled, fixed caps.
 promotion: declined (finite inverse and worked examples preserve this existing containment method; provenance repair has its named .14 owner).

- [x] `.13` c33c — **ROOT CAUSE**: census/partition.py rc=0: live127192/
 131072B; five whole completed spans82856B identified before changes. Scratch
 insertion diagnosed exactly; all active .13/.14 ownership stays live.
- [x] `.13` c33c — **ADDRESSED**: verify.py rc=0 authenticates archive11/
 84762B, complete127192B committed-source inverse/order/SHA and damaged byte/
 absent-marker/omitted-payload refusals; partition46007B before receipts.
- [x] `.13` c33c — **NO REGRESSION**: verify/focused/six books rc=0: all
 retained live segments/prior archives/history/core/data/canonical/frozen/
 registry112/effective110/114/LIVE exact; prior Rust173/17/242 applies.
 Book worked example/index/pointers and fixed full-family/part caps sync.
 promotion: declined (finite archive and worked exact inverse retain this existing containment application).

Completed c29e1–c33b acceptance: [archive/P4-SYSTEM-11.md](archive/P4-SYSTEM-11.md#acceptance).


Completed c26a–c29e0 acceptance: [archive/P4-SYSTEM-10.md](archive/P4-SYSTEM-10.md#acceptance).

Completed c18–c25 acceptance: [archive/P4-SYSTEM-9.md](archive/P4-SYSTEM-9.md#acceptance).

Completed c7b through a and final .12 acceptance receipts are preserved
verbatim in [`archive/P4-SYSTEM-7.md`](archive/P4-SYSTEM-7.md#completed-acceptance).

Older acceptance/verification/commit/changelog records, plus closed designs, are
preserved in [`archive/P4-SYSTEM-6.md`](archive/P4-SYSTEM-6.md) (earlier parts linked there).


<!-- END acceptance -->

## verification

<!-- BEGIN verification bytes=2649 sha256=3cf296aeb5294fd0fa899a416cd78c416557c3d763a1297db8b15c48f66f98b8 -->
| `2026-10-10` | `.13` c36 |14exact pins; intact GREEN0/3damaged v2 controls RED1; full make ci/final focused9/books/invariant verifier | rc=0; Rust173/17/253,6books; G-CONTRACT green114/114 frozen, CPU incomplete7/10; .14 frontier |
| `2026-10-10` | `.13` c35 | missing-binding RED→2Execution rows; isolated shared62176census/194688requests;35restored controls; fresh167corpus/alias example | Rust173/17/253/focused15/six books/verify rc=0; registry116/effective114/114 open; frozen/storage/semantics/old inputs/history/LIVE exact |
| `2026-10-10` | `.13` c34c | false-acceptance RED1→62/0; disabled predicate RED1; exact guard inverse and protected census | record gate/focused9/six books/verify rc=0; CPU/data/frozen/history/milestones exact; arms669 |
| `2026-10-10` | `.13` c34b | missing-binding RED→2Execution rows;62176direct boundaries/194688requests;31Rust+3schema guards;13new version controls | Rust173/17/253/record-schema61/0/focused15/six books rc=0; registry114/effective112/114; frozen/selector/CPU/data/history/milestones exact; arms668 |
| `2026-10-10` | `.13` c34b1 | full C source capture/inverse, five damaged controls;37hand words/21refusals/mixed4/5/full167corpus; DEV6+CHANGELOG23 whole entries | verify/derive/focused8docs/six books rc=0; fixed caps, prior code/data/frozen/history/LIVE/registry exact |
| `2026-10-10` | `.13` c34b0 | defect RED101→1625new full-state cells/1536author cells/32words;6new+23prior actual controls RED-restored; bound v2 request fixtures | Rust173/17/253/focused/full CI/six books rc=0; all canonical guest data/frozen/history/LIVE/prior registry/effective110/114 exact; contain book/DEV before binding |
| `2026-10-10` | `.13` c34a |60640prebuilt full-state boundaries/205canonical words/prior corpus;16wrong/16capture/23actual guards RED-restored; public permission diagnosis | Rust173/17/246/focused/six books rc=0; registry112/effective110/114/core/data/frozen/history/LIVE exact; immediate c34b0 permission repair before binding |
| `2026-10-10` | `.13` c33d | whole7179B intro/440B checkpoint/full14853B source inverse; damaged controls refuse; canonical88words/independent worked example | archive8886B/save4084chapter B; prior history/core/data/frozen/LIVE/registry112/effective110/114 exact; focused/six books rc=0; prior Rust173/17/242 applies; hooks next |
| `2026-10-10` | `.13` c33c | five whole payloads/full127192B task inverse/order/SHA; damaged controls refuse; prior archive/history identity and full-family budgets | archive11/84762B; partition46007B; registry112/effective110/114/LIVE unchanged; focused/six books rc=0; prior Rust173/17/242 applies; hooks next |



<!-- END verification -->

## commits

<!-- BEGIN commits bytes=1635 sha256=8972332771b17a7d4db8ebeadd4bee7c97b95d0568bcd2951b795b845cffa9b1 -->
| `.13` c36 | `SEMULITH-P4-0191 (leaf P4-SYSTEM.13): freeze the complete environment contract` | priority .14 provenance/note repairs, then evidence signoff work |
| `.13` c35 | `SEMULITH-P4-0190 (leaf P4-SYSTEM.13): qualify and bind deterministic SC` | c36/0191 full CI and v2 freeze, then priority .14 sweep |
| `.13` c34c | `SEMULITH-P4-0189 (leaf P4-SYSTEM.13): preserve authority in versioned requirement mirrors` | deterministic SC c35/0190, full CI/freeze, priority .14 |
| `.13` c34b | `SEMULITH-P4-0188 (leaf P4-SYSTEM.13): qualify and bind reservation guarantees` | deterministic SC qualification/pair, full CI/freeze, then priority .14 sweep |

| `.13` c34b1 | `SEMULITH-P4-0187 (leaf P4-SYSTEM.13): contain C chronology and append histories` | qualified reservation supersession+binding c34b/0188, then SC/full CI/freeze and priority .14 sweep |

| `.13` c34b0 | `SEMULITH-P4-0186 (leaf P4-SYSTEM.13): check physical permission on failed SC` | own c34b1/0187 bounded book/development containment, then qualified reservation/SC bindings/full CI/freeze |
| `.13` c34a | `SEMULITH-P4-0185 (leaf P4-SYSTEM.13): witness reservation histories before binding` | own c34b0/0186 physical SC permission repair before qualified reservation/SC bindings/full CI/freeze |
| `.13` c33d | `SEMULITH-P4-0184 (leaf P4-SYSTEM.13): contain atomics timeline before final pairs` | own c34/0185 reservation witnesses before SC/full CI/freeze; .14 sweep owned |
| `.13` c33c | `SEMULITH-P4-0183 (leaf P4-SYSTEM.13): contain completed task receipts` | own c33d/0184 atomics-book containment, then reservation/SC/full CI/freeze; .14 sweep owned |



<!-- END commits -->

## changelog

<!-- BEGIN changelog bytes=2690 sha256=4be70bdea03860daef2369c80fbe6658dbf9f541ebf885068d55158f800ff7ee -->
- `2026-10-10`: `.13` c36 (SEMULITH-P4-0191): freeze14v2 members after114/114checks;3damaged controls rejected, full CI/focused9/six books/invariants green. Close .13, activate .14; CPU incomplete7axes.

- `2026-10-10`: `.13` c35 (SEMULITH-P4-0190): qualified SC prerequisite mirrors/inspection text, v2 supersession+2Execution bindings;35controls, shared62176census and fresh167corpus green; registry116/effective114/114, final CI/freeze next.

- `2026-10-10`: `.13` c34c (SEMULITH-P4-0189): close false acceptance of laboratory-authority replacement for architectural requirement;62/0/disabled-predicate RED1/focused9/six books green, fixed caps and protected CPU/frozen data.

- `2026-10-10`: `.13` c34b (SEMULITH-P4-0188): qualify live reservation mirrors/public matches comments, frozen-safe v2 supersession plus2Execution checks;62176direct boundaries/31controls; registry114/effective112/114.
- `2026-10-10`: `.13` c34b1 (SEMULITH-P4-0187): preserve full C source/inverse, current mixed-length guide and report route; whole DEV/CHANGELOG partition; verify/derive/focused8docs/six books rc=0.
- `2026-10-10`: `.13` c34b0 (SEMULITH-P4-0186): nonmatching SC checks
 side-effect-free physical permission before retirement; denied/malformed
 answers preserve target/provider distinction.1625newcells/1536authorcells,
 6new+23prior actual controls discriminate; Rust173/17/253/focused/CI/books
 green. Prior guest data/frozen/history/LIVE/registry/effective110/114 exact;
 contain book/DEV before qualified reservation/SC bindings and freeze.

- `2026-10-10`: `.13` c34a (SEMULITH-P4-0185): unbound60640boundaries/
 121280parcels/168192requests;16wrong/16capture/23actual controls discriminate,
 independent author/205words/prior corpus exact; Rust173/17/246/focused/books
 green. Core/data/frozen/history/LIVE/effective110/114 exact. Own immediate
 c34b0 physical SC permission repair, then qualified reservation/SC bindings.

- `2026-10-10`: `.13` c33d (SEMULITH-P4-0184): whole atomics intro/checkpoint
 7619B→8886B archive/full14853B inverse; save4084B, all direct/public examples
 exact. Worked88words/independent sequence, focused/six books green. .14 owns
 rootb8d09f53 assembler rationale repair; registry112/effective110/114/LIVE
 unchanged. Reservation/SC/full CI/freeze next, fixed caps.

- `2026-10-10`: `.13` c33c (SEMULITH-P4-0183): five whole completed spans
 82856B→archive11/84762B; full127192B source inverse/damaged controls pass.
 Retained live/.13/.14/prior history/core/data/frozen/LIVE/registry112/effective
 110/114 exact; focused/six books green. Own atomics-book containment next.

Prior entries: [archive/P4-SYSTEM-11.md](archive/P4-SYSTEM-11.md#changelog).

<!-- END changelog -->
