# DEV_NOTES shard — _(2026-10-10)_ … _(2026-10-10)_

> Sharded from `DEV_NOTES.md` under its 48 KiB ceiling (`doctrine/readme_routes.tsv`).
> Entries in a shard are **never edited after the shard** — git history is canonical.

## _(2026-10-10)_ — observe JALR targets and links directly (P4-SYSTEM.13 c22b2)

The old GC comparison admits base-JALR bit-1 erasure across all 167 guests.
Bind literal Execution POS/NEG after declaration missing-entry RED rc=101.
Fifteen direct cases cover ordinary/odd targets, immediate limits, carry before
masking, negatives, wrap, high bits, aliases, x0 and two next-fetch faults:
17 boundaries/32 actual parcels. All GPR/PC/mode/trap/counters/requests/memory
are observed; companion guests add 36/71, making the pair 53/103.

Eight incorrect public effects fail named observations. A source-disabled PC
observer lets bit-1 erasure escape (meaningful test RED rc=101); restore GREEN.
Reordering link before target alone is equivalent: Frame snapshots register
reads before all effects. Investigated the initial invalid control, retain its
GREEN result and explicitly use the new link as the aliased base for the RED.
No production CPU/author/generated/canonical change. Prior 90 bindings exact;
independent direct 15/17/32 and full 167/5365/10524 replay/identity rc=0.

make check rc=0 (Rust 167/17/208). Registry92/effective90/114, twelve runtime
pairs/freeze remain. Focused gates/all six books rc=0; hooks precede c23a book
containment then c23b XLEN. Integer chapter 31,694/32,768 B; retain every
witness byte in the next split. LIVE_STATUS unchanged (652 arms,48 chapters,P4 12/18).
promotion: declined (finite target/request distinction and equivalent-mutation
root diagnosis retained with worked examples in book/tree).

## _(2026-10-10)_ — correct inherited IALIGN evidence and own JALR target gap (P4-SYSTEM.13 c22b1)

Six GC source/expectation files for fault-jal-mis, fault-jalr-mis and it-prio-jump
retain base IALIGN=32 trap/no-link prose despite current GC link writes. Import
133e722 copied it; 2611340 added parcels but retained derivations. Full relevant
source histories audited (base roots a199ccf/25862a2). Authenticated RV32I/C
sources confirm IALIGN=16 halfword targets. Correct prose and last it-prio-jump
mnemonic to <fetch fault>; historical basenames and base input files stay fixed.
Literal final states reproduced through independent author and public CPU.

An isolated public BASE JALR table masks with ~3 instead of ~1; all 167/5365/10524
old observations still pass. fault-jalr-mis final PC 2→0; it-prio-jump fault
EPC/tval40000002→40000000. The GC rule lacks these observations. Production
is correct. Own priority-next c22b2 direct target-state witnesses before credit.
The initial census's dir-chain candidate has no JALR; actual six-guest census
and finite limits are in task/book. Do not treat this diagnostic as a realized pair.

Identity rc=0: 112 base exact; 342 GC exact plus six annotation-only changes, all
images/numeric writes/budgets unchanged. Generated Rust differs ONLY by six input
hash strings; executable arrays byte-exact. All 90 registry/core/author/frozen
bytes exact; effective 88/114 unchanged. Normal full167/5365/10524 rc=0; make check
rc=0 (Rust167/17/206). GUEST-GEN rc=0 (147/0 self-test); make ci rc=0 (all five legs, including
all six books). Hooks precede c22b2.
LIVE_STATUS changes only doctrine arms 650→652 (48 chapters / P4 12/18 unchanged). promotion: declined
(worked target/observation distinction and priority repair retained in book/tree).

The first GUEST-GEN run refused source annotations (142/145 pass). Its governor
now pins exactly three reviewed base/GC source pairs and independently requires
identical assembled images. Stale exceptions and changed owner/mirror pins or
instructions refuse; two isolated bypass mutations fail. All other source bytes,
seven expectation exceptions and write/parcel checks remain governed.

## _(2026-10-10)_ — retain whole development receipts (P4-SYSTEM.13 c22a)

Live notes reached 47,462 B under fixed 49,152 B cap. Existing sharder targets
32,768 B: 20 entries=13 kept+7 moved, head 31,228 B. New shard 0224 preserves the
16,234 B ordered suffix, SHA256 0ad12ca063f04407f2aee04a06b2bec7a250050fc9135d5f8044f0bed7631af1.
Remove only this new note/footer and concatenate kept+shard entries to recover
47,462 B SHA256 8f3064fc70b5929072632f333171ba281d77a926a512013ae3d827f2a9277a46.
Old manifest prefix/sealed history exact; one appended row, 226 logical frozen
shard rows. Runtime/canonical/guest/registry/frozen bytes exact; 88/114 unchanged.
Inverse/no-op rc=0; focused gates and all six books rc=0, including 226 frozen
rows, six derived claims and 40 index rows. Hooks then c22b JALR-LSB. LIVE_STATUS unchanged (650 arms, 48 chapters, P4 12/18).
promotion: declined (existing whole-entry containment protocol; exact proof in
owning task and book example).

## _(2026-10-10)_ — require immediate architectural transfers (P4-SYSTEM.13 c21b)

NO-DELAY-SLOTS was declared/unbound. Authenticated RV32I 1.1.5 and all eight
requirement associations reviewed. POS guest-control/c-branches and NEG
scope-branch/dir-cmp-branch/c-links retain exact 63/111 observations. Base skipped
writes pin x6/x13, x20–x24 and x8; not-taken fall-through remains visible. C
programs add five compressed control forms and mixed 2/4-byte lengths.

Thirteen isolated author drivers defer one named taken transfer until after one
actual instruction, preserving correct link values. All fail named observations.
A separate public-CPU delayed-PC driver reproduces all thirteen first differences;
normal driver matches writes, never-written markers and fetch counts. Book retains
the matrix. No production/author/guest change or pipeline implementation claim.
Declaration test first missing-entry RED rc=101; then exact two Guest bindings.
make check rc=0 (Rust 167/17/206). Independent probes/full 167/5365/10524 rc=0;
prior 88 bindings/112 base+348 GC inputs/core/author/generated/frozen identity rc=0.
Registry 90, effective 88/114: scope 13/guest 23/boundary 6/execution 2 pairs; thirteen
runtime pairs/freeze remain. LIVE_STATUS unchanged (650 arms, 48 chapters, P4 12/18).
Focused gates/books rc=0 (shards, fixed bounds, frontiers, six derived claims,
frozen contracts, fresh reports, schema, main+five model books). Hooks precede
c22a live-note containment, then c22b JALR-LSB.
promotion: declined (ordinary control-flow discrimination and finite limits
retained with exact witnesses in integer book and owning tree).


## _(2026-10-10)_ — keep memory witnesses in a bounded book chapter (P4-SYSTEM.13 c21a)

The integer chapter reached 32,287 B against fixed 32,768 B per-part ceiling,
leaving 481 B for future runtime work. Book family has 49 tracked files, not its
80-file cap, and 448,559 B against 524,288 B. Move LOAD-EXT/LOAD-X0/ENDIAN as an
ordered suffix into contract-memory.md, preserving every section and separator.
The suffix is 10504 B, SHA256 098a50b7a66bd45c39c91dbf5a73025e75f7720c16a2397a00ef61db9d241109.
Remove only the new navigation line and chapter header to reconstruct the exact
32,287 B original, SHA256 37589ade3b38e2065f8399cb7f475d74b0c2209636b33e836aa69a6629f64c28.
Integer/memory chapters now 21,872/10,782 B; caps unchanged. SUMMARY, index,
profile pointers/GS report and current runtime summary follow the split.

`python3 target/p4-system-13/c21a/verify.py` rc=0 verifies inverse and all prior
88 registry/core/author/generated/frozen bytes plus 112 base/348 GC canonical/
guest inputs. Effective 86/114 unchanged; no Rust code changed. LIVE_STATUS
changes only book chapters 47→48, doctrine arms 650/P4 12/18 unchanged. Focused
gates and main+five model books rc=0, including six derived claims and 40 index
rows. Explicit new-file census: 50 files/449,248 B, fixed caps hold. Hooks then
c21b NO-DELAY-SLOTS.
promotion: declined (lossless partition under existing fixed containment policy;
source/suffix/inverse hashes retained in this entry and owning task).


## _(2026-10-10)_ — discriminate the selected little-endian byte lanes (P4-SYSTEM.13 c20)

OB-ENDIAN was declared but unbound. Authenticated RV32I 1.1.6 delegates the
choice to the EEI and requires byte-address invariance; canonical profile chooses
little-endian. POS scope-mem and NEG dir-ext-matrix independently match 64/128,
all seven integer load/four store forms. The NEG matrix stores sign-edge values
then reads different widths/addresses. It distinguishes a pair of wrong read/
write orders that a same-width round trip might hide.

Nine isolated author controls reverse each LH/LHU/LW/LWU/LD, SH/SW/SD, or both
directions. All fail NEG at named steps; SH-only reversal survives scope-mem's
all-ones store, while SW fails its later pattern at step 28. A separate public
client reverses H/W/D provider reads/writes/both: nine more NEG refusals. Byte
reversal changes neither selected guest; all 256 public byte values keep their
address/value. Existing literal DataAccess witnesses give provider composition
context; no new core/author/guest semantics or configurable endian mode.

Declaration check observed missing-entry RED rc=101 before registration. Exact
two Guest bindings pass make check rc=0 (Rust 167/17/206). Independent author/
public probes rc=0, full 167/5365/10524 normal replay exact; identity rc=0 for all
prior 86 bindings and 112 base/348 GC inputs/core/author/generated/frozen bytes.
Registry 88, effective 86/114: scope 13/guest 22/boundary 6/execution 2 pairs; fourteen
runtime pairs/freeze remain. Book retains lane values, controls and limits.
LIVE_STATUS unchanged (650 arms, 47 chapters, P4 12/18). Focused gates/books rc=0 (shards, fixed bounds, frontiers, six derived claims,
frozen contracts, fresh reports, schema, main+five model books). Hooks precede
c21a book partition under fixed cap, then c21b NO-DELAY-SLOTS.
promotion: declined (ordinary lane/symmetry reasoning retained with worked
observations in the integer book and owning task).


## _(2026-10-10)_ — require x0 load requests and delivered faults (P4-SYSTEM.13 c19)

The GC mirror's shared corpus rule compares register changes, never-written
registers and fetch counts; neither final trap state nor data requests is judged.
Root is the route flip/mirror at 133e722 (base fault fixtures originate a199ccf;
registry reuses that rule from 072b211). Base-specific crossing/fault assertions
remain valid. Isolated author and independent public conditional bad table both
skip loads only when rd=0 and still satisfy all 167/5365/10524 old observations,
including the two fault guests. Their cause/EPC/tval/PC/retirement actually differ:
book retains exact before/after values. Own and resolve this previously uncredited
LOAD-X0 witness gap here; no core misbehavior was found.

New literal public-interface cases cover all seven load encodings: seven success,
seven access refusals, five misalignments and seven Sv39 invalid-root page faults.
Audit exact width/address request sequence, GPRs/x0, PC, mode, cause/EPC/tval,
cycles, retirement, parcels and memory. Page faults require the implicit root
walk and no explicit Load. Direct 26/52 plus unchanged companions 52/104=78/156.
Seven erased and seven duplicate tables refuse; each erased form also fails each
applicable fault case. Disabling the request observer causes the terminal control
to fail rc=101; restoring it passes. Disabled access-fault injection also refuses.
Declaration test first missing-entry RED rc=101, then two exact Execution bindings.

make check rc=0 (167 core/17 DSP/206 verify). Independent author/public probes
rc=0; exact prior 84 registry entries and 112 base/348 GC input files, core,
definitions, author, generated data and frozen records verified rc=0. Registry 86,
effective 84/114, fifteen runtime pairs/freeze remain. LIVE_STATUS unchanged:
650 arms, 47 chapters, P4 12/18. Book retains matrix, root cause and finite limits.
Focused gates/books rc=0 (shards, fixed bounds, frontiers, counts, frozen contracts,
fresh reports, schema, main+five model books). Hooks precede c20 ENDIAN.
promotion: declined (the worked
request/trap distinction and controls remain in the integer book and owning tree).


## _(2026-10-10)_ — authenticate citation evidence at both readers (P4-SYSTEM.13 c18c)

Actual locator/quote readers both returned rc=0 on three fetched RISC-V HTML
pages whose hashes differed from the source ledger, despite identical lengths.
Full byte diff isolates one Antora UI-version metadata value per page; architecture
text unchanged. The snapshot matches exact pins. The failure is reader identity,
not an ISA disagreement: published read headings without checking bytes, and
quote corpus used the same preferred fetched route. History roots: 32b72dbc's
reader, 3afd2757's route, bf2070a7's quote consumer. SEMANTICS also gated locator
work only on cache availability; cache failures could become an absence skip.

Shared verified_source now requires a regular file, valid SHA256/byte-length pin,
exact length and exact digest before either reader uses a page. Both paths refuse
alteration and malformed identity clearly; no silent fallback or repin. Shared
presence-only dispatch checks fetched-only data, treats partial/corrupt evidence
as present and permits a named skip only for absence. Cache resolution errors
propagate; quote entrypoint distinguishes source refusal from a text mismatch.
Non-snapshot http_status=0 handling and explicit synthetic --pages interface stay
unchanged. Locator controls run with SEMANTICS. All self-test scratch now derives
from target/doctrine-selftest; synthetic root paths are relative, not serialized
absolute paths. Correct the old pre-integration "not a commit gate" docstring.

Observed new controls against old code: locator 15 pass/3 fail (same-size text,
wrong length, absent identity), quote 14/1 (default-corpus changed bytes accepted).
After repair: locator 21/0, quote 15/0, SEMANTICS 8/0. Actual mismatched pages then
refuse through locator/quote tools and both wrappers (rc=1/2/1/2), naming source
and sha256. Seven route cases cover total absence, fetched-only, cache-only,
changed preferred source with valid fallback, quote integration, changed cache
page with valid manifest and corrupt manifest. No named skip hides corruption.

Authenticate snapshot manifest and all 72 files (0 failures), save/verify the old
three fetched pages on-volume, prove metadata-only diff, restore exactly 3 files /
226648 B and rehash against unchanged ledger. Public locators resolve 10 files/
12 bindings; quote corpus 118 attributed, 0 findings, 88 unattributed, two named
non-HTML source IDs (three instances). All 84 registry entries, production/core/
author/generated/frozen and 112 base/348 GC input files remain exact; 82/114 unchanged.
make ci rc=0, all five legs green (Rust 167/17/203, doctrines, bench, smoke bench,
main+five model books). Focused identities/controls/routes also rc=0. LIVE_STATUS
changes only doctrine arms 649→650; 47 chapters/P4 12/18 unchanged. Next c19 LOAD-X0.

Promoted to [a-version-string-is-not-an-identity](docs/knowledge/a-version-string-is-not-an-identity.md)
and its index: authenticating at acquisition does not authenticate a later reader;
presence dispatch must never turn corruption into absence.

## _(2026-10-10)_ — realize load extension and low-bit stores (P4-SYSTEM.13 c18b)

Bind LOAD-EXT POS scope-mem, NEG bound-ext/dir-ext-matrix, all eleven forms and
111 boundaries/222 parcels. Literal sign-edge arithmetic pins 8/16/32 widths on
both sides and unsigned partners; zero LB visibly overwrites -1. Wider reads
observe narrow stores leaving higher lanes zero, full SD/LD preserves the pattern,
and cross-width high lanes use the read width's sign. Non-clamping source values
distinguish truncation from saturation.

Before credit, seventeen isolated author copies fail committed observations:
signed LB/LH/LW zero-extension at scope-mem steps 12/14/16; unsigned LBU/LHU/LWU
sign-extension at steps 13/15/17; LD low-word18; SB/SH/SW high-bit selection at
bound-ext steps 23/28/33, overwide writes at scope-mem steps 22/24/26, saturation at
bound-ext steps 42/44 and scope-mem step 28; SD low-word at scope-mem step 17. Public registry gate
first fails the missing LOAD-EXT entry (rc=101), then both bindings run. Normal
full independent replay is 167/5365/10524 exact; Rust 167/17/203 passes make check.
Only registry/tests, review docs and derived GS change; every prior 82 entry and
112 base/348 GC canonical+guest inputs, production core/author, generated data and
frozen definitions remain exact. Effective 82/114, registry 84, sixteen pairs/freeze
remain. NEG is a legal semantic counterexample, not an invented trap.

Source review found fetched RV32I/RV64I bytes differ from ledger digests, with
same lengths. Exact diff is one Antora UI-version meta value per page; the local
snapshot matches both pinned hashes, and its full relevant sections supplied this
review. check_citations._work_dir prefers any fetched directory; published reads
without digest checks, and quote reader uses the route directly. Owned priority
c18c repairs both evidence paths immediately after this commit, before further
runtime pairs. No architecture-body or processor mismatch; no repin or silent
fallback authorized. Details/reproduction and repair schedule are in the task.

Focused identity/reports/freeze/schema/bounds/counts and main+five model books
pass (rc=0). Required hooks precede c18c. The first hook refused the combined
acceptance box; split ROOT CAUSE/ADDRESSED/NO REGRESSION into distinct ticked
boxes with their own actual tool results, then rerun the required hook.
LIVE_STATUS unchanged: 649 arms/47 chapters/P4 12/18. .14 retains status/experiment work.
promotion: declined (worked matrix and finite controls live in the integer book; the separate identity defect is owned with immediate repair in the task).


Earlier entries: [history manifest](docs/changelog/SHARDS.sha256).
